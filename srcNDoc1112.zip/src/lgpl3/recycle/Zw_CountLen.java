package lgpl3.recycle;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.filter.BitRow;
import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;

/**
 * To cmpress.<br/>
 * To cmpress.
 *
 * @version 2023/05/21_22:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_CountLen" >src</a>
 *
 */
public class Zw_CountLen {

	public static void main(String[] sAry) throws Throwable {

		int k = 10;

		long b64W6 = B64W6.genB64W6ByAry32(Ary32va.genAscAry32From1(k));

		O.l("b64W6=" + B64W6.str(b64W6));

		b64W6 = BitRow.vToIdxNCompress(B64W6.easySort(b64W6, k));

		O.l("vToIdxNCompress=" + B64W6.str(b64W6));

	}
}
