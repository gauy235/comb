package lgpl3.comb.wDup;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.wDup.DatWDup_A.DEF_DIV32;

import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;

/**
 * @version 2023/11/11_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=PWDup_U" >src</a>
 *
 * @see PWDup_V
 */
public abstract class PWDup_U extends PWDup_A {

	private static final Class<?> THIS = PWDup_U.class;

	/**
	 * Log2 then divide.<br/>
	 */
	public static int logNDiv(long v) {

		return B64va.log2(v) / DEF_DIV32;
	}

	/**
	 * To convert.<br/>
	 */
	public static String strQ(int v32) {

		// O.l("v32=" + v32, THIS);

		return (v32 == -1) ? O.S64 : O.ARY_A_Z[v32];
	}

	/**
	 * To convert.<br/>
	 */
	public static StringBuilder conv(long b64As2Pow) {

		StringBuilder ret = new StringBuilder();

		if (b64As2Pow == 0b0L) return ret;

		long low1;

		do if ((low1 = -b64As2Pow & b64As2Pow) == b64As2Pow) return ret.append(O.ARY_A_Z[logNDiv(low1)]);

		else ret.append(O.ARY_A_Z[logNDiv(low1)]).append(O.C44);

		while ((b64As2Pow &= ~low1) != 0b0L);

		throw new IllegalArgumentException();
	}

	public static void p(long rmdB64, int rmdK, long prefix, Seq retSeq, int lv) {

		lv++;

		long allLow1 = rmdB64, low1 = (-allLow1 & allLow1), curB64W6;

		int exQ = -1, lowQ = logNDiv(low1);

		prefix <<= $6;

		if (rmdK == 0) {

			if (lowQ != exQ) {

				curB64W6 = prefix | (lowQ + 1); // 記得 plus 1

				O.lv(lv, "cur=" + B64W6.strByVCellMinus1AftRevBySAry(curB64W6, O.ARY_A_Z));

				retSeq.a(curB64W6);
			}

			return;
		}

		if (Long.bitCount(rmdB64) < rmdK) return;

		do {
			O.lv(lv, "lowQ=" + strQ(lowQ) + " of " + conv(allLow1) + " :" + strQ(exQ));

			if (lowQ != exQ) {

				exQ = lowQ;

				curB64W6 = prefix | (lowQ + 1); // plus 1

				O.lv(lv, "add=" + B64W6.strByVCellMinus1AftRevBySAry(curB64W6, O.ARY_A_Z));

				p((rmdB64 & ~low1), rmdK - 1, curB64W6, retSeq, lv);

			} else O.lv(lv, "<===");

		} while ((allLow1 &= ~low1) != 0b0L);
	}
}
