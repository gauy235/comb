package lgpl3.comb;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;

import lgpl3.b32.B32va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Arr;
import lgpl3.o.ary.Seq;
import lgpl3.o.keyNV.K32V64;

/**
 * @version 2023/11/11_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Pnk_J" >src</a>
 *
 * @see Pnk_W
 */
public abstract class Pnk_J extends Pnk_H {

	private static final Class<?> THIS = Pnk_J.class;

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * 剪尾巴法, 剪尾巴後再延伸法, 砲彈互斥法.
	 */
	// rule: [1,2,3] => 1,2,31,32=>1,2,31,(321)=>1,2,(312),(321)=>1,23,21,(312),(321)=>...

	public static long[] colByIterBreadthFifo(int n, final int k) { // 原創

		Seq retSeq = new Seq();

		Arr<K32V64> qu = new Arr<>(K32V64.class);

		K32V64 tailKV; // [K, V] = [rmdB32, prefix]

		int iHeadOfQ = 0, rmdB32 = ~(-0b1 << n), allLo1 = rmdB32, lo1; // O.l("hi1=" + B64W6.str24(hi1));

		long prefix;

		// init
		do qu.a(new K32V64(rmdB32 & ~(lo1 = -allLo1 & allLo1) /* 每次拿掉最低位元 */, B32va.log2NPlus1(lo1)));

		while ((allLo1 &= ~lo1) != 0b0);
		// init end

		do {
			tailKV = qu.ar[iHeadOfQ++];

			allLo1 = rmdB32 = tailKV.k; // O.l("rmdB32=" + B32va.str16(rmdB32), THIS);
			prefix = tailKV.v;

			if (B64W6.totalVCell(prefix) == k) retSeq.a(prefix); // 個人主義 當差 那 1 個什麼 情況下 大智若愚

			else do qu.a(new K32V64(rmdB32 & ~(lo1 = -allLo1 & allLo1) /* 每次拿掉最低位元 */,

					(prefix << $6 | B32va.log2NPlus1(lo1))));

			while ((allLo1 &= ~lo1) != 0b0); // O.l("hi1=" + B64W6.str24(hi1));

		} while (iHeadOfQ != qu.i);

		O.l("lenQ=" + qu.i, THIS);

		return retSeq.trim().ar;
	}
}
