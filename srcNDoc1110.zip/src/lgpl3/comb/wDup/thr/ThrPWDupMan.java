package lgpl3.comb.wDup.thr;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.wDup.DatWDup_A.DEF_DIV32;

import java.util.Arrays;

import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;
import lgpl3.o.thr.ThrWBox;

/**
 * 排列 with duplicated.<br/>
 *
 * @version 2023/11/09_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ThrPWDupMan" >src</a>
 *
 * @see ThrToCWDup
 */
public class ThrPWDupMan extends ThrWBox<DatWDup> { // ThrPWDup manually

	private static final Class<?> THIS = ThrPWDupMan.class;

	public long allB64As2Pow;

	public final int k;

	public long tmp64;

	public Seq seq;

	/**
	 * 排列.<br/>
	 */
	public void colRecur(long rmdB64, long preB64W6) {

		if (B64W6.totalVCell(preB64W6) == k) {

			if (box.ifPassToInEx(preB64W6)) { // O.l("add=" + B64W6.strByVCellMinus1AftRevBySAry(preB64W6, O.ARY_A_Z));

				O.l("pass=" + B64W6.strByVCellMinus1AftRevBySAry(preB64W6, O.ARY_A_Z), THIS);

				seq.a(preB64W6);

			}

			return;
		}

		for (long all1 = rmdB64, low1; all1 != 0b0L; all1 &= ~low1)

			if (!box.isToEx(tmp64 = (preB64W6 << $6) | (B64va.log2(low1 = -all1 & all1) / DEF_DIV32 + 1 /* must plus 1 */)))

				colRecur((rmdB64 & ~low1), tmp64);

	}

	/**
	 * 建構方法.<br/>
	 */
	public ThrPWDupMan(DatWDup datWDup) {

		box = datWDup;

		allB64As2Pow = datWDup.b64OfQRCell;

		k = datWDup.k;

		datWDup.tmpObj = seq = new Seq();

	}

	@Override
	public void run() {

		colRecur(allB64As2Pow, 0b0L);

		box.cntP = seq.i;

		Arrays.sort(seq.trim().ary); // fuck

		for (int idx = 0; idx != seq.i; idx++) box.mapK64V32.easyPutNCount(seq.ary[idx]);
	}
}
