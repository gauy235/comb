package lgpl3.comb;

import java.util.LinkedList;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Arr;
import lgpl3.o.keyNV.K32V64V32;

/**
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Pnk_J" >src</a>
 *
 * @see Pnk_W
 */
public abstract class Pnk_J extends Pnk_H {

	private static final Class<?> THIS = Pnk_J.class;

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * 剪尾巴後再延伸法, 砲彈互斥法.
	 */
	// rule: [1,2,3] => 1,2,31,32=>1,2,31,(321)=>1,2,(312),(321)=>1,23,21,(312),(321)=>...

	public static long[] colByIterBreadthNDepthFirst(int n, int kAsLv) { // 原創

		int rmdB32 = ~(-0b1 << n), tmpAll1 = rmdB32, low1, iStk = 0, iRet = 0, stackLen;

		stackLen = (n + (n - kAsLv + 1)) * kAsLv >>> 1; // P(10,8) => 8+7+6+ ... +5+4+3 => 上底 + 下底

		K32V64V32 stack[] = new K32V64V32[stackLen - kAsLv + 1], topKvv;

		O.l("stackLen=" + stack.length, THIS);

		long ret[] = new long[(int) int64(n, kAsLv)], prefix;

		if (--kAsLv == 0) {

			do ret[iRet++] = n; while (--n != 0);

			return ret;
		}

		// init [rmd, prefix, kAsLv]

		do stack[iStk++] = new K32V64V32((~(low1 = -tmpAll1 & tmpAll1) & rmdB32 /* 這層只拿掉某 1 個位元 */ ),

				B32va.log2NPlus1(low1), kAsLv);

		while ((tmpAll1 = ~low1 & tmpAll1) != 0b0);

		// init end

		O.l("stack=" + O.L + new Arr<K32V64V32>(stack).toStr());
		O.l("iStk=" + iStk, THIS);

		do {
			topKvv = stack[--iStk];

			rmdB32 = topKvv.k; // O.l("rmdB32=" + B32va.str16(rmdB32), THIS);
			prefix = topKvv.v1 << B64W6.$6;
			kAsLv = topKvv.v2;

			if (--kAsLv == 0) // 檢查是否剩下最後 1 個位元

				do ret[iRet++] = (prefix | B64va.log2NPlus1(low1 = -rmdB32 & rmdB32)); while ((rmdB32 &= ~low1) != 0b0);
			else {
				tmpAll1 = rmdB32;

				do stack[iStk++] = new K32V64V32((~(low1 = -tmpAll1 & tmpAll1) & rmdB32 /* 這層只拿掉某 1 個位元 */),

						(prefix | B32va.log2NPlus1(low1)), kAsLv);

				while ((tmpAll1 &= ~low1) != 0b0); // stack 增長 長尾巴
			}

		} while (iStk != 0);

		return ret;
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * 剪尾巴後再延伸法, 砲彈互斥法.
	 */
	// rule: [1,2,3] => 1,2,31,32=>1,2,31,(321)=>1,2,(312),(321)=>1,23,21,(312),(321)=>...

	public static long[] colByIterBreadthNDepthFirstFifo(int n, int kAsLv) { // 原創

		int rmdB32 = ~(-0b1 << n), tmpAll1 = rmdB32, hi1, iRet = 0;

		LinkedList<K32V64V32> que = new LinkedList<>();

		K32V64V32 kvv;

		long ret[] = new long[(int) int64(n, kAsLv)], prefix;

		if (--kAsLv == 0) {

			do ret[iRet++] = n; while (--n != 0);

			return ret;
		}

		// init [rmd, prefix, kAsLv]

		do que.add(new K32V64V32(rmdB32 ^ (hi1 = B32va.highest1(tmpAll1)) /* 這層只拿掉某 1 個位元 */,

				B32va.log2NPlus1(hi1), kAsLv));

		while ((tmpAll1 ^= hi1) != 0b0); // O.l("hi1=" + B64W6.str24(hi1));

		// init end

		do {
			kvv = que.poll();

			rmdB32 = kvv.k; // O.l("rmdB32=" + B32va.str16(rmdB32), THIS);
			prefix = kvv.v1 << B64W6.$6;
			kAsLv = kvv.v2;

			if (--kAsLv == 0) // 檢查是否剩下最後 1 個位元

				do ret[iRet++] = (prefix | B64va.log2NPlus1(hi1 = B32va.highest1(rmdB32))); while ((rmdB32 ^= hi1) != 0b0);
			else {
				tmpAll1 = rmdB32;

				do que.add(new K32V64V32(rmdB32 ^ (hi1 = B32va.highest1(tmpAll1) /* 這層只拿掉某 1 個位元 */),

						(prefix | B32va.log2NPlus1(hi1)), kAsLv));

				while ((tmpAll1 ^= hi1) != 0b0);
			}

		} while (que.size() != 0);

		return ret;
	}
}
