package lgpl3.other.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.time.T64;

/**
 * colByIterBreadthNDepthFirstFifo<br/>
 *
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex015_PByIter" >src</a>
 *
 * @see Ex009_FacByPostDfs
 */
public class Ex015_PByIter {

	public static void main(String[] sAry) throws Throwable {

		int n = 4;
		int k = 3;

		// long t0 = O.t(), ar[] = Pnk.colByIterBreadthNDepthFirst(n, k);
		long t0 = O.t(), ar[] = Pnk.colByIterBreadthNDepthFirstFifo(n, k);

		float costT = T64.difInF32Sec(t0);

		Aryva.checkDup(Aryva.rev(ar));

		O.l("ar[0]=" + B64W6.str24(ar[0]));

		if (n <= 8) O.l(Pnk.strByAryOfRevB64W6BySAry(ar, O.ARY_A_Z));

		O.l("total=" + O.eq(ar.length, Pnk.int64(n, k)) + " costT=" + costT);

	}
}
