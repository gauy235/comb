package lgpl3.comb;

import lgpl3.o.O;
import lgpl3.o.keyNV.KArV32;

/**
 * 排列.<br/>
 *
 * @version 2023/11/07_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Pnk" >src</a>
 *
 * @see PByToInEx
 * @see PWBlank
 */
public abstract class Pnk extends Pnk_Z {

	/**
	 * If passes test.
	 */
	public static void test() {

		long ans;

		KArV32 kArV32;

		for (int n = 11, k; n != 0; n--) for (k = n; k != 0; k--) {

			ans = O.eq(colRecur(n, k).length, int64(n, k));

			O.eq(colByLoopBreadth(n, k).length, ans);

			colRecurWNGteK(~(-0b1 << n), 0b0L, (kArV32 = new KArV32(int64(n, k))), k);

			O.eq(kArV32.v, ans);

		}
	}
}
