package lgpl3.comb.wDup;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.wDup.DatWDup_A.DEF_DIV32;

import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;

/**
 * @version 2023/11/11_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=PWDup_U" >src</a>
 *
 * @see PWDup_V
 */
public abstract class PWDup_U extends PWDup_A { // private static final Class<?> THIS = PWDup_U.class;

	public static DatWDup dat;

	/**
	 * Log2 then divide.<br/>
	 */
	public static int logNDiv(long v) {

		return B64va.log2(v) / DEF_DIV32;
	}

	/**
	 * To convert.<br/>
	 */
	public static String strQ(int v32) {

		return (v32 == -1) ? O.S64 : dat.distSortedSAry[v32];
	}

	/**
	 * To convert.<br/>
	 */
	public static StringBuilder conv(long b64As2Pow) {

		StringBuilder ret = new StringBuilder();

		if (b64As2Pow == 0b0L) return ret;

		long low1;

		do if ((low1 = -b64As2Pow & b64As2Pow) == b64As2Pow) return ret.append(dat.distSortedSAry[logNDiv(low1)]);

		else ret.append(dat.distSortedSAry[logNDiv(low1)]).append(O.C44);

		while ((b64As2Pow &= ~low1) != 0b0L);

		throw new IllegalArgumentException();
	}

	public static void p(long rmdB64, int rmdK, long prefix, Seq retSeq, int lv) {

		long low1 = (-rmdB64 & rmdB64), pre;

		int oldQ = -1, newQ = logNDiv(low1);

		prefix <<= $6;

		if (rmdK-- == 1) {

			if (newQ != oldQ) {

				pre = prefix | (newQ + 1); // 記得 plus 1

				O.lv(lv, "prefix=" + B64W6.strByVCellMinus1AftRevBySAry(pre, dat.distSortedSAry));

				retSeq.a(pre);
			}

			return;
		}

		if (Long.bitCount(rmdB64) < rmdK) return;

		rmdB64 &= ~low1;

		do {
			O.lv(lv, "top rmdB64=" + strQ(newQ) + "_" + conv(rmdB64) + " :" + strQ(oldQ));

			if (newQ != oldQ) {

				oldQ = newQ;

				pre = prefix | (newQ + 1); // plus 1

				O.lv(lv, "pre=" + B64W6.strByVCellMinus1AftRevBySAry(pre, dat.distSortedSAry));

				if (rmdK == 0) {

					O.lv(lv, "add=" + B64W6.strByVCellMinus1AftRevBySAry(pre, dat.distSortedSAry));

					retSeq.a(pre);

					continue;
				}

				if (rmdB64 == 0b0L || Long.bitCount(rmdB64) < rmdK) {

					O.lv(lv, "kick bitCnt=" + Long.bitCount(rmdB64) + " k=" + rmdK + " pre="

							+ B64W6.strByVCellMinus1AftRevBySAry(pre, dat.distSortedSAry));

					return;
				}

				p(rmdB64, rmdK, pre, retSeq, lv);

			} else O.lv(lv, "<===");

		} while (rmdB64 != 0b0L);
	}
}
