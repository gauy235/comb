package lgpl3.recycle;

import lgpl3.o.O;

/**
 * count 反向數.<br/>
 * T(n) = O(n) 的演算法被稱作"線性時間演算法".
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_CountOfInv" >src</a>
 *
 */
public class Zw_CountOfInv {

	public static int countOfInv(int[] ar, int i, int j) {

		O.l("i=" + i + " j=" + j, Zw_CountOfInv.class);

		if (j == ar.length) return 0; // j >= ary.length

		if (i < j && ar[i] > ar[j]) return 1 + countOfInv(ar, i, j + 1);

		else return countOfInv(ar, i, j + 1);
	}

	public static void main(String[] sAry) {

		int ar[] = { 30, 10, 20, 40 }, count = 0;

		for (int start = 0; start < ar.length; start++) {

			O.l("start=" + start);

			count += countOfInv(ar, start, start + 1);

		}

		O.l("ans=" + count);

	}
}