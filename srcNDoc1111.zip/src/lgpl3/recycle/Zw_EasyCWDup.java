package lgpl3.recycle;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.wDup.DatWDup_A.DEF_DIV32;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.comb.wDup.sample.Ex704_Hxy;
import lgpl3.comb.wDup.thr.ThrToCWDup;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.ary.Seq;
import lgpl3.shareWXyz.HxyVal;

/**
 * CWDup<br/>
 * CWDup
 *
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_EasyCWDup" >src</a>
 *
 * @see Ex704_Hxy
 */
public class Zw_EasyCWDup { // private static final Class<?> THIS = Zw_EasyCWDup.class;

	public static DatWDup dat;

	/**
	 * Log2 then divide.<br/>
	 */
	public static int logNDiv(long v) {

		return B64va.log2(v) / DEF_DIV32;
	}

	/**
	 * To convert.<br/>
	 */
	public static String strQ(int v32) {

		return (v32 == -1) ? O.S64 : dat.distSortedSAry[v32];
	}

	/**
	 * To convert.<br/>
	 */
	public static StringBuilder conv(long b64As2Pow) {

		StringBuilder ret = new StringBuilder();

		if (b64As2Pow == 0b0L) return ret;

		long low1;

		do if ((low1 = -b64As2Pow & b64As2Pow) == b64As2Pow)

			return ret.append(dat.distSortedSAry[logNDiv(low1)]);

		else ret.append(dat.distSortedSAry[logNDiv(low1)]).append(O.C44);

		while ((b64As2Pow &= ~low1) != 0b0L);

		throw new IllegalArgumentException();
	}

	/**
	 * 從 1 列全相異數列中取出 k 個數.
	 *
	 * @see ThrToCWDup #reGo(long, long)
	 * @see B32va #next1BitL(int, int)
	 */
	public static void cWDup(long rmdB64, int k, long prefix, Seq retSeq, int lv) {

		B.cnt++;

		--k;
		++lv;

		long low1, pre;

		int oldQ = -1, newQ;

		prefix <<= $6;
		do {
			newQ = logNDiv(low1 = -rmdB64 & rmdB64);

			rmdB64 &= ~low1;

			O.lv(lv, "top rmdB64=" + strQ(newQ) + "_" + conv(rmdB64) + " :" + strQ(oldQ));

			if (newQ != oldQ) {

				oldQ = newQ;

				pre = prefix | (newQ + 1); // plus 1

				O.lv(lv, "pre=" + B64W6.strByVCellMinus1AftRevBySAry(pre, dat.distSortedSAry));

				if (k == 0) {

					O.lv(lv, "add=" + B64W6.strByVCellMinus1AftRevBySAry(pre, dat.distSortedSAry));

					retSeq.a(pre);

					continue;
				}

				if (rmdB64 == 0b0L || Long.bitCount(rmdB64) < k) {

					O.lv(lv, "kick bitCnt=" + Long.bitCount(rmdB64) + " k=" + k + " pre="

							+ B64W6.strByVCellMinus1AftRevBySAry(pre, dat.distSortedSAry));

					return;
				}

				cWDup(rmdB64, k, pre, retSeq, lv);

			} else O.lv(lv, "<===");

		} while (rmdB64 != 0b0L);
	}

	/**
	 * CWDup<br/>
	 */
	public static DatWDup cWDup(String s, int k) {

		dat = new DatWDup();

		dat.oriS = s;
		dat.k = k;

		dat.initAll();

		Seq seq = new Seq();

		cWDup(dat.b64OfQRCell, k, 0b0L, seq, 0);

		dat.tmpObj = seq.trim().ary;

		return dat;
	}

	public static void main(String[] sAry) throws Throwable {

		// String s = "A,B,B,C,C,C";
		String s = "A,B,B,D,E";

		int k = 3;

		cWDup(s, k);

		long arOfB64W6[] = (long[]) dat.tmpObj, b64W6,

				ans = HxyVal.int64WLim0ToMax(dat.k, dat.sortByCntDistSAry.length, dat.b64W6OfQtyPlus1Desc);

		arOfB64W6 = Aryva.checkDup(arOfB64W6);

		for (int idx = 0; idx != arOfB64W6.length; idx++) {

			b64W6 = arOfB64W6[idx];

			O.l((idx + 1) + "=" + B64W6.strByVCellMinus1AftRevBySAry(b64W6, dat.distSortedSAry) + " " + B64W6.str24(b64W6));

		}

		O.l("len=" + O.eq(arOfB64W6.length, ans));

	}
}