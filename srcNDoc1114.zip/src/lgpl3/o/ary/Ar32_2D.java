package lgpl3.o.ary;

import lgpl3.o.B;
import lgpl3.o.O;

/**
 * The wrapper for int[][]<br/>
 *
 * @version 2023/10/27_09:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ar32_2D" >src</a>
 *
 * @see Ary2D
 */
public class Ar32_2D extends Arr<int[]> {

	private static final Class<?> THIS = Ar32_2D.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * 質數隊伍的建構方法.<br/>
	 * The constructor.
	 */
	public Ar32_2D() {

		super(int[].class);
	}

	/**
	 * 質數隊伍的建構方法.<br/>
	 * The constructor.
	 */
	public Ar32_2D(int[][] aryOfAr32) {

		super(aryOfAr32);
	}

//	/**
//	 * 加 all 個項到此伍末之後.<br/>
//	 * To append the all to after the iLen of this.
//	 */
//	public void appendAll(Ar32_2D otherAr32_2D) { // appendAll(int[][]) 有爭議
//
//		int lenPlusOtherLen = iLen + otherAr32_2D.iLen;
//
//		if (lenPlusOtherLen >= baseLen)
//
//			extLen(lenPlusOtherLen);
//
//		System.arraycopy(otherAr32_2D.ar, 0, ar, iLen, otherAr32_2D.iLen);
//
//		iLen = lenPlusOtherLen;
//
//		for (int idx = 0; idx != iLen; idx++)
//
//			O.l("idx " + idx + "=" + ar[idx]);
//
//	}

	/**
	 * To fill.<br/>
	 */
	public static int[][] fill(int[][] ar32_2D, int v32) {

		for (int ar[], iBig = 0, iSmall; iBig != ar32_2D.length; iBig++) {

			ar = ar32_2D[iBig];

			for (iSmall = 0; iSmall != ar.length; iSmall++) ar[iSmall] = v32;
		}

		O.l("fill=" + O.L + Ar32_2D.toStr(ar32_2D) + O.L + O.S64 + THIS);

		return ar32_2D;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder toStr(int[][] ar32_2D) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		for (int iBig = 0, ar[], iSmall; iBig != ar32_2D.length;) {

			ar = ar32_2D[iBig++];

			for (iSmall = 0; iSmall != ar.length;) {

				ret.append(ar[iSmall]);

				if (++iSmall != ar.length) ret.append(O.STR_C44C32);

			}

			if (iBig != ar32_2D.length) ret.append(O.C_A_L);

		}

		return ret;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	@Override
	public StringBuilder toStr() {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		for (int iBig = 0, ar32[], iSmall; iBig != i;) {

			ar32 = ar[iBig++];

			for (iSmall = 0; iSmall != ar32.length;) {

				ret.append(ar32[iSmall]);

				if (++iSmall != ar32.length) ret.append(O.STR_C44C32);

			}

			if (iBig != i) ret.append(O.C_A_L); // O.l("ar.len=" + ar.length, THIS);

		}

		return ret;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder toMatrixStr(int[][] ar32_2D) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		for (int iBig = 1, ar[], iSmall, v32; iBig != ar32_2D.length;) {

			ar = ar32_2D[iBig++];

			for (iSmall = 1; iSmall != ar.length;) {

				ret.append((v32 = ar[iSmall++]) == 0 ? O.S48 : Integer.toString(v32));

				if (iSmall != ar.length) ret.append(O.STR_C44C32);

			}

			if (iBig != ar32_2D.length) ret.append(O.C_A_L);

		}

		return ret;
	}
}
