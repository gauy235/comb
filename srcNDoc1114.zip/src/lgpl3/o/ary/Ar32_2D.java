package lgpl3.o.ary;

import lgpl3.o.B;
import lgpl3.o.O;

/**
 * The wrapper for int[][]<br/>
 * The wrapper for int[][]
 *
 * @version 2022/03/27_09:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ar32_2D" >src</a>
 *
 * @see Ary2D
 */
public class Ar32_2D extends Arr<int[]> {

	private static final Class<?> THIS = Ar32_2D.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * 質數隊伍的建構方法.<br/>
	 * The constructor.
	 */
	public Ar32_2D() {

		super(int[].class);
	}

	/**
	 * 質數隊伍的建構方法.<br/>
	 * The constructor.
	 */
	public Ar32_2D(int[][] aryOfAr32) {

		super(aryOfAr32);
	}

//	/**
//	 * 加 all 個項到此伍末之後.<br/>
//	 * To append the all to after the iLen of this.
//	 */
//	public void appendAll(Ar32_2D otherAr32_2D) { // appendAll(int[][]) 有爭議
//
//		int lenPlusOtherLen = iLen + otherAr32_2D.iLen;
//
//		if (lenPlusOtherLen >= baseLen)
//
//			extLen(lenPlusOtherLen);
//
//		System.arraycopy(otherAr32_2D.arr, 0, ar, iLen, otherAr32_2D.iLen);
//
//		iLen = lenPlusOtherLen;
//
//		for (int idx = 0; idx != iLen; idx++)
//
//			O.l("idx " + idx + "=" + ar[idx]);
//
//	}

	/**
	 * To fill.<br/>
	 * To fill.
	 */
	public static int[][] fill(int[][] ar32_2D, int v32) {

		int iBig, iSmall;
		int[] ar32;

		for (iBig = 0; iBig != ar32_2D.length; iBig++) {

			ar32 = ar32_2D[iBig];

			for (iSmall = 0; iSmall != ar32.length; iSmall++)

				ar32[iSmall] = v32;

		}

		O.l("fill=" + O.L + Ar32_2D.toStr(ar32_2D) + O.L + O.S64 + THIS);

		return ar32_2D;

	}

	/**
	 * To StringBuilder.<br/>
	 * To StringBuilder.
	 */
	@Override
	public StringBuilder toStr() {

		StringBuilder retStr = new StringBuilder(O.defLenForStr);

		int iBig, ar32[], iSmall;

		for (iBig = 0; iBig != i;) {

			ar32 = ar[iBig++];

			for (iSmall = 0; iSmall != ar32.length;) {

				retStr.append(ar32[iSmall++]);

				if (iSmall != ar32.length)

					retStr.append(O.STR_C44C32);

			}

			// O.l("ar.length=" + ar.length, THIS);

			if (iBig != i)

				retStr.append(O.C_A_L);

		}

		return retStr;

	}

	/**
	 * To StringBuilder.<br/>
	 * To StringBuilder.
	 */
	public static StringBuilder toStr(int[][] ar32_2D) {

		StringBuilder retStr = new StringBuilder(O.defLenForStr);

		int iBig, ar32[], iSmall;

		for (iBig = 0; iBig != ar32_2D.length;) {

			ar32 = ar32_2D[iBig++];

			for (iSmall = 0; iSmall != ar32.length;) {

				retStr.append(ar32[iSmall++]);

				if (iSmall != ar32.length)

					retStr.append(O.STR_C44C32);

			}

			if (iBig != ar32_2D.length)

				retStr.append(O.C_A_L);

		}

		return retStr;

	}

	/**
	 * To StringBuilder.<br/>
	 * To StringBuilder.
	 */
	public static StringBuilder toMatrixStr(int[][] ar32_2D) {

		StringBuilder retStr = new StringBuilder(O.defLenForStr);

		int iBig, ar32[], iSmall, v32;

		for (iBig = 1; iBig != ar32_2D.length;) {

			ar32 = ar32_2D[iBig++];

			for (iSmall = 1; iSmall != ar32.length;) {

				retStr.append((v32 = ar32[iSmall++]) == 0 ? O.C48 : (char) (64 + v32));

				if (iSmall != ar32.length)

					retStr.append(O.STR_C44C32);

			}

			if (iBig != ar32_2D.length)

				retStr.append(O.C_A_L);

		}

		return retStr;

	}
}
