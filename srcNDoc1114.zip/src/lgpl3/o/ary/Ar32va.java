package lgpl3.o.ary;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * 本類別是使用 32 位元的整數陣列.<br/>
 * The array of 32 bit integer.
 *
 * @version 2023/11/04_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ar32va" >src</a>
 *
 * @see Aryva
 */
public abstract class Ar32va extends Ar32va_U { // private static final Class<?> THIS = Ar32va.class;

	/**
	 * 奇數位置值跟偶數位置值抓出來互比, 大的放一組, 小的放另一組.<br/>
	 * 10 元素, 15 次比較.
	 */
	public static int[] findMinMax(int[] ar) { // Aryva 也要補上

		int min = ar[0], max = min, tmpV;

		for (int idx = 1; idx != ar.length; idx++)

			if ((tmpV = ar[idx]) > max) max = tmpV; // O.l("tmpV=" + tmpV);

			else if (tmpV < min) min = tmpV;

		return new int[] { min, max };
	}

	/**
	 * 奇數位置值跟偶數位置值抓出來互比, 大的放一組, 小的放另一組.<br/>
	 * 10 元素, 15 次比較.
	 */
	public static int[] findMinMaxByGroupEvenOdd(int[] ar) {

		int len = ar.length, lenDiv2 = (len >>> 1), idx, vEven, vOdd, aryMin[] = new int[lenDiv2],

				aryMax[] = new int[lenDiv2], newIdx, min, max;

		for (idx = 0; idx != lenDiv2; idx++)

			if ((vEven = ar[newIdx = idx << 1]) < (vOdd = ar[newIdx + 1])) { // O.l("newIdx=" + newIdx);

				aryMin[idx] = vEven;
				aryMax[idx] = vOdd;

			} else {

				aryMin[idx] = vOdd;
				aryMax[idx] = vEven;

			}

		min = aryMin[0];
		max = aryMax[0];

		for (idx = 1 /* 從 1 開始 */; idx != lenDiv2; idx++) {

			if ((vOdd = aryMin[idx]) < min) min = vOdd;

			if ((vOdd = aryMax[idx]) > max) max = vOdd;

		}

		if ((len & 0b1) != 0b0) // 當長度是 odd 檢查

			if ((vOdd = ar[len - 1]) < min) min = vOdd;

			else if (vOdd > max) max = vOdd;

		return new int[] { min, max };
	}

	/**
	 * 奇數位置值跟偶數位置值抓出來互比, 大的放一組, 小的放另一組.<br/>
	 * 10 元素, 15 次比較.
	 */
	public static int[] findMinMaxByCompaHeadTail(int[] ar) {

		int len = ar.length, lenDiv2 = (len >>> 1), idx, vHead, vTail, min = ar[0], max = ar[len - 1];

		if (max < min) max += min - (min = max); // swap

		if (len <= 2) return new int[] { min, max };

		//////////////////////////////////////////

		for (idx = 1; idx != lenDiv2; idx++)

			if ((vHead = ar[idx]) < (vTail = ar[len - 1 - idx])) {

				if (vHead < min) min = vHead;

				if (vTail > max) max = vTail;

			} else {

				if (vTail < min) min = vTail;

				if (vHead > max) max = vHead;

			}

		if ((len & 0b1) != 0b0) // 當長度是 odd 檢查

			if ((vTail = ar[lenDiv2]) < min) min = vTail;

			else if (vTail > max) max = vTail;

		return new int[] { min, max };
	}

	/**
	 * To partition.<br/>
	 */
	public static int easyPartiNRetIdxOfPivot(int[] ar, int left, int right) {

		int iCnt = left, pivot = ar[left]; // 陣列頭當 pivot

		for (int j = left + 1; j <= right; j++) if ((ar[j] < pivot) && (++iCnt != j)) swapV(ar, iCnt, j); // 小的排在我左邊

		swapV(ar, left, iCnt); // 最後 跟 那群小朋友的尾巴 交換

		return iCnt;
	}

	/**
	 * To partition.<br/>
	 */
	public static int partiNRetIdxOfPivot(int[] ar, int left, int right) {

		// i as count
		int i = left, pivot = ar[left]; // 陣列頭當 pivot

		O.l("pivot=ar[" + i + "]=" + pivot);

		for (int j = left + 1; j <= right; j++)

			if (ar[j] < pivot /* && (++i != j) */) { // todo: 小於還是小於等於

				i++; // the count plus 1

				swapV(ar, i, j); // 小的排在我左邊

				O.l("swap " + ar[i] + " " + ar[j]);

			}

		///////////////////////////////////////////////////

		swapV(ar, left, i); // 最後 跟 那群小朋友的尾巴 交換

		O.l("endRound=>" + Arrays.toString(ar));

		return i; // i as count
	}

	/**
	 * The k-th smallest.<br/>
	 */
	public static int k_thSmall(int[] ar, int k_th) {

		int left = 0, right = (ar.length - 1), iPivot;

		while (left <= right) { // while (left < right)

			if ((iPivot = Ar32va.partiNRetIdxOfPivot(ar, left, right)) == k_th) return ar[iPivot];

			if (iPivot > k_th) right = iPivot - 1;

			else left = iPivot + 1;

		}

		throw new RuntimeException("left=" + left + " right=" + right);
	}

	/**
	 * count 反向數.<br/>
	 */
	public static int countPInversionInRow(int[] ar, int from) {

		int ret = 0;

		for (int to = from + 1; to < ar.length; to++) if (ar[from] > ar[to]) ret++;

		O.l("from=" + from + " subtotal=" + ret);

		return ret;
	}

	/**
	 * count 反向數.<br/>
	 */
	public static int countPInversion(int[] ar) {

		int ret = 0;

		for (int from = 0; from < ar.length; from++) ret += countPInversionInRow(ar, from);

		return ret;
	}
}