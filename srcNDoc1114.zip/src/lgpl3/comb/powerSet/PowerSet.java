package lgpl3.comb.powerSet;

import static java.lang.System.out;

import lgpl3.b32.B32va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.selfCallva.SelfCallva;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32_2D;
import lgpl3.o.ary.Seq32;

/**
 * @version 2022/11/30_01:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=PowerSet" >src</a>
 *
 * @see SelfCallva
 */
public abstract class PowerSet extends PowerSet_A {

	private static final Class<?> THIS = PowerSet.class;

	/**
	 * To gen all subset.<br/>
	 * 100 個元素, 2^100 電腦當掉.
	 */
	public static void easyPrintByInt32(final int[] baseAr32, int curIdx, int prefix) { // 1234 = 1000+200+30+4 阿 Q

		if (curIdx == (baseAr32.length - 1)) { // Z 軸延伸 垂直紙面

			out.println(prefix + baseAr32[curIdx]);
			out.println(prefix);

			return;

		}

		easyPrintByInt32(baseAr32, (curIdx + 1), (prefix + baseAr32[curIdx])); // 問取不取? 取
		easyPrintByInt32(baseAr32, (curIdx + 1), prefix); // 問取不取? 不取

	}

	/**
	 * To gen all subset.<br/>
	 * 100 個元素, 2^100 電腦當掉.
	 */
	public static void easyByBit(int prefix, int nAsLv) { // Z 軸延伸 垂直紙面

		if (--nAsLv == 0) {

			out.println(B32va.strByLog2LowestBitBySAry(prefix | (0b1 << nAsLv), O.ARY_A_Z));
			out.println(B32va.strByLog2LowestBitBySAry(prefix, O.ARY_A_Z));

			return;

		}

		easyByBit(prefix | (0b1 << nAsLv), nAsLv); // 問取不取? 取
		easyByBit(prefix, nAsLv); // 問取不取? 不取

	}

	/**
	 * To StringBuilder.
	 */
	public static StringBuilder toStrByAr32(int[] ar32, int endIdx) {

		StringBuilder str = new StringBuilder(O.defLenForStr);

		str.append(O.C91);

		for (int idx = 0; idx != endIdx;) {

			str.append(ar32[idx]);

			if (++idx != endIdx) str.append(O.C44);

		}

		return str.append(O.C93);

	}

	/**
	 * To gen all subset.
	 *
	 * @see #colFromNone(int[], int, Seq32, Ar32_2D, int)
	 */
	public static void printBySeq32(int[] baseAr32, Seq32 prefix, int idx, int lv) { // 原創

		B.cnt++;

		O.lv(++lv, "subset= " + prefix.toStr()); // 先印出來 要不然之後會繼續長尾巴

		if (idx == baseAr32.length) return; // 終止條件

		for (; idx != baseAr32.length; idx++)

			if (idx + 1 < baseAr32.length) printBySeq32(baseAr32, prefix.cNA(baseAr32[idx]), idx + 1, lv);

			else printBySeq32(baseAr32, prefix.a(baseAr32[idx]), idx + 1, lv);

	}

	/**
	 * To gen all subset.
	 *
	 * @see #colFromNone(int[], int, Seq32, Ar32_2D, int)
	 */
	public static void printByB64W6(int[] baseAr32, long prefix, int idx, int lv) { // 原創

		B.cnt++;

		lv++;

		O.lv(lv, "idx=" + idx + " [" + B64W6.strByVCellAftRev(prefix) + "]"); // 先印出來 要不然之後會繼續長尾巴

		if (idx == baseAr32.length) return; // 終止條件

		for (; idx != baseAr32.length;)

			printByB64W6(baseAr32, ((prefix << B64W6.$6) | baseAr32[idx]), idx += 1, lv); // 到下一層去

	}

	/**
	 * To gen all subset.
	 */
	public static void printInAr32(int[] baseAr32, int[] prefix, int idx, int endOfPrint, int lv) {

		B.cnt++;

		lv++;

		// 終止條件 先秀空集合
		// O.lv(lv, Arrays.toString(prefix) + " idx=" + idx + " end=" + endOfPrint + " " + toStrByAr32(prefix, endOfPrint)

		// + " fin");

		O.l(toStrByAr32(prefix, endOfPrint));

		for (; idx != baseAr32.length; idx++) {

			// O.lv(lv, "prefix[" + endOfPrint + "]=" + baseAr32[idx]);

			prefix[endOfPrint] = baseAr32[idx]; // 從原本秀 1 開頭, 變成秀 2 開頭, 秀 3 開頭

			printInAr32(baseAr32, prefix, idx + 1, endOfPrint + 1, lv);

		}
	}
}
