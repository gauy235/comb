package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;
import lgpl3.shuffle.Shuffler;

/**
 * k-thSmall.<br/>
 * k-thSmall.
 *
 * @version 2022/12/26_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_K_thSmall" >src</a>
 *
 */
public class Zw_K_thSmall {

	public static void main(String[] sAry) {

		int[] ar = { 20, 30, 50, 80, 90 };
		int k_th = 3;

		ar = Shuffler.shuffle(ar);

		O.l("bef=");
		O.l(Arrays.toString(ar));

		int k_thSmall = Ar32va.k_thSmall(ar, k_th);

		O.l(k_th + "-thSmall=" + k_thSmall);

		// O.l(O.Z + k_thSmall(ar, ar.length / 2));

	}
}