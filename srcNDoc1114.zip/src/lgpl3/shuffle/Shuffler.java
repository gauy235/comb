package lgpl3.shuffle;

import java.util.concurrent.ThreadLocalRandom;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.ary.Ar32va;

/**
 * To shuffle the array.<br/>
 * To shuffle the array.
 *
 * @version 2022/06/25_10:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Shuffler" >src</a>
 *
 */
public abstract class Shuffler extends Shuffler_B {

	// private static final Class<?> THIS = Shuffler.class;

	/**
	 * To shuffle then to pick.
	 */
	// ar.length 最大長度 64, every ar[i] 最大值 63, k 最大長度 10
	public static long pickKNRetB64W6(int[] ary32, int k) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int idx, lenMul8 = (ary32.length << 3); // 寬鬆

		long tmp, kept = 0b0L, ret = 0b0L;

		do {
			idx = rnd.nextInt(lenMul8) >>> 3;
			tmp = (0b1L << idx);

			if ((tmp & kept) != 0b0L) // O.l("tmp=" + tmp, THIS);

				continue;

			ret <<= B64W6.$6;
			ret |= ary32[idx]; // 好像 不可簡寫在同一列 如 swapByXor

			if (Long.bitCount(kept |= tmp) == k)

				break;

		} while (B.T);

		return ret;

	}

	/**
	 * To shuffle then to pick.
	 */
	// every ary32[i] 最大值 63 and k 最大長度 10
	public static long pickKNRetB64W6(int[] sortedAr32, int k, int[] exSortedAr32) {

		return pickKNRetB64W6(Ar32va.ex(sortedAr32, exSortedAr32), k);
	}

	/**
	 * To shuffle then to pick.<br/>
	 * To shuffle then to pick.
	 */
	public static int[] pickK(int[] ary32, int k) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int idx, lenMul8 = (ary32.length << 3) /* 寬鬆 */, ret[] = new int[k], iRet = 0;

		long tmp, kept = 0b0L;

		do {
			idx = rnd.nextInt(lenMul8) >>> 3;
			tmp = (0b1L << idx);

			if ((tmp & kept) != 0b0L) // O.l("tmp=" + tmp, THIS);

				continue;

			ret[iRet++] = ary32[idx];

			if (Long.bitCount(kept |= tmp) == k)

				break;

		} while (B.T);

		return ret;

	}

	/**
	 * To shuffle then to pick.<br/>
	 * To shuffle then to pick.
	 */
	public static String[] pickK(String[] sAry, int k) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int idx, lenMul8 = (sAry.length << 3) /* 寬鬆 */, iRet = 0;

		long tmp, kept = 0b0L;

		String[] ret = new String[k];

		do {
			idx = rnd.nextInt(lenMul8) >>> 3;
			tmp = (0b1L << idx);

			if ((tmp & kept) != 0b0L) // O.l("tmp=" + tmp, THIS);

				continue;

			ret[iRet++] = sAry[idx];

			if (Long.bitCount(kept |= tmp) == k)

				break;

		} while (B.T);

		return ret;

	}
}
