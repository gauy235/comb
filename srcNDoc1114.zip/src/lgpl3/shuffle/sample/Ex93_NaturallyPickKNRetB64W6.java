package lgpl3.shuffle.sample;

import java.util.Enumeration;
import java.util.Hashtable;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;
import lgpl3.shuffle.Shuffler;

/**
 * 排列的實驗法及逼近法<br/>
 * <br/>
 *
 * 排列 [A,B,C]<br/>
 * <br/>
 * 1. 取數列的子集合 <br/>
 * 2. 放入容器以過濾重複<br/>
 * <br/>
 *
 * 部份相同物排列 [A,A,B]<br/>
 * <br/>
 * 1. 取數列的子集合<br/>
 * 2. 放入容器以過濾重複<br/>
 * <br/>
 *
 * 組合 (取物) [A,B,C]<br/>
 * <br/>
 * 1. 取數列的子集合<br/>
 * 2. 排序<br/>
 * 3. 放入容器以過濾重複<br/>
 * <br/>
 *
 * 部份相同物組合 (取物) [A,A,B]<br/>
 * <br/>
 * 1. 取數列的子集合<br/>
 * 2. 排序<br/>
 * 3. 放入容器以過濾重複<br/>
 *
 * @version 2022/07/07_00:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex93_NaturallyPickKNRetB64W6" >src</a>
 *
 */
public class Ex93_NaturallyPickKNRetB64W6 {

	public static void main(String[] sAry) throws Throwable {

		int ary32[] = { 10, 15, 20, 25, 30, 30, 30 };

		int k = 5; // 最後 ret 用 b32 不可取超過 5 個

		int nOfTest = 200;

		Hashtable<Long, Object> filter = new Hashtable<>();
		do
			filter.put(Shuffler.pickKNRetB64W6(ary32, k), filter);

		while (--nOfTest != 0);

		int[] ret = new int[filter.size()];

		for (Enumeration<Long> allKey = filter.keys(); allKey.hasMoreElements();)

			ret[nOfTest++] = (int) ((long) allKey.nextElement());

		Ar32va.sortNCheckDup(ret);

		for (; nOfTest != 0;)

			O.l(B64W6.strByVCellAftRev(ret[--nOfTest]));

		O.l("total=" + ret.length);

	}
}