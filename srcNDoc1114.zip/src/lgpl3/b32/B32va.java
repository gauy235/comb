package lgpl3.b32;

import static java.lang.System.out;

import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;

/**
 * 本類別是使用 2 進位.<br/>
 * The 2 bit digit.
 *
 * @version 2022/05/26_11:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B32va" >src</a>
 *
 * @see Ar32va
 */
public abstract class B32va extends B32va_V {

	private static final Class<?> THIS = B32va.class;

	/**
	 * 分配下去.<br/>
	 */
	public static int[] distributeOver1Ar32(int b32As2Pow) {

		int ret[] = new int[Integer.bitCount(b32As2Pow)], idx = 0, lowest1;
		do
			ret[idx++] = lowest1 = (-b32As2Pow & b32As2Pow); // 連用 2 個等號

		while ((b32As2Pow = (~lowest1 & b32As2Pow)) != 0b0);

		return ret;

	}

//	/**
//	 * To B32.<br/>
//	 */
//	public static int toB32As2PowByAryOfB32As2Pow(int[] ary32) {
//
//		int b32As2Pow = ary32[0];
//
//		for (int idx = 1; idx != ary32.length; idx++)
//
//			b32As2Pow |= ary32[idx];
//
//		return b32As2Pow;
//
//	}

	/**
	 * 回傳 2 進位字串建立者.<br/>
	 * To StringBuilder of 2 bit digit.
	 */
	public static StringBuilder str16(int int32) {

		int len = 19, idx = len, iUd = 0; // underline

		char[] cAr = new char[len];

		while (idx-- != 0)

			cAr[idx] = O.C48;

		idx = len - 1;

		do {
			if ((int32 & 0b1) != 0b0) cAr[idx] = O.C49;

			if (++iUd == 4 || iUd == 8 || iUd == 12) cAr[--idx] = O.C95;

			int32 >>>= 1; // O.l("iUnder=" + iUnder, THIS);

		} while (idx-- != 0);

		// O.l("int32=" + Integer.toBinaryString(int32), THIS);

		return new StringBuilder(len).append(cAr);

	}

	/**
	 * 回傳 2 進位字串建立者.<br/>
	 * To StringBuilder of 2 bit digit.
	 */
	public static StringBuilder str(int int32) {

		int len = 39, idx = len, iUd = 0; // underline

		char[] cAr = new char[len];

		while (idx-- != 0)

			cAr[idx] = O.C48;

		idx = len - 1;
		do {
			if ((int32 & 0b1) != 0b0) cAr[idx] = O.C49;

			if (++iUd == 4 || iUd == 8 || iUd == 12 || iUd == 16 || iUd == 20 || iUd == 24 || iUd == 28) cAr[--idx] = O.C95;

			int32 >>>= 1; // O.l("iUd=" + iUd, THIS);

		} while (idx-- != 0);

		return new StringBuilder(len).append(cAr); // O.l("int32=" + Integer.toBinaryString(int32), THIS);

	}

	/**
	 * To StringBuilder from String array via bit32.<br/>
	 */
	public static StringBuilder strByLog2HighestBitBySAry(int b32As2Pow, String[] sAry) {

		StringBuilder ret = new StringBuilder(O.defLenForStr); // O.l(sAry);

		if (b32As2Pow == 0b0) return ret;

		int hi1;
		do
			if ((hi1 = highest1(b32As2Pow)) == b32As2Pow) return ret.append(sAry[log2(hi1)]);

			else ret.append(sAry[log2(hi1)]).append(O.C44);

		while ((b32As2Pow = (~hi1 & b32As2Pow)) != 0b0);

		throw new IllegalArgumentException("b32As2Pow=" + str(b32As2Pow));

	}

	/**
	 * To StringBuilder from String array via bit32.<br/>
	 */
	public static StringBuilder strByLog2LowestBitBySAry(int b32As2Pow, String[] sAry) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		if (b32As2Pow == 0b0) return ret;

		int low1;
		do
			if ((low1 = (-b32As2Pow & b32As2Pow)) == b32As2Pow) return ret.append(sAry[log2(low1)]);

			else ret.append(sAry[log2(low1)]).append(O.C44);

		while ((b32As2Pow = (~low1 & b32As2Pow)) != 0b0);

		throw new IllegalArgumentException("b32As2Pow=" + str(b32As2Pow));

	}

	/**
	 * 印出文字.<br/>
	 * To print line.
	 */
	public static int lv(int lv, CharSequence charSeq, int int32) { // min lv is 1 // 原創

		StringBuilder str = new StringBuilder(O.defLenForStr);

		for (int count = lv; --count != 0;)

			str.append(O.strAsIndent);

		str.append(lv).append(O.C32).append(charSeq);

		out.println(str.append(strByLog2LowestBitBySAry(int32, O.ARY_A_Z)));

		return lv;

	}
}