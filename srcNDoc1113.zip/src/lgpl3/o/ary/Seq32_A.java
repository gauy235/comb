package lgpl3.o.ary;

import java.io.Serializable;
import java.util.Arrays;

import lgpl3.b32.B32va;
import lgpl3.o.B;
import lgpl3.o.O;

/**
 * 32 位元整數伍.<br/>
 * The int32 sequence.
 *
 * @version 2022/04/23_22:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Seq32_A" >Seq32_A.java</a>
 *
 * @see Seq32
 */
public abstract class Seq32_A implements Serializable {

	private static final Class<?> THIS = Seq32_A.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * 內部陣列.<br/>
	 * The inside array.
	 */
	public int[] ar;

	/**
	 * 內部陣列長度.<br/>
	 * The length of the inside array.
	 */
	public int fixedLen; // todo: change to baseLen

	/**
	 * 內部陣列的最末項的後 1 個位置.<br/>
	 * The position after the last element of the inside array.
	 */
	public int i; // index, length

	/**
	 * 用於多執行緒的同步.<br/>
	 * For synchronizing.
	 */
	public final Object keyToSyn = new Object();

	/**
	 * 確保不會 IndexOutOfBoundsException.<br/>
	 * To extend the length of inside array and to avoid the IndexOutOfBoundsException.<br/>
	 */
	public void extLen() {

		final int oldLen = fixedLen;

		if (O.isDev)

			O.l("oldLen=" + oldLen + " extLen=" + B32va.str((oldLen << 1) | oldLen), THIS);

		System.arraycopy(ar, 0, (ar = new int[fixedLen = (fixedLen << 1) | fixedLen]), 0, oldLen);

	}

	/**
	 * 確保不會 IndexOutOfBoundsException.<br/>
	 * To extend the length of inside array and to avoid the IndexOutOfBoundsException.<br/>
	 */
	public void extLen(int newLen) {

		final int oldLen = fixedLen;

		do if ((fixedLen = ((fixedLen << 1) | fixedLen)) < 0b0)

			O.x();

		while (fixedLen < newLen);

		if (O.isDev)

			O.l("oldLen=" + oldLen + ", fixedLen=" + B32va.str(fixedLen), THIS);

		System.arraycopy(ar, 0, (ar = new int[fixedLen]), 0, oldLen);

	}

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	public Seq32_A(int[] ary32) {

		if (ary32 == null || (fixedLen = ary32.length) == 0)

			O.x();

		this.ar = ary32;

		if (fixedLen < Seq.DEF_LEN)

			extLen(Seq.DEF_LEN);

	}

	/**
	 * 縮減空間.<br/>
	 * To trim the inside array length to the number of elements.
	 */
	public Seq32_A trim() {

		if (i != fixedLen)

			System.arraycopy(ar, 0, (ar = new int[fixedLen = i]), 0, i);

		// if (O.isDev) O.l("trim=", THIS);

		return this;

	}

	/**
	 * To sort.<br/>
	 * To sort.
	 */
	public Seq32_A sort() {

		Arrays.sort(ar, 0, i);

		return this;

	}

	/**
	 * 陣列內元素位置顛倒.<br/>
	 * To reverse.
	 */
	public Seq32_A rev() {

		int idx = 0, lenDiv2 = (i >>> 1), lenMinus1 = (i - 1), tmp32;

		for (; idx != lenDiv2; idx++) {

			tmp32 = ar[idx];
			ar[idx] = ar[lenMinus1 - idx];
			ar[lenMinus1 - idx] = tmp32;

		}

		return this;

	}

	/**
	 * To StringBuilder.<br/>
	 * To StringBuilder.
	 */
	public StringBuilder toStr() {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		for (int idx = 0; idx != i;) {

			ret.append(ar[idx]);

			if (++idx != i)

				ret.append(O.C44);

		}

		return ret;

	}

	/**
	 * 取得第 0 個項.<br/>
	 * To return the 0-th element (head) of this.<br/>
	 * Not thread safe.<br/>
	 *
	 * @see #tail()
	 */
	public int head() {

		return ((i == 0) ? Integer.MIN_VALUE : ar[0]);
	}

	/**
	 * 取得第末個項.<br/>
	 * To return the last element (tail) of this.<br/>
	 * Not thread safe.<br/>
	 *
	 * @see #head()
	 */
	public int tail() {

		return ((i == 0) ? Integer.MIN_VALUE : ar[i - 1]);
	}

	/**
	 * 取得並移除第 0 個項.<br/>
	 * To return and to remove the first element (head) of this.
	 */
	public int cutHead() {

		if (i == 0)

			return Integer.MIN_VALUE; // fuck

		int head = ar[0];

		System.arraycopy(ar, 1, ar, 0, --i);

		// ary32[iLen + 1] = 0; // 不用寫

		return head;

	}

	/**
	 * 取得並移除第末個項.<br/>
	 * To return and to remove the last element (tail) of this.
	 */
	public int cutTail() { // O.xy(iLen, fixedLen); // O.l("ary32=" + ary32.length, THIS);

		return ((i == 0) ? Integer.MIN_VALUE : ar[--i]);
	}

	/**
	 * 取得此伍第 index 位置, 把其餘項往前移動.<br/>
	 * To cut the element to the idx-th position and return.
	 */
	public int cutAt(int idx) {

		if (idx >= i || idx < 0)

			return Integer.MIN_VALUE;

		int ret = ar[idx];

		if (--i > idx)

			System.arraycopy(ar, idx + 1, ar, idx, i - idx);

		return ret;

	}

	/**
	 * To sum.<br/>
	 * To sum.
	 */
	public long sum() {

		long ans = 0;

		for (int idx = 0; idx != i; idx++)

			ans += ar[idx];

		return ans;

	}
}
