package lgpl3.recycle;

import lgpl3.o.O;

/**
 * count 反向數.<br/>
 * T(n) = O(n) 的演算法被稱作"線性時間演算法".
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_CountOfInv" >src</a>
 *
 */
public class Zw_CountOfInv {

	public static int countOfInversionOld(int[] ar, int i, int j) {

		O.l("i=" + i + " j=" + j);

		if (j == ar.length) return 0; // j >= ar.length

		if (i < j && ar[i] > ar[j]) return 1 + countOfInversionOld(ar, i, j + 1);

		return countOfInversionOld(ar, i, j + 1);
	}

	public static int countOfInversion(int[] ar, int from) {

		int ret = 0;

		for (int to = from + 1; to < ar.length; to++) if (ar[from] > ar[to]) ret++;

		O.l("from=" + from + " subtotal=" + ret);

		return ret;
	}

	public static int countOfInversionBig(int[] ar) {

		int ret = 0;

		for (int from = 0; from < ar.length; from++) ret += countOfInversion(ar, from);

		return ret;
	}

	public static void main(String[] sAry) {

		int ar[] = { 50, 140, 30, 10 }, cnt = 0;

		for (int from = 0; from != ar.length; from++) {

			O.l("from=" + from);

			cnt += countOfInversionOld(ar, from, from + 1);
		}

		O.l("total=" + O.eq(cnt, countOfInversionBig(ar)));

	}
}