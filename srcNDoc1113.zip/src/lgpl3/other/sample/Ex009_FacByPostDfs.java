package lgpl3.other.sample;

import lgpl3.comb.Pnk;
import lgpl3.o.O;

/**
 * 排列使用遞迴累加 recurSum recurCount.<br/>
 * 土法煉鋼.
 *
 * @version 2023/11/11_21:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex009_FacByPostDfs" >src</a>
 *
 * @see Ex010_FacByCount
 */
public class Ex009_FacByPostDfs { // 後序法 深先

	public static void main(String[] sAry) throws Throwable {

		int n = 4;

		long cnt = Pnk.recurCount(n);

		O.l(n + "!=recurCount(" + n + ")=" + cnt);

		cnt = Pnk.recurCountByMul(n, 0L);

		O.l(n + "!=recurCount(" + n + ")=" + cnt);

		cnt = Pnk.recurCountBySum(n, 0L);

		O.l(n + "!=recurCountNew(" + n + ")=" + cnt);
	}
}
