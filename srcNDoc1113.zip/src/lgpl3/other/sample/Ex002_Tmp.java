package lgpl3.other.sample;

import lgpl3.o.O;

/**
 * Code template.<br/>
 * Code template.
 *
 * @version 2022/05/05_18:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex002_Tmp" >src</a>
 *
 */
public class Ex002_Tmp {

	public static void main(String[] sAry) throws Throwable {

		for (int idx = 0; idx != sAry.length; idx++)

			O.l(sAry[idx]);

	}
}
