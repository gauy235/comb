package lgpl3.shuffle;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;

import java.util.concurrent.ThreadLocalRandom;

import lgpl3.o.B;
import lgpl3.o.ary.Ar32va;

/**
 * To shuffle the array.<br/>
 *
 * @version 2023/11/25_10:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Shuffler" >src</a>
 *
 */
public abstract class Shuffler extends Shuffler_B { // private static final Class<?> THIS = Shuffler.class;

	/**
	 * To shuffle then to pick.
	 */
	// ar.length 最大長度 64, every ar[i] 最大值 63, k 最大長度 10
	public static long pickKNRetB64W6(int[] ar32, int k) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int idx, lenMul8 = ar32.length << 3; // 寬鬆

		long tmp, kept = 0b0L, ret = 0b0L;

		do {
			idx = rnd.nextInt(lenMul8) >>> 3;
			tmp = 0b1L << idx;

			if ((tmp & kept) != 0b0L) continue; // O.l("tmp=" + tmp, THIS);

			ret <<= $6;
			ret |= ar32[idx]; // 好像 不可簡寫在同一列 如 swapByXor

			if (Long.bitCount(kept |= tmp) == k) return ret;

		} while (B.T);
	}

	/**
	 * To shuffle then to pick.
	 */
	public static long pickKNRetB64W6(int[] sortedAr32, int k, int[] exSortedAr32) { // 單個 ar32[i] 最大值 63, k 最大 10

		return pickKNRetB64W6(Ar32va.ex(sortedAr32, exSortedAr32), k);
	}

	/**
	 * To shuffle then to pick.<br/>
	 */
	public static int[] pickK(int[] ar32, int k) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int idx, lenMul8 = (ar32.length << 3) /* 寬鬆 */, ret[] = new int[k], iRet = 0;

		long tmp, kept = 0b0L;

		do {
			idx = rnd.nextInt(lenMul8) >>> 3;
			tmp = 0b1L << idx;

			if ((tmp & kept) != 0b0L) continue; // O.l("tmp=" + tmp, THIS);

			ret[iRet++] = ar32[idx];

			if (Long.bitCount(kept |= tmp) == k) return ret;

		} while (B.T);
	}

	/**
	 * To shuffle then to pick.<br/>
	 */
	public static String[] pickK(String[] sAry, int k) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int idx, lenMul8 = (sAry.length << 3) /* 寬鬆 */, iRet = 0;

		long tmp, kept = 0b0L;

		String[] ret = new String[k];

		do {
			idx = rnd.nextInt(lenMul8) >>> 3;
			tmp = 0b1L << idx;

			if ((tmp & kept) != 0b0L) continue; // O.l("tmp=" + tmp, THIS);

			ret[iRet++] = sAry[idx];

			if (Long.bitCount(kept |= tmp) == k) return ret;

		} while (B.T);
	}
}
