package lgpl3.shuffle;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.ary.Arr;
import lgpl3.o.ary.Ary2D;
import lgpl3.o.ary.Seq;

/**
 * Shuffles the array.<br/>
 *
 * @version 2023/12/10_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Shuffler_A" >src</a>
 *
 * @see Shuffler_B
 */
public abstract class Shuffler_A { // private static final Class<?> THIS = Shuffler_A.class;

	public static final int N_TO_SHIFT = 48; // limited len of ar

	public static final long MASK = ~(-0b1L << N_TO_SHIFT);
	// MASK = 0000_0000_0000_0000_1111_1111_1111_1111_1111_1111_1111_1111_1111_1111_1111_1111

	public static final int RANGE32 = (0b1 << (64 - N_TO_SHIFT)); // 65_536

	/**
	 * Shuffles.<br/>
	 */
	public static long[] shuffle(long[] ar) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		long tmpV;

		for (int len = ar.length, bound = (len << 3) /* 適用短陣列 */, idx; len != 0;)

			if ((idx = rnd.nextInt(bound) >>> 3) != --len) {

				tmpV = ar[len];
				ar[len] = ar[idx];
				ar[idx] = tmpV;
			}

		return ar;
	}

	/**
	 * Shuffles.<br/>
	 */
	public static long[] shuffleByShift(long[] ar) { // element value limited 2 ^ 48

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int idx;
		for (idx = ar.length - 1; idx >= 0; idx--) ar[idx] = (long) rnd.nextInt(RANGE32) << N_TO_SHIFT | ar[idx];

		Arrays.sort(ar);

		for (idx = ar.length - 1; idx >= 0; idx--) ar[idx] &= MASK;

		return ar;
	}

	/**
	 * Shuffles.<br/>
	 */
	public static int[] shuffle(int[] ar) { // 適用短陣列

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		for (int len = ar.length, bound = (len << 3), ix, tmpV; len != 0;) if ((ix = rnd.nextInt(bound) >>> 3) != --len) {

			tmpV = ar[len];
			ar[len] = ar[ix];
			ar[ix] = tmpV;
		}

		return ar;
	}

	/**
	 * Shuffles.<br/>
	 */
	public static Ary2D shuffle(Ary2D ary2D) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int bound = ary2D.i << 3; // 適用短陣列

		long allAr[][] = ary2D.ar, tmpAr[];

		for (int ix = 0, newIx; ix != ary2D.i; ix++) if ((newIx = rnd.nextInt(bound) >>> 3) != ix) {

			tmpAr = allAr[ix];
			allAr[ix] = allAr[newIx];
			allAr[newIx] = tmpAr;
		}

		return ary2D;
	}

	/**
	 * Shuffles.<br/>
	 */
	public static Arr<Seq> shuffle(Arr<Seq> arOfSeq) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int bound = arOfSeq.i << 3; // 適用短陣列

		Seq allSeq[] = arOfSeq.ar, tmpSeq;

		for (int ix = 0, newIx; ix != arOfSeq.i; ix++) if ((newIx = rnd.nextInt(bound) >>> 3) != ix) {

			tmpSeq = allSeq[ix];
			allSeq[ix] = allSeq[newIx];
			allSeq[newIx] = tmpSeq;
		}

		return arOfSeq;
	}

	/**
	 * Shuffles.<br/>
	 */
	public static String[] shuffle(String[] sAry) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int bound = sAry.length << 3; // 適用短陣列

		String tmpS;

		for (int idx = 0, newIdx; idx != sAry.length; idx++) if ((newIdx = rnd.nextInt(bound) >>> 3) != idx) {

			tmpS = sAry[idx];
			sAry[idx] = sAry[newIdx];
			sAry[newIdx] = tmpS;
		}

		return sAry;
	}

	/**
	 * Shuffles.<br/>
	 */
	public static char[] shuffle(char[] charAry) { // todo: 縮寫 shfl

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int bound = charAry.length << 3; // 適用短陣列

		char tmpChar;

		for (int idx = 0, newIdx; idx != charAry.length; idx++) if ((newIdx = rnd.nextInt(bound) >>> 3) != idx) {

			tmpChar = charAry[idx];
			charAry[idx] = charAry[newIdx];
			charAry[newIdx] = tmpChar;
		}

		return charAry;
	}

	/**
	 * Shuffles.<br/>
	 */
	public static long shuffle(long b64W6, int totalVCell) { // todo: 陣列愈長 swap 愈多次嗎

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		for (int bound = (totalVCell << 3) /* 適用短陣列 */, idx; totalVCell != 0;)

			if ((idx = rnd.nextInt(bound) >>> 3) != --totalVCell) b64W6 = B64W6.swapVCell(b64W6, totalVCell, idx);

		return b64W6;
	}

	/**
	 * Shuffles.<br/>
	 */
	public static long shuffleAgainstHead(long b64W6, int totalVCell) { // todo: 陣列愈長 swap 愈多次

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		// 每次從 idx 0 開始 swap 不均勻嗎
		for (int bound = totalVCell << 3 /* 適用短陣列 */, idx; totalVCell-- != 0;)

			if ((idx = rnd.nextInt(bound) >>> 3) != 0) b64W6 = B64W6.swapVCell(b64W6, 0, idx);

		return b64W6;
	}

	/**
	 * Shuffles.<br/>
	 */
	public static long shuffleAgainstHead(long b64W6, int totalVCell, ThreadLocalRandom rnd) { // todo: 陣列愈長 swap 愈多次

		// 每次從 idx 0 開始 swap 不均勻嗎
		for (int bound = totalVCell << 3 /* 適用短陣列 */, idx; totalVCell-- != 0;)

			if ((idx = rnd.nextInt(bound) >>> 3) != 0) b64W6 = B64W6.swapVCell(b64W6, 0, idx);

		return b64W6;
	}
}
