package lgpl3.shuffle;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.ary.Arr;
import lgpl3.o.ary.Ary2D;
import lgpl3.o.ary.Seq;

/**
 * To shuffle the array.<br/>
 * To shuffle the array.
 *
 * @version 2022/06/05_14:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Shuffler_A" >src</a>
 *
 * @see Shuffler_B
 */
public abstract class Shuffler_A {

	private static final Class<?> THIS = Shuffler_A.class;

	public static final int N_TO_SHIFT = 48; // limited len of ary

	public static final long MASK = ~(-0b1L << N_TO_SHIFT);
	// MASK = 0000_0000_0000_0000_1111_1111_1111_1111_1111_1111_1111_1111_1111_1111_1111_1111

	public static final int RANGE32 = (0b1 << (64 - N_TO_SHIFT)); // 65_536

	/**
	 * To shuffle.
	 */
	public static long[] shuffle(long[] ary) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		long tmpV;
		for (int len = ary.length, bound = len << 3 /* 適用短陣列 */, idx; len != 0;)

			if ((idx = (rnd.nextInt(bound) >>> 3)) != --len) {

				tmpV = ary[len];
				ary[len] = ary[idx];
				ary[idx] = tmpV;

			}

		return ary;

	}

	/**
	 * To shuffle.<br/>
	 * To shuffle.
	 */
	public static long[] shuffleByShift(long[] ary) { // element value limited 2 ^ 48

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int idx;
		for (idx = ary.length - 1; idx >= 0; idx--)

			ary[idx] = (((long) rnd.nextInt(RANGE32)) << N_TO_SHIFT) | ary[idx];

		Arrays.sort(ary);

		for (idx = ary.length - 1; idx >= 0; idx--)

			ary[idx] &= MASK;

		return ary;

	}

	/**
	 * To shuffle.
	 */
	public static int[] shuffle(int[] ary32) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		for (int len = ary32.length, bound = len << 3 /* 適用短陣列 */, idx, tmpV; len != 0;)

			if ((idx = (rnd.nextInt(bound) >>> 3)) != --len) {

				tmpV = ary32[len];
				ary32[len] = ary32[idx];
				ary32[idx] = tmpV;

			}

		return ary32;

	}

	/**
	 * To shuffle.
	 */
	public static Ary2D shuffle(Ary2D ary2D) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int bound = ary2D.i << 3; // 適用短陣列

		long allAry[][] = ary2D.arr, tmpAry[];

		for (int idx = 0, newIdx; idx != ary2D.i; idx++)

			if ((newIdx = (rnd.nextInt(bound) >>> 3)) != idx) {

				tmpAry = allAry[idx];
				allAry[idx] = allAry[newIdx];
				allAry[newIdx] = tmpAry;

			}

		return ary2D;

	}

	/**
	 * To shuffle.
	 */
	public static Arr<Seq> shuffle(Arr<Seq> arrOfSeq) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int bound = arrOfSeq.i << 3; // 適用短陣列

		Seq allSeq[] = arrOfSeq.arr, tmpSeq;

		for (int idx = 0, newIdx; idx != arrOfSeq.i; idx++)

			if ((newIdx = (rnd.nextInt(bound) >>> 3)) != idx) {

				tmpSeq = allSeq[idx];
				allSeq[idx] = allSeq[newIdx];
				allSeq[newIdx] = tmpSeq;

			}

		return arrOfSeq;

	}

	/**
	 * To shuffle.
	 */
	public static String[] shuffle(String[] sAry) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int bound = sAry.length << 3; // 適用短陣列

		String tmpS;
		for (int idx = 0, newIdx; idx != sAry.length; idx++)

			if ((newIdx = (rnd.nextInt(bound) >>> 3)) != idx) {

				tmpS = sAry[idx];
				sAry[idx] = sAry[newIdx];
				sAry[newIdx] = tmpS;

			}

		return sAry;

	}

	/**
	 * To shuffle.
	 */
	public static char[] shuffle(char[] charAry) {

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int bound = charAry.length << 3; // 適用短陣列

		char tmpChar;
		for (int idx = 0, newIdx; idx != charAry.length; idx++)

			if ((newIdx = (rnd.nextInt(bound) >>> 3)) != idx) {

				tmpChar = charAry[idx];
				charAry[idx] = charAry[newIdx];
				charAry[newIdx] = tmpChar;

			}

		return charAry;

	}

	/**
	 * To shuffle.
	 */
	public static long shuffle(long b64W6, int totalVCell) { // todo: 陣列愈長 swap 愈多次嗎

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		for (int bound = totalVCell << 3 /* 適用短陣列 */, idx; totalVCell != 0;)

			if ((idx = (rnd.nextInt(bound) >>> 3)) != --totalVCell)

				b64W6 = B64W6.swapVCell(b64W6, totalVCell, idx);

		return b64W6;

	}

	/**
	 * To shuffle.
	 */
	public static long shuffleAgainstHead(long b64W6, int totalVCell) { // todo: 陣列愈長 swap 愈多次

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		// 每次從 idx 0 開始 swap 不均勻嗎
		for (int bound = totalVCell << 3 /* 適用短陣列 */, idx; totalVCell != 0; totalVCell--)

			if ((idx = (rnd.nextInt(bound) >>> 3)) != 0)

				b64W6 = B64W6.swapVCell(b64W6, 0, idx);

		return b64W6;

	}

	/**
	 * To shuffle.
	 */
	public static long shuffleAgainstHead(long b64W6, int totalVCell, ThreadLocalRandom rnd) { // todo: 陣列愈長 swap 愈多次

		// 每次從 idx 0 開始 swap 不均勻嗎
		for (int bound = totalVCell << 3 /* 適用短陣列 */, idx; totalVCell != 0; totalVCell--)

			if ((idx = (rnd.nextInt(bound) >>> 3)) != 0)

				b64W6 = B64W6.swapVCell(b64W6, 0, idx);

		return b64W6;

	}
}
