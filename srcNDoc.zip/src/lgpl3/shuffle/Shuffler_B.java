package lgpl3.shuffle;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.concurrent.ThreadLocalRandom;

import lgpl3.comb.Cnk;
import lgpl3.comb.Pnk;
import lgpl3.comb.filter.BitRow;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;

/**
 * @version 2022/09/25_10:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Shuffler_B" >src</a>
 *
 * @see Shuffler
 */
public abstract class Shuffler_B extends Shuffler_A {

	private static final Class<?> THIS = Shuffler.class;

	/**
	 * C(n,k)
	 */
	public static int pickKNRetB32As2Pow(int n, int k) {

		if (k == 0 || n == k) return 0b0;

		boolean isGt1_2 = k > (n >>> 1);

		if (isGt1_2) k = n - k;

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int lim = 0, bakup = ~(0xFFFF_FFFF << k), ret = 0b0, nMul32 = (n << 5) /* 寬鬆 */, tmp;

		while (((tmp = (0b1 << (rnd.nextInt(nMul32) >>> 5))) & ret) != 0b0 /* 直到出現非 0 */ ||

				Integer.bitCount(ret |= tmp) != k) // O.l("tmp=" + tmp, THIS);

			if (++lim == 0b0 /* 過頭再回來 */) return bakup;

			else B.cnt++;

		O.l("B.cnt=" + B.cnt, THIS);

		B.cnt = 0;

		// C(5,3) => C(5,2) 0001_0100 => inverse => ~0001_0100 & ~1110_0000 => 1110_1011 & 0001_1111 => 0000_1101

		if (isGt1_2) return ~ret & ~(-0b1 << n); // ~(-0b1 << n) as mask // 0001_0010 ^ 0001_1111 => 0000_1101

		return ret;
	}

	/**
	 * To sum.
	 */
	public static int sumOfInv(int totalVCellPerB64W6) {

		int nAftFac = (int) Pnk.int64(totalVCellPerB64W6), sumOfInv = 0;

		// 若 A=3! 則運氣普通的話 6/6 + 6/5 + 6/4 + 6/3 + 6/2 + 6/1

		// 樣態甲: CBA
		// 樣態乙: ACB
		// 樣態丙: ABC
		// 樣態丁: BAC
		// 樣態戊: BCA
		// 樣態己: CAB
		// 所以 甲乙丙丁戊己 排列 是 A! = 24

		for (int unselectedQty = nAftFac; unselectedQty != 0; unselectedQty--) {

			sumOfInv += (nAftFac / unselectedQty);

			if (nAftFac % unselectedQty != 0) sumOfInv++; // 不到1次 也算1次 6/5=2

		}

		O.l("sumOfInv=" + O.f(sumOfInv), THIS);

		return sumOfInv;
	}

	/**
	 * To sum.
	 */
	public static int sumOfInvForC(int n, int k) {

		int ansC = (int) Cnk.int64(n, k), ret = 0;

		for (int unselectedQty = ansC; unselectedQty != 0; unselectedQty--) {

			ret += (ansC / unselectedQty);

			if (ansC % unselectedQty != 0) ret++;

		}

		return ret;
	}

	/**
	 * The number of tests.
	 */
	public static int sumOfFac(int totalVCellPerB64W6) { // (n!)*(n!) 想 (n!)*(n!-1)

		// 有想過 [(n!)^(n!)] / [(n!)!]= A*A / A!

		int sumOfFac = (int) Pnk.int64(totalVCellPerB64W6);

		sumOfFac *= sumOfFac - 1;

		O.l("sumOfFac=" + O.f(sumOfFac), THIS);

		return sumOfFac;
	}

	/**
	 * To shuffle.
	 */
	public static int[] shuffleForCnk(int n, int k, float rate) {

		int nOfTest = (int) (sumOfInvForC(n, k) * rate);

		O.l("nOfTest=" + nOfTest, THIS);

		Hashtable<Integer, Object> filter = new Hashtable<>();

		do filter.put(pickKNRetB32As2Pow(n, k), filter); while (--nOfTest != 0);

		int[] ret = new int[filter.size()];

		for (Enumeration<Integer> allKey = filter.keys(); allKey.hasMoreElements();) ret[nOfTest++] = allKey.nextElement();

		return ret;
	}

	/**
	 * To shuffle.
	 */
	public static long[] shuffleForPnk(long b64W6AftC, int totalVCellPerB64W6, int nOfTest) { // just one row

		if (totalVCellPerB64W6 == 1) return new long[] { b64W6AftC };

		BitRow filter = new BitRow(b64W6AftC, totalVCellPerB64W6);

		long ret[] = new long[(int) Pnk.int64(totalVCellPerB64W6)];

		ThreadLocalRandom rnd = ThreadLocalRandom.current();

		int idx = 0;

		do if (filter.ifNew(b64W6AftC = shuffleAgainstHead(b64W6AftC, totalVCellPerB64W6, rnd))) ret[idx++] = b64W6AftC;

		// 把 b64W6AftC 不斷丟進去 shuffle 又 shuffle

		while (--nOfTest != 0);

		return O.delTailAll0(ret);
	}

	/**
	 * To shuffle.
	 */
	// 土法煉鋼 排列
	public static long[] shuffleForPnk(long[] aryAftC /* long[] of B64W6 */, int totalVCellPerB64W6, float rate) {

		if (totalVCellPerB64W6 == 1) return aryAftC;

		int nTestOfPerRow = (O.rnd100() > 0) ? (int) (sumOfInv(totalVCellPerB64W6) * rate) : sumOfFac(totalVCellPerB64W6);

		O.l("totalVCellPerB64W6=" + totalVCellPerB64W6 + " nTestOfPerRow=" + O.f(nTestOfPerRow), THIS);
		O.l("rate=" + rate);

		int idx = 0;
		long ret[] = shuffleForPnk(aryAftC[idx++], totalVCellPerB64W6, nTestOfPerRow);

		for (; idx != aryAftC.length; idx++) // O.l("merge idx=" + idx, THIS);

			ret = Aryva.merge(ret, shuffleForPnk(aryAftC[idx], totalVCellPerB64W6, nTestOfPerRow));

		return ret;
	}
}
