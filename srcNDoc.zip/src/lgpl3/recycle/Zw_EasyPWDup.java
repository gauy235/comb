package lgpl3.recycle;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.wDup.DatWDup_A.DEF_DIV32;

import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.ary.Seq;

/**
 * PWDup<br/>
 * PWDup
 *
 * @version 2023/09/18_23:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_EasyPWDup" >src</a>
 *
 * @see Zw_EasyCWDup
 */
public class Zw_EasyPWDup {

	private static final Class<?> THIS = Zw_EasyPWDup.class;

	/**
	 * PWDup<br/>
	 */
	public static void pWDup(long rmdB64, long prefix, Seq retSeq, int kAsLv) {

		if (kAsLv-- == 0) {

			retSeq.a(prefix);

			return;

		}

		long old64 = (prefix <<= $6), cache = old64, allBullet = rmdB64, bullet;

		for (; allBullet != 0b0L; allBullet = (~bullet & allBullet)) {

			prefix = old64 | (B64va.log2(bullet = (-allBullet & allBullet)) / DEF_DIV32 + 1);

			// O.lv(kAsLv + 1, "tmp=" + B64W6.str24(tmp));

			if (prefix != cache) pWDup((~bullet & rmdB64), (cache = prefix), retSeq, kAsLv);

		}
	}

	/**
	 * PWDup<br/>
	 */
	public static DatWDup pWDup(String s, int k) {

		DatWDup datWDup = new DatWDup();

		datWDup.oriS = s;
		datWDup.k = k;

		datWDup.initAll();

		O.l("allBit=" + O.S64 + THIS + "=" + B64W6.str24(datWDup.b64As2PowOfQRPlus1));

		Seq retSeq = new Seq();

		datWDup.tmpObj = retSeq;

		pWDup(datWDup.b64As2PowOfQRPlus1, 0b0L, retSeq, k);

		return datWDup;

	}

	public static void main(String[] sAry) throws Throwable {

		String myS = "Y,B,B,C,C,C";

		int k = 3;

		DatWDup dat = pWDup(myS, k);

		long arOfB64W6[] = ((Seq) dat.tmpObj).trim().ary, b64W6;

		arOfB64W6 = Aryva.checkDup(arOfB64W6);

		for (int idx = 0; idx != arOfB64W6.length; idx++) {

			b64W6 = arOfB64W6[idx];

			O.l(B64W6.str24(b64W6));

			O.l((idx + 1) + " " + B64W6.strByVCellMinus1AftRevBySAry(b64W6, dat.distSortedSAry));

		}
	}
}