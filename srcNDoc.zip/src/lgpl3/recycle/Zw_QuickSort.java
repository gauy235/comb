package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * QuickSort.<br/>
 * QuickSort.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_QuickSort" >src</a>
 *
 */
public class Zw_QuickSort {

	public static int[] quickSort(int[] ary, int left, int right) {

		if (left < right) {

			int iPivot = Ary32va.easyPartiNRetIdxOfPivot(ary, left, right);
			// int iPivot = Ary32va.partiNRetIdxOfPivot(ary, left, right);

			quickSort(ary, left, iPivot - 1);

			quickSort(ary, iPivot + 1, right);

		}

		return ary;

	}

	public static void main1(String[] sAry) {

		int[] ar = { 20, 30, 40, 70, 80, 90 }, clonedAr = ar.clone();

		ar = Shuffler.shuffle(ar);

		O.l("bef=" + O.L + Arrays.toString(ar));

		int iPivot = Ary32va.partiNRetIdxOfPivot(ar, 0, ar.length - 1);

		O.l("pivot=ar[" + iPivot + "]=" + ar[iPivot]);

	}

	public static void main(String[] sAry) {

		int[] ar = { 20, 30, 40, 70, 80, 90 }, clonedAr = ar.clone();

		ar = Shuffler.shuffle(ar);

		O.l("bef=" + O.L + Arrays.toString(ar));

		O.l("aft=" + O.L + Arrays.toString(quickSort(ar, 0, ar.length - 1)));

		if (!Arrays.equals(ar, clonedAr))

			O.x(O.L + "ar=" + Arrays.toString(ar) + O.L + "clonedAr=" + Arrays.toString(clonedAr));

	}
}
