package lgpl3.recycle;

import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;

/**
 * HeapSort.
 *
 * @version 2023/11/25_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_HeapSort" >src</a>
 *
 */
public class Zw_HeapSort { // private static final Class<?> THIS = Zw_HeapSort.class;

	static void maxHeapify(int[] ar, int idx, int len) {

		// find largest among root, left child and right child
		int iBig = idx;

		int l = ((idx << 1) + 1), r = (l + 1);

		if (l < len && (ar[l] > ar[iBig])) iBig = l; // 不可用 vBig = ar[iBig]

		if (r < len && (ar[r] > ar[iBig])) iBig = r;

		if (iBig != idx) {

			Ar32va.swapV(ar, idx, iBig);

			maxHeapify(ar, iBig, len);
		}
	}

	static int[] maxHeapSort(int[] ar) { // asc

		// Build max heap 並調整
		for (int idx = ar.length / 2 - 1; idx >= 0; idx--) maxHeapify(ar, idx, ar.length);

		// 跟 root 交換
		for (int idx = ar.length - 1; idx >= 0; idx--) { // Heap sort 逐漸縮短

			Ar32va.swapV(ar, 0, idx);

			maxHeapify(ar, 0, idx); // Heapify root element to get highest element at root again // Heap sort 逐漸縮短
		}

		return ar;
	}

	public static void main(String[] sAry) {

		int[] ar = { 1, 12, 9, 5, 6, 10 };

		O.l(maxHeapSort(ar)); // asc
	}
}
