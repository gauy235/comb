package lgpl3.recycle;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;
import lgpl3.shuffle.Shuffler;

/**
 * HeapSort.
 *
 * @version 2023/11/30_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_HeapSort" >src</a>
 *
 */
public class Zw_HeapSort { // private static final Class<?> THIS = Zw_HeapSort.class;

	static void maxHeapify(int[] ar, int idx, int len) {

		// find max among root, left child and right child
		int iMax = idx;

		int l = idx * 2 + 1;
		int r = idx * 2 + 2;

		if (l < len && (ar[l] > ar[iMax])) iMax = l; // 不可用 max = ar[iMax]

		if (r < len && (ar[r] > ar[iMax])) iMax = r;

		if (iMax != idx) {

			Ar32va.swapV(ar, idx, iMax);

			maxHeapify(ar, iMax, len); // 當 iMax == l or iMax == r 往下滑 調整
		}
	}

	static int[] maxHeapSort(int[] ar) { // asc

		int idx;

		for (idx = ar.length / 2 - 1; idx >= 0; idx--) maxHeapify(ar, idx, ar.length); // 初始化 從倒數第 2 層調整

		// 從最尾端跟 root 交換
		for (idx = ar.length - 1; idx >= 0; idx--) { // 尚未排序資料列 逐漸縮短

			Ar32va.swapV(ar, 0, idx);

			maxHeapify(ar, 0, idx); // 跟 root 交換
		}

		return ar;
	}

	public static void main1(String[] sAry) {

		int[] ar = { 1, 12, 9, 5, 6, 10 };

		O.l("ar=");
		O.l(Shuffler.shuffle(ar));

		O.l("aft=");
		O.l(maxHeapSort(ar)); // asc
	}

	public static void main(String[] sAry) {

		long[] ar = { 1, 12, 9, 5, 6, 10 };

		O.l("ar=");
		O.l(Shuffler.shuffle(ar));

		O.l("aft=");
		O.l(B64W6.maxHeapSort(ar)); // asc
	}
}
