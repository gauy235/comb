package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;
import lgpl3.shuffle.Shuffler;

/**
 * Search By Pivot.<br/>
 *
 * @version 2022/12/26_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_SearchByPivot" >src</a>
 *
 */
public class Zw_SearchByPivot { /* unsorted */

	/**
	 * To search.
	 */
	public static int srhByPivot(int[] ar /* unsorted */, int key, int left, int right) { // 會把資料分群並搬移

		while (left <= right) {

			int idxPivot = Ar32va.goPivot(ar, left, right);
			int vPivot = ar[idxPivot];

			if (key == vPivot) return idxPivot;

			if (key > vPivot) left = idxPivot + 1;

			else right = idxPivot - 1;

			O.l("idxPivot=" + idxPivot + " left=" + left + " right=" + right);
		}

		return -1; // not find
	}

	public static void main(String[] sAry) throws Throwable {

		int[] ar = { 20, 30, 40, 50, 60, 90 };
		int key = 60;

		ar = Shuffler.shuffle(ar);

		O.l("bef=" + O.L + Arrays.toString(ar));
		O.l("key=" + key);

		O.l("foundIdx=" + srhByPivot(ar, key, 0, ar.length - 1));
	}
}