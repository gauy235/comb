package lgpl3.recycle;

/**
 * LR.<br/>
 *
 * @version 2023/12/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=LR32" >src</a>
 *
 */
public abstract class LR32 {

	/**
	 * 16 bits per cell.<br/>
	 */
	public static final int $16 = 16;

	/**
	 * 0b1111_1111_1111_1111<br/>
	 */
	public static final int MSK = 0b1111_1111_1111_1111; // 0b1111_1111_1111_1111 ;

	/**
	 * 0b1111_1111_1111_1111_0000_0000_0000_0000<br/>
	 */
	public static final int MSK_16TO31 = 0b1111_1111_1111_1111_0000_0000_0000_0000; // todo: 改 B64W6 首為 第 0 位元

	/**
	 * To gen.<br/>
	 */
	public static int gen(int l, int r) {

		l <<= $16;

		return l |= r;
	}

	/**
	 * Returns r.<br/>
	 */
	public static int r(int b32) {

		return b32 &= MSK;
	}

	/**
	 * Returns l.<br/>
	 */
	public static int l(int b32) {

		b32 &= MSK_16TO31;

		return b32 >>>= $16;
	}
}