package lgpl3.recycle;

import static lgpl3.o.B.T;

import java.util.Arrays;

import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.shuffle.Shuffler;

/**
 * Bubble Sort.<br/>
 * Bubble Sort.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_BubbleSort" >src</a>
 *
 */
public class Zw_BubbleSort {

	/**
	 * To swap.
	 */
	public static boolean swap(int[] ar, int i, int j) {

		int tmp = ar[i];

		ar[i] = ar[j];

		ar[j] = tmp;

		return B.T;

	}

	public static int[] bubbleSort(int[] ar) {

		for (int iBig = ar.length - 1, j; iBig > 0; iBig--) {

			O.l("iBig=" + iBig + " ar=" + Arrays.toString(ar));

			boolean aftSwap = !T;

			for (j = 0; j < iBig; j++) {

				if (ar[j] > ar[j + 1]) aftSwap = swap(ar, j, j + 1);

				O.lv(j + 1, "ar=" + Arrays.toString(ar));

			}

			if (!aftSwap) return ar; // O.l("skip it");

		}

		return ar;

	}

	public static void main(String[] sAry) {

		int[] ar = { 20, 30, 40, 50, 60, 90 }, clonedAr = ar.clone();

		ar = Shuffler.shuffle(ar);

		O.l("bef=" + O.L + Arrays.toString(ar));

		O.l("aft=" + O.L + Arrays.toString(bubbleSort(ar)));

		if (!Arrays.equals(ar, clonedAr))

			O.x(O.L + Arrays.toString(ar) + "=>ar" + O.L + Arrays.toString(clonedAr) + "=>clonedAr");

	}
}