package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ary32va;
import lgpl3.shuffle.Shuffler;

/**
 * Stooge Sort.<br/>
 * Stooge Sort.
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_StoogeSort" >src</a>
 *
 */
public class Zw_StoogeSort {

	public static int[] stoogeSort(int[] ar, int low, int high) {

		if (ar[low] > ar[high]) Ary32va.swapV(ar, low, high);

		if (low + 1 >= high) return ar;

		int idx1_3 = (high - low + 1) / 3;

		stoogeSort(ar, low, (high - idx1_3));
		stoogeSort(ar, (low + idx1_3), high);
		stoogeSort(ar, low, (high - idx1_3));

		return ar;

	}

	public static void main(String[] sAry) {

		int[] ar = { 20, 30, 40, 70, 80, 90 }, clonedAr = ar.clone();

		ar = Shuffler.shuffle(ar);

		O.l("bef=" + O.L + Arrays.toString(ar));

		O.l("aft=" + O.L + Arrays.toString(stoogeSort(ar, 0, ar.length - 1)));

		if (!Arrays.equals(ar, clonedAr))

			O.x(O.L + Arrays.toString(ar) + "=>ary" + O.L + Arrays.toString(clonedAr) + "=>clonedAry");

	}
}