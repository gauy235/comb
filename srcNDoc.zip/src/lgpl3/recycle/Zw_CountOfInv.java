package lgpl3.recycle;

import lgpl3.o.O;

/**
 * count 反向數.<br/>
 * T(n) = O(n) 的演算法被稱作"線性時間演算法".
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_CountOfInv" >src</a>
 *
 */
public class Zw_CountOfInv {

	public static int countOfInv(int[] ary, int i, int j) {

		O.l("i=" + i + " j=" + j);

		if (j == ary.length) // j >= ary.length

			return 0;

		if (i < j && ary[i] > ary[j])

			return 1 + countOfInv(ary, i, j + 1);
		else
			return countOfInv(ary, i, j + 1);

	}

	public static void main(String[] sAry) {

		int[] ary = { 30, 10, 20, 40 };

		int count = 0;

		for (int idx = 0; idx < ary.length; idx++) {

			O.l("idx=" + idx);

			count += countOfInv(ary, idx, idx + 1);

		}

		O.l("countOfInv=" + count);

	}
}