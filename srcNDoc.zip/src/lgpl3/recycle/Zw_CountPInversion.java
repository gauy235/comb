package lgpl3.recycle;

import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;

/**
 * count 反向數.<br/>
 * T(n) = O(n) 的演算法被稱作"線性時間演算法".
 *
 * @version 2022/12/16_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_CountPInversion" >src</a>
 *
 */
public class Zw_CountPInversion {

	public static int countPInversionOld(int[] ar, int i, int j) {

		O.l("i=" + i + " j=" + j);

		if (j == ar.length) return 0; // j >= ar.length

		if (i < j && ar[i] > ar[j]) return 1 + countPInversionOld(ar, i, j + 1);

		else return countPInversionOld(ar, i, j + 1);
	}

	public static void main(String[] sAry) {

		int ar[] = { 50, 140, 30, 10 }, cnt = 0;

		for (int from = 0; from != ar.length; from++) {

			O.l("from=" + from);

			cnt += countPInversionOld(ar, from, from + 1);
		}

		O.l("total=" + O.eq(cnt, Ar32va.countPInversion(ar)));

	}
}