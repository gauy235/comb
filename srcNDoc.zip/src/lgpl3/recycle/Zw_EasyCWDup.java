package lgpl3.recycle;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.comb.wDup.sample.Ex704_Hxy;
import lgpl3.comb.wDup.thr.ThrToCWDup;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.ary.Seq;

/**
 * CWDup<br/>
 * CWDup
 *
 * @version 2023/09/18_23:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_EasyCWDup" >src</a>
 *
 * @see Zw_EasyPWDup
 *
 * @see Ex704_Hxy
 */
public class Zw_EasyCWDup {

	private static final Class<?> THIS = Zw_EasyCWDup.class;

	/**
	 * 從 1 列全相異數列中取出 k 個數.
	 *
	 * @see ThrToCWDup #reGo(long, long)
	 * @see B32va #next1BitL(int, int)
	 */
	public static void cWDup(long rmdB64, int k, long prefix, Seq retSeq, int lv) {

		B.cnt++;
		lv++;
		k--;

		long low1;

		int qr, qPlus1 = 0b0, newQPlus1;

		boolean isFirst = B.T;

		prefix <<= $6;
		do {
			low1 = -rmdB64 & rmdB64;
			rmdB64 = ~low1 & rmdB64;

			qr = B64va.log2(low1);

			if (isFirst) {

				isFirst = !B.T;

				qPlus1 = qr / DatWDup.DEF_DIV32 + 1;

				O.lv(lv, "rmdB64=" + B64W6.str24(rmdB64) + " first qPlus1=" + qPlus1);

				if (k == 0) {

					O.lv(lv, "add=" + B64W6.str24(prefix | qPlus1));

					retSeq.a(prefix | qPlus1);

				}

				// todo:if you pick 3 from [A,B,C,D] then at most you can start from B as [B,C,D] not [C,D,X]

				if (rmdB64 == 0b0L) {

					O.lv(lv, "ret prefix=" + B64W6.str24(prefix));

					return;
				}

				cWDup(rmdB64, k, (prefix | qPlus1), retSeq, lv);

			} else {

				newQPlus1 = qr / DatWDup.DEF_DIV32 + 1;

				O.lv(lv, "newQPlus1=" + newQPlus1 + " qPlus1=" + qPlus1);

				if (newQPlus1 != qPlus1) {

					O.lv(lv, "rmdB64=" + B64W6.str24(rmdB64) + " !newQPlus1=" + newQPlus1 + " qPlus1=" + qPlus1);

					if (k == 0) {

						O.lv(lv, "add=" + B64W6.str24(prefix | newQPlus1));

						retSeq.a(prefix | newQPlus1);

					}

					if (rmdB64 == 0b0L) { // todo: check bitcount

						O.lv(lv, "ret prefix=" + B64W6.str24(prefix));

						return;
					}

					cWDup(rmdB64, k, (prefix | (qPlus1 = newQPlus1)), retSeq, lv);

				} else O.lv(lv, "notDo");

			}

		} while (rmdB64 != 0b0L);
	}

	/**
	 * CWDup<br/>
	 */
	public static DatWDup cWDup(String s, int k) {

		DatWDup datWDup = new DatWDup();

		datWDup.oriS = s;
		datWDup.k = k;

		datWDup.initAll();

		O.l("b64As2PowOfQRPlus1=" + B64W6.str24(datWDup.b64As2PowOfQRPlus1), THIS);

		cWDup(datWDup.b64As2PowOfQRPlus1, k, 0b0L, ((Seq) (datWDup.tmpObj = new Seq())), 0);

		return datWDup;
	}

	public static void main(String[] sAry) throws Throwable {

		String s = "X,B,B,C,C,C";

		int k = 3;

		DatWDup dat = cWDup(s, k);

		long arOfB64W6[] = ((Seq) dat.tmpObj).trim().ary, b64W6;

		arOfB64W6 = Aryva.checkDup(arOfB64W6);

		for (int idx = 0; idx != arOfB64W6.length; idx++) {

			b64W6 = arOfB64W6[idx];

			O.l(B64W6.str24(b64W6));

			O.l((idx + 1) + " " + B64W6.strByVCellMinus1AftRevBySAry(b64W6, dat.distSortedSAry));

		}

		O.l("cnt=" + B.cnt);

	}
}