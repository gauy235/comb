package lgpl3.recycle;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.wDup.DatWDup_A.DEF_DIV32;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.comb.wDup.sample.Ex704_Hxy;
import lgpl3.comb.wDup.thr.ThrToCWDup;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.ary.Seq;
import lgpl3.shareWXyz.HxyVal;

/**
 * CWDup<br/>
 * CWDup
 *
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_EasyCWDup" >src</a>
 *
 * @see Ex704_Hxy
 */
public class Zw_EasyCWDup {

	private static final Class<?> THIS = Zw_EasyCWDup.class;

	/**
	 * To convert.<br/>
	 */
	public static StringBuilder convertQ(int myQ) {

		if (myQ == -1) return new StringBuilder("_");

		return B64W6.strByVCellMinus1BySAry(myQ + 1, O.ARY_A_Z);
	}

	/**
	 * To convert.<br/>
	 */
	public static StringBuilder convert(long b64As2Pow) {

		if (b64As2Pow == 0b0L) return new StringBuilder("0");

		long maskB64 = 0b1L, tmpB64, retB64W6 = 0b0L;
		do {
			tmpB64 = b64As2Pow & maskB64;

			if (b64As2Pow < (maskB64 <<= 1)) { // terminate

				if (tmpB64 != 0b0L) // its necessary

					retB64W6 = (retB64W6 << B64W6.$6) | (B64va.log2(tmpB64) / DatWDup.DEF_DIV32 + 1);

				return B64W6.strByVCellMinus1AftRevBySAry(retB64W6, O.ARY_A_Z);

			} else if (tmpB64 != 0b0L) retB64W6 = (retB64W6 << B64W6.$6) | (B64va.log2(tmpB64) / DatWDup.DEF_DIV32 + 1);

		} while (B.T);
	}

	/**
	 * 從 1 列全相異數列中取出 k 個數.
	 *
	 * @see ThrToCWDup #reGo(long, long)
	 * @see B32va #next1BitL(int, int)
	 */
	public static void cWDup(long rmdB64, int k, long prefix, Seq retSeq, int lv) {

		B.cnt++;

		--k;
		++lv;

		long low1;

		int oldQ = -1, newQ;

		prefix <<= $6;
		do {
			newQ = B64va.log2(low1 = -rmdB64 & rmdB64) / DEF_DIV32;

			O.lv(lv, "top rmdB64=" + convert(rmdB64) + " newQ=" + convertQ(newQ) + " oldQ=" + convertQ(oldQ));

			rmdB64 &= ~low1;

			if (newQ != oldQ) {

				oldQ = newQ++;

				O.lv(lv, "pre=" + B64W6.strByVCellMinus1AftRevBySAry(prefix >>> $6, O.ARY_A_Z));

				if (k == 0) {

					O.lv(lv, "add=" + B64W6.strByVCellMinus1AftRevBySAry(prefix | newQ, O.ARY_A_Z));

					retSeq.a(prefix | newQ);

					continue;
				}

				if (rmdB64 == 0b0L || Long.bitCount(rmdB64) < k) {

					O.lv(lv, "kick rmdB64=" + convert(rmdB64) + " k=" + k + " pre=" + B64W6.str24(prefix >>> $6));

					return;
				}

				cWDup(rmdB64, k, (prefix | newQ), retSeq, lv);

			} else O.lv(lv, "none");

		} while (rmdB64 != 0b0L);
	}

	/**
	 * CWDup<br/>
	 */
	public static DatWDup cWDup(String s, int k) {

		DatWDup datWDup = new DatWDup();

		datWDup.oriS = s;
		datWDup.k = k;

		datWDup.initAll();

		cWDup(datWDup.b64As2PowOfQRCell, k, 0b0L, ((Seq) (datWDup.tmpObj = new Seq())), 0);

		return datWDup;
	}

	public static void main(String[] sAry) throws Throwable {

		// String s = "A,B,B,A";
		String s = "A,B,B,B,C";

		int k = 3;

		DatWDup dat = cWDup(s, k);

		long arOfB64W6[] = ((Seq) dat.tmpObj).trim().ary, b64W6,

				ans = HxyVal.int64WLim0ToMax(dat.k, dat.sortByCntDistSAry.length, dat.b64W6OfQtyPlus1Desc);

		arOfB64W6 = Aryva.checkDup(arOfB64W6);

		for (int idx = 0; idx != arOfB64W6.length; idx++) {

			b64W6 = arOfB64W6[idx];

			O.l((idx + 1) + "=" + B64W6.strByVCellMinus1AftRevBySAry(b64W6, dat.distSortedSAry) + " " + B64W6.str24(b64W6));

		}

		O.l("len=" + O.eq(arOfB64W6.length, ans) + " cnt=" + B.cnt);

	}
}