package lgpl3.recycle;

import lgpl3.o.O;
import lgpl3.o.keyNV.K32V;
import lgpl3.o.keyNV.MapK32V;
import lgpl3.shuffle.Shuffler;

/**
 * Zw_MergeSortByLoop.
 *
 * @version 2023/12/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_MergeSortByLoop" >src</a>
 *
 */
public class Zw_MergeSortByLoop {

	/**
	 * merge sort.<br/>
	 */
	public static void mergeLR(int[] ar, int l, int r) {

		int mid = (l + r) / 2, iL = l, iM = (mid + 1), tmpAr[] = new int[r - l + 1], iT = 0;

		while (iL <= mid && iM <= r) tmpAr[iT++] = (ar[iL] < ar[iM]) ? ar[iL++] : ar[iM++]; // todo: 改良寫法

		while (iL <= mid) tmpAr[iT++] = ar[iL++];

		while (iM <= r) tmpAr[iT++] = ar[iM++];

		iT = 0;

		do ar[l++] = tmpAr[iT++]; while (l <= r); // 回寫回去
	}

	public static int[] mgSortByLoop(int[] ar) {

		int l = 0, r = ar.length - 1, mid = (l + r) / 2;

		int idx = 0;

		MapK32V<Integer> q = new MapK32V<Integer>();

		K32V<Integer> tmpLR;

		while (r > (l + 1)) { // O.l("l=" + l + " r=" + r);

			q.a(l, mid);
			q.a((mid + 1), r);

			tmpLR = q.ar[idx++]; // O.l("tmpLR=" + tmpLR.toStr());

			l = tmpLR.k;
			r = tmpLR.v;

			mid = (l + r) / 2;

		}

		// O.l("q=" + O.L + q.toStr());
		// O.l("len=" + q.i);

		for (idx = q.i - 1; idx >= 0; idx--) { // 從最末往前取出

			tmpLR = q.ar[idx];

			l = tmpLR.k;
			r = tmpLR.v;

			if (r > l) mergeLR(ar, l, r);

		}

		mergeLR(ar, 0, ar.length - 1); // 最後一次

		return ar;
	}

	public static void main(String[] sAry) throws Throwable {

		int[] ar = { 1, 12, 9, 5, 6, 10 };

		O.l("ar=");
		O.l(Shuffler.shuffle(ar));

		O.l("aft=");
		O.l(mgSortByLoop(ar));
	}
}
