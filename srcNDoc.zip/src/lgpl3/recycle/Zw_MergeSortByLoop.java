package lgpl3.recycle;

import lgpl3.o.O;
import lgpl3.o.ary.Arr;
import lgpl3.o.keyNV.K32V32;
import lgpl3.shuffle.Shuffler;

/**
 * Zw_MergeSortByLoop.
 *
 * @version 2023/12/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_MergeSortByLoop" >src</a>
 *
 */
public class Zw_MergeSortByLoop {

	/**
	 * merges.<br/>
	 */
	public static void mergeLR(int[] ar, int l, int r) {

		int mid = (l + r) / 2, iL = l, iM = (mid + 1), tmpAr[] = new int[r - l + 1], iT = 0;

		while (iL <= mid && iM <= r) tmpAr[iT++] = (ar[iL] < ar[iM]) ? ar[iL++] : ar[iM++]; // todo: 改良寫法

		while (iL <= mid) tmpAr[iT++] = ar[iL++];

		while (iM <= r) tmpAr[iT++] = ar[iM++];

		iT = 0;

		do ar[l++] = tmpAr[iT++]; while (l <= r); // 回寫回去
	}

	/**
	 * merge sort.<br/>
	 */
	public static int[] mgSortByLoop(int[] ar) {

		int l = 0, r = (ar.length - 1), mid = (l + r) / 2, idx;

		Arr<K32V32> q = new Arr<K32V32>(K32V32.class);

		q.a(new K32V32(l, mid)); // 初始化 分割左半

		K32V32 kV;

		for (idx = 0; r > (l + 1); idx++) { // 分割左半

			l = (kV = q.ar[idx]).k; // O.l("lr=" + lr.toStr());
			r = kV.v;

			mid = (l + r) / 2;

			if (l != mid) q.a(new K32V32(l, mid));

			if (++mid != r) q.a(new K32V32(mid, r));

		}

		O.l("q=" + O.L + q.toStr());
		O.l("len=" + q.i);

		// 從最末往前取出 合併左半
		for (idx = q.i - 1; idx >= 0; idx--) if ((r = (kV = q.ar[idx]).v) != (l = kV.k)) mergeLR(ar, l, r);

		q.i = 0; // 清空

		l = 0;
		r = ar.length - 1;
		mid = (l + r) / 2;

		q.a(new K32V32(++mid, r)); // 初始化 分割右半

		for (idx = 0; r > (l + 1); idx++) { // 分割右半

			l = (kV = q.ar[idx]).k; // O.l("lr=" + lr.toStr());
			r = kV.v;

			mid = (l + r) / 2;

			if (l != mid) q.a(new K32V32(l, mid));

			if (++mid != r) q.a(new K32V32(mid, r));

		}

		O.l("q=" + O.L + q.toStr());
		O.l("len=" + q.i);

		// 從最末往前取出 合併右半
		for (idx = q.i - 1; idx >= 0; idx--) if ((r = (kV = q.ar[idx]).v) != (l = kV.k)) mergeLR(ar, l, r);

		mergeLR(ar, 0, ar.length - 1); // 最後一次

		return ar;
	}

	public static void main(String[] sAry) throws Throwable {

		int[] ar = { 1, 12, 9, 5, 6, 10 };

		O.l("ar=");
		O.l(Shuffler.shuffle(ar));

		O.l("aft=");
		O.l(mgSortByLoop(ar));
	}
}
