package lgpl3.recycle;

import static lgpl3.o.keyNV.LR32.MSK;

import lgpl3.o.O;
import lgpl3.o.ary.Seq32;
import lgpl3.o.keyNV.LR32;
import lgpl3.shuffle.Shuffler;

/**
 * Merge Sort By Loop.
 *
 * @version 2023/12/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_MergeSortByLoop" >src</a>
 *
 */
public class Zw_MergeSortByLoop {

	/**
	 * merges.<br/>
	 */
	public static void mergeLR(int[] ar, int l, int r) {

		int mid = (l + r) >>> 1, iL = l, iM = (mid + 1), vL, vM, tmpAr[] = new int[r - l + 1], iT = 0;

		while (iL <= mid && iM <= r) if ((vL = ar[iL]) < (vM = ar[iM])) {

			tmpAr[iT++] = vL;
			iL++; // // 此情況下 iL 延長

		} else {

			tmpAr[iT++] = vM;
			iM++; // // 此情況下 iM 延長
		}

		while (iL <= mid) tmpAr[iT++] = ar[iL++];

		while (iM <= r) tmpAr[iT++] = ar[iM++];

		iT = 0;

		do ar[l++] = tmpAr[iT++]; while (l <= r); // 回寫回去
	}

	/**
	 * merge sort.<br/>
	 */
	public static int[] mgSortByLoop(int[] ar) {

		int l = 0, r = (ar.length - 1), mid = (l + r) >>> 1, lr, idx;

		Seq32 q = new Seq32().a(LR32.gen(l, mid)); // 初始化 加入左半

		for (idx = 0; r > (l + 1); idx++) { // 分割左半

			l = LR32.l(lr = q.ar[idx]); // O.l(LR32.l(lr) + "^" + (lr &= MSK));

			r = lr &= MSK;

			mid = (l + r) >>> 1;

			if (l != mid) q.a(LR32.gen(l, mid));

			if (++mid != r) q.a(LR32.gen(mid, r));

		}

		O.l("q=" + O.L + q.toStr());
		O.l("len=" + q.i);

		// 從最末往前取出 合併左半
		for (idx = q.i - 1; idx >= 0; idx--) if ((r = LR32.r(lr = q.ar[idx])) != (l = LR32.l(lr))) mergeLR(ar, l, r);

		q.i = 0; // 清空

		l = 0;
		r = ar.length - 1;
		mid = (l + r) >>> 1;

		q.a(LR32.gen(++mid, r)); // 初始化 加入右半

		for (idx = 0; r > (l + 1); idx++) { // 分割右半

			l = LR32.l(lr = q.ar[idx]); // O.l(LR32.l(lr) + "^" + (lr &= MSK));

			r = lr &= MSK;

			mid = (l + r) >>> 1;

			if (l != mid) q.a(LR32.gen(l, mid));

			if (++mid != r) q.a(LR32.gen(mid, r));

		}

		O.l("q=" + O.L + q.toStr());
		O.l("len=" + q.i);

		// 從最末往前取出 合併右半
		for (idx = q.i - 1; idx >= 0; idx--) if ((r = LR32.r(lr = q.ar[idx])) != (l = LR32.l(lr))) mergeLR(ar, l, r);

		mergeLR(ar, 0, ar.length - 1); // 最後全合併

		return ar;
	}

	public static void main(String[] sAry) throws Throwable {

		int[] ar = { 50, 12, 9, 5, 6, 10 };

		O.l("ar=");
		O.l(Shuffler.shuffle(ar));

		O.l("aft=");
		O.l(mgSortByLoop(ar));
	}
}
