package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.shuffle.Shuffler;

/**
 * Merge sort.<br/>
 *
 * @version 2023/06/26_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_MergeSort" >src</a>
 *
 */
public class Zw_MergeSort {

	static void merge(int[] ar, int left, int mid, int right) {

		O.l("left=" + left + " mid=" + mid + " right=" + right);

		int[] tmpAr = new int[ar.length]; // 缺點 copy all

		for (int i = left; i <= right;)

			tmpAr[i] = ar[i++]; // copy array to tmp array

		// merge array[left...mid] and array[mid + 1...right]
		int goL = left, goR = mid + 1;

		for (int i = left; i <= right;)

			if (goL > mid) ar[i++] = tmpAr[goR++]; // 左邊過頭了

			else if (goR > right) ar[i++] = tmpAr[goL++]; // 右邊過頭了

			else if (tmpAr[goL] < tmpAr[goR]) ar[i++] = tmpAr[goL++];

			else ar[i++] = tmpAr[goR++];

	}

	static void mgSort(int[] ar, int left, int right) {

		if (left >= right) return;

		int mid = left + (right - left) / 2;

		// 切割 切割 後合併
		mgSort(ar, left, mid);

		mgSort(ar, mid + 1, right);

		merge(ar, left, mid, right);

	}

	public static void main(String[] sAry) throws Throwable {

		int[] ar = { 3, 5, 6, 8, 9 }, clonedAr = ar.clone();

		ar = Shuffler.shuffle(ar);

		O.l("bef=" + O.L + Arrays.toString(ar));

		mgSort(ar, 0, ar.length - 1); // merge sort 切割 切割 後合併

		O.l("aft=" + O.L + Arrays.toString(ar));

		if (!Arrays.equals(ar, clonedAr))

			O.x(O.L + Arrays.toString(ar) + "=>ar" + O.L + Arrays.toString(clonedAr) + "=>clonedAr");

	}
}