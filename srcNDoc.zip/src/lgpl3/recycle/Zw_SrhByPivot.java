package lgpl3.recycle;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;
import lgpl3.shuffle.Shuffler;

/**
 * Search By Pivot.<br/>
 *
 * @version 2023/10/26_10:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Zw_SrhByPivot" >src</a>
 *
 */
public class Zw_SrhByPivot { /* unsorted */

	public static void main(String[] sAry) throws Throwable {

		int[] ar = { 20, 30, 40, 50, 60, 90 };
		int key = 60;

		ar = Shuffler.shuffle(ar);

		O.l("bef=" + O.L + Arrays.toString(ar));
		O.l("key=" + key);

		O.l("foundIdx=" + Ar32va.srhByPivot(ar, key, 0, ar.length - 1));
	}
}