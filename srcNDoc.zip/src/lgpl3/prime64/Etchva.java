package lgpl3.prime64;

import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.prime64.thr.Marker;
import lgpl3.prime64.thr.Moon;
import lgpl3.prime64.thr.PeerByThrToEtch;
import lgpl3.prime64.thr.ThrToEtch;

/**
 * @version 2022/05/04_19:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Etchva" >src</a>
 *
 * @see Marker
 */
public abstract class Etchva {

	private static final Class<?> THIS = Etchva.class;

	/**
	 * 初始化時會找 1 ~ $INIT_TAIL_IN_MY_AR32 的質數.<br/>
	 * The tail prime of origin array of prime.
	 */
	public static final int $INIT_TAIL_IN_MY_AR32 = 370_759;

	/**
	 * 初始化的質數陣列的長度.<br/>
	 * The length of origin array of prime.
	 */
	public static final int $COUNT_OF_P_AS_LEN = 31_580;

	/**
	 * 6 bits per cell.<br/>
	 */
	public static final int $NUM_OF_BIT_PER_CELL = 6;

	/**
	 * 找質數 EtchPrime 時所允許輸入最大數 .<br/>
	 * The maximum input number for etching primes.
	 */
	// public static final long $MAX_TEST_N_OVER_1_AR32 = 137_438_953_279L;
	public static final long $MAX_TEST_N_OVER_1_AR32 = (((long) (O.$MAX_LEN_OF_ARY - 1)) << 6) + 64L;
	// 137,438,953,216 ok
	// 137,438,953,217
	// 137,438,953,218
	// 137,438,953,278 this
	// 137_438_953_279L this
	// 137_438_953_280L

	/**
	 * 初始化 (質數) 陣列.<br/>
	 * To init the origin array of primes.
	 */
	public static int[] genMyAr32OfP() {

		int ret[] = new int[$COUNT_OF_P_AS_LEN], idx = 0, n32 = 5;

		ret[idx++] = 2; // fuck
		ret[idx++] = 3; // fuck

		for (boolean b4 = B.T; n32 <= $INIT_TAIL_IN_MY_AR32; n32 += ((b4 = !b4) ? 4 : 2))

			if (Miner.testPrime32(n32)) ret[idx++] = n32; // keep it

		O.l("genMyAr32OfP maxP=" + O.f(ret[ret.length - 1]), THIS);

		return ret;
	}

	/**
	 * 內建的質數陣列.<br/>
	 * The inside origin array of prime.
	 */
	public static int[] myAr32OfP = genMyAr32OfP();

	/**
	 * The range.
	 */
	public static final int RANGE32 = 0b1 << 24;

	/**
	 * 可儲存.<br/>
	 */
	public static Ar32OfCompoBitWr etch(long headN, long tailN) { // todo: 要寫 zoneLittlePrime

		return new Ar32OfCompoBitWr(headN, tailN, null, 0);
	}

	/**
	 * Just count.<br/>
	 */
	public static int countPAftEtch(long headN, long tailN) {

		int ret = 0;

		zoneLittlePrime: {

			if (headN == 1L || headN == 2L) {

				if (tailN == 1L) return 0;

				if (tailN == 2L) return 1;

				if (tailN == 3L) return 2;

				if (tailN >= 4L) {

					ret = 2;
					headN = 5L;

					break zoneLittlePrime;
				}
			}

			if (headN == 3L) {

				if (tailN == 3L) return 1;

				if (tailN >= 4L) {

					ret = 1;
					headN = 5L;

					break zoneLittlePrime;
				}
			}
		} // zoneLittlePrime end

		// O.l("headN=" + O.f(headN) + " tailN=" + O.f(tailN), THIS);

		headN |= 0b1; // 4~4 will not do

		final int sqrt32OfTailNPlus1 = ((int) StrictMath.sqrt(tailN) + 1),

				ar32[] = new int[(RANGE32 >>> $NUM_OF_BIT_PER_CELL) + 1], offset = (int) (headN >>> $NUM_OF_BIT_PER_CELL);

		int div32 = 3, div32X2, tmp32;

		long divPow2; // div * div

		for (int idx = 1; div32 < sqrt32OfTailNPlus1; div32 = myAr32OfP[++idx]) {

			tmp32 = (div32 & 0b11_1111) >>> 1;

			divPow2 = (divPow2 = div32) * divPow2; // convert to int64

			div32X2 = div32 << 1;

			if (divPow2 < headN) { // 找接近的 headN 起始值

				divPow2 += ((headN - divPow2) / div32X2) * div32X2;

				if (divPow2 < headN) divPow2 += div32X2;

			}

			if (divPow2 <= tailN)

				do { // (divPow2 >>> offsetPlus6) go err

					tmp32 = (((int) divPow2) & 0b11_1111) >>> 1; // r=2 or r=3, the pos is 1

					ar32[((int) (divPow2 >>> $NUM_OF_BIT_PER_CELL)) - offset] |= (0b1 << tmp32);

				} while ((divPow2 += div32X2) <= tailN);

		}

		///////////////////////////////////////////////////////////

		boolean b4;

		// 6n + 1
		if ((tmp32 = (int) (headN % 6)) == 1) b4 = B.T;

		else { // 6n + 3

			if (tmp32 == 3) headN += 2; // 6n + 5

			b4 = !B.T; // 6n + 5
		}

		b4 = !b4; // important

		for (; headN <= tailN; headN += ((b4 = !b4) ? 4 : 2)) {

			tmp32 = (((int) headN) & 0b11_1111) >>> 1;

			if (((ar32[((int) (headN >>> 6)) - offset] >>> tmp32) & 0b1) == 0b0) ret++;

		}

		// O.l("headN=" + O.f(headN) + " tailN=" + O.f(tailN) + " count=" + O.f(ret), THIS);

		return ret;
	}

	/**
	 * 啟動多執行緒找 n1 ~ n2 間所有質數.<br/>
	 * To mine all primes between n1 and n2 (both inclusive) with threads.
	 */
	public static Moon<ThrToEtch> etchWThr(final long n1, final long n2, final int numOfThr) {

		////////////////////////////////
		ThrToEtch[] arOfThr = new ThrToEtch[numOfThr];
		Moon<ThrToEtch> moon = new Moon<ThrToEtch>();

		long myN1;
		int idx = 0;

		for (; idx != numOfThr; idx++)

			if ((myN1 = n1 + (RANGE32 * idx)) <= n2) arOfThr[idx] = new ThrToEtch(myN1, n2, numOfThr, idx, moon);

			else break;

		///////////////////////////////////////////// delTailAllNull

		for (idx = arOfThr.length - 1; idx != -1; idx--) if (arOfThr[idx] != null) break;

		if (++idx != arOfThr.length) System.arraycopy(arOfThr, 0, (arOfThr = new ThrToEtch[idx]), 0, idx); // 縮短陣列可用

		/////////////////////////////////////////////

		moon.oriN1 = n1;
		moon.oriN2 = n2;
		moon.numOfThr = numOfThr;

		moon.aryOfThr = arOfThr;

		moon.ar32OfCompoBitXy = new Ar32OfCompoBitXy();

		moon.otherThr = new PeerByThrToEtch(moon);

		return moon;
	}
}
