package lgpl3.prime64.thr;

import lgpl3.prime64.Ar32OfCompoBitWr;
import lgpl3.prime64.Ar32OfCompoBitXy;

/**
 * The thread to add.<br/>
 * The thread to add.
 *
 * @version 2021/08/21_13:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ThrToInAr32OfCompoBitXy"
 *          >ThrToInAr32OfCompoBitXy.java</a>
 *
 * @see ThrToAddInPrimeAry2D
 */
public class ThrToInAr32OfCompoBitXy extends Thread {

	// private static final Class<?> THIS = ThrToInAr32OfCompoBitXy.class;

	public Ar32OfCompoBitXy ar32OfCompoBitXy;

	public Ar32OfCompoBitWr[] theArr;

	public Ar32OfCompoBitWr ar32OfCompoBitWr;

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	public ThrToInAr32OfCompoBitXy(Ar32OfCompoBitXy ar32OfCompoBitXy, Ar32OfCompoBitWr ar32OfCompoBitWr) {

		this.ar32OfCompoBitXy = ar32OfCompoBitXy;

		this.theArr = ar32OfCompoBitXy.ar;

		this.ar32OfCompoBitWr = ar32OfCompoBitWr;

		start(); // auto start

	}

	@Override
	public void run() {

		synchronized (ar32OfCompoBitXy.keyToSyn) { // not extLen

			theArr[ar32OfCompoBitXy.i++] = ar32OfCompoBitWr;
		}
	}
}
