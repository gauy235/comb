package lgpl3.prime64;

import lgpl3.o.B;
import lgpl3.o.ary.Arr;

/**
 * 本類別質數隊伍.<br/>
 * 如果這個不好吃, 可以選擇不要吃.
 *
 * @version 2021/08/23_18:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ar32OfCompoBitXy" >Ar32OfCompoBitXy.java</a>
 *
 * @see Ar32OfCompoBitWr
 */
public class Ar32OfCompoBitXy extends Arr<Ar32OfCompoBitWr> {

	private static final Class<?> THIS = Ar32OfCompoBitXy.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * 建構方法.<br/>
	 * The constructor.
	 */
	public Ar32OfCompoBitXy() {

		super(Ar32OfCompoBitWr.class);

		ar = new Ar32OfCompoBitWr[baseLen = PrimeAry2D.DEF_LEN];

	}
}
