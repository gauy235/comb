package lgpl3.comb.thr;

import java.util.Arrays;

import lgpl3.comb.CatalanNum;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.thr.ThrWBox;

/**
 * C(2n,n)-C(2n,n-1)<br/>
 * CatalanNum(4)=14
 *
 * @version 2022/06/11_17:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ThrCatalan" >src</a>
 *
 */
public class ThrCatalan extends ThrWBox<long[]> {

	// private static final Class<?> THIS = ThrWinToChamp.class;

	public static final int ID_AS_WIN = CatalanNum.ID_AS_WIN;

	public static final int ID_AS_LOSE = CatalanNum.ID_AS_LOS;

	public final int maxCountOfWin;

	public int iLen = 0;

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	public ThrCatalan(int n, boolean isToRun) { // n must be even

		maxCountOfWin = n >>> 1;

		box = new long[(int) CatalanNum.int64(maxCountOfWin)];

		if (isToRun)

			run();

	}

	/**
	 * C(2n,n)-C(2n,n-1)<br/>
	 * C(2n,n)-C(2n,n-1)
	 */
	public void winLose(long prefix, int countW, int countL) {

		if (countW == maxCountOfWin) {

			int lv = countW + countL;// for O.lv()

			do
				prefix = ((prefix << B64W6.$6) | ID_AS_LOSE); // 補滿

			while (++countL != countW);

			O.lv(lv, "prefix=" + B64W6.str(prefix));

			box[iLen++] = prefix;

			return;

		}

		// countW < maxCountOfWin

		winLose(((prefix << B64W6.$6) | ID_AS_WIN), (countW + 1), countL); // win

		if (countW > countL)

			winLose(((prefix << B64W6.$6) | ID_AS_LOSE), countW, (countL + 1)); // lose

	}

	@Override
	public void run() {

		winLose(ID_AS_WIN, 1, 0);
	}

	public static void main(String[] sAry) throws Throwable {

		String[] aryOfDyck = { "W", "L" };

		int n = 10;

		ThrCatalan thr = new ThrCatalan(n, B.T);

		long[] aryAsSet = Aryva.chkDup(thr.box);

		Arrays.sort(aryAsSet);

		for (int idx = 0, size = aryAsSet.length; idx != size; idx++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(aryAsSet[idx], aryOfDyck));

		O.l("total=" + O.eq(thr.iLen, CatalanNum.int64(n >>> 1)));

	}
}
