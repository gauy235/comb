package lgpl3.comb.selfCallva.sample;

import lgpl3.comb.selfCallva.SelfCallva;
import lgpl3.o.O;
import lgpl3.shuffle.Shuffler;

/**
 * This reduces the maximum recursion depth from N to log2(N).<br/>
 * But the search effort still stays O(N).
 *
 * @version 2022/11/17_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex24_FindMax" >src</a>
 *
 */
public class Ex24_FindMax {

	public static void main(String[] sAry) throws Throwable {

		int[] baseAry = { 10, -40, 20, 50, 89, 30 };

		Shuffler.shuffle(baseAry);

		O.l("baseAry=");
		O.l(baseAry);
		O.l("==========");

		O.l("findMax=" + SelfCallva.findMax(baseAry, baseAry.length - 1));
		O.l("findMaxByKeepMax=" + SelfCallva.findMaxByKeepMax(baseAry, baseAry[0], 1));

	}
}
