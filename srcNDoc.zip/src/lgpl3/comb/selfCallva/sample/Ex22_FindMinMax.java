package lgpl3.comb.selfCallva.sample;

import static lgpl3.o.B.T;

import java.util.Arrays;

import lgpl3.comb.selfCallva.SelfCallva;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;
import lgpl3.shuffle.Shuffler;

/**
 * This reduces the maximum recursion depth from N to log2(N).<br/>
 * But the search effort still stays O(N).
 *
 * @version 2022/12/03_08:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex22_FindMinMax" >src</a>
 *
 */
public class Ex22_FindMinMax {

	public static void main(String[] sAry) throws Throwable {

		O.isDev = !T;

		int[] ar = { 13, 60, 20, 50, 89, 30 };

		O.l("ar=");
		O.l(Shuffler.shuffle(ar));
		O.l("==========");

		O.l(SelfCallva.findMinMaxByDivLR(ar, 0, ar.length));

		for (int i = 0; i < 1_000; i++) {

			Shuffler.shuffle(ar);

			if (!Arrays.equals(SelfCallva.findMinMaxByDivLR(ar, 0, ar.length), Ar32va.findMinMax(ar))) O.x();

			if (!Arrays.equals(Ar32va.findMinMaxByGroupEvenOdd(ar), Ar32va.findMinMax(ar))) O.x();

			if (!Arrays.equals(Ar32va.findMinMaxByCompaHeadTail(ar), Ar32va.findMinMax(ar))) O.x();

		}
	}
}
