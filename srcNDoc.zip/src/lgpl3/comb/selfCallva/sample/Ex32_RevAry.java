package lgpl3.comb.selfCallva.sample;

import java.util.Arrays;

import lgpl3.comb.selfCallva.SelfCallva;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;

/**
 * To sum with tail recursion.<br/>
 * TailRecurSum.
 *
 * @version 2022/12/17_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex32_RevAry" >src</a>
 *
 */
public class Ex32_RevAry {

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 10, 30, 70, 60 };
		int[] clonedAry = ary.clone();
		int[] clonedAry2 = ary.clone();

		O.l("bef===");
		O.l(ary);

		O.l("aft easyRev===");

		SelfCallva.easyRevAr32(ary, 0);

		O.l(ary);

		if (!Arrays.equals(ary, Ar32va.rev(clonedAry)))

			O.x();

		O.l("aft rev===");

		SelfCallva.revAr32(ary, 0);

		if (!Arrays.equals(ary, clonedAry2))

			O.x();

		O.l(ary);

	}
}
