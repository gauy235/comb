package lgpl3.comb.selfCallva;

/**
 * 本類別前進式自己呼叫自己的人.<br/>
 * To call self forward.
 *
 * @version 2022/12/14_10:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ForwardSelfCallva" >src</a>
 *
 * @see Recur
 */
public abstract class ForwardSelfCallva extends ForwardSelfCallva_A {
}
