package lgpl3.comb.sample;

import lgpl3.comb.DCirc;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.time.T64;

/**
 * 環狀排列且全錯排.<br/>
 * Derangement and circular permutation.
 *
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=D40_DCirc" >src</a>
 *
 * @see P93_PCircAsDnk
 * @see P96_ThrToPCircAsDnk
 * @see P98_PeerByThrToPCircAsDnk
 * @see D40_DCirc
 */
public class D40_DCirc {

	public static void main(String[] sAry) throws Throwable {

		int n = 6;
		int k = 4;

		long ary[], t0 = O.t();

		ary = DCirc.col(n, k);

		float costT = T64.difInF32Sec(t0);

		Aryva.checkDup(ary);

		// Arrays.sort(ary, 0, ary.length, CompaForAryOfB64W6.COMPA);

		O.l("ans=" + O.eq(ary.length, DCirc.int64(n, k)));

		O.l("ar[0]=" + B64W6.str24(ary[0]) + "=" + B64W6.strByVCellMinus1BySAry(ary[0], O.ARY_A_Z));

		O.l(DCirc.strByAryOfB64W6BySAry(ary, O.ARY_A_Z) + " costT=" + costT);

	}
}
