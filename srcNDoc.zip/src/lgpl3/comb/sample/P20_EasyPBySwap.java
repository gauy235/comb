package lgpl3.comb.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;
import lgpl3.o.ary.Aryva;
import lgpl3.o.keyNV.KArV32;
import lgpl3.o.time.T64;

/**
 * Permutation.<br/>
 *
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=P20_EasyPBySwap" >src</a>
 *
 */
public class P20_EasyPBySwap {

	public static void main1(String[] sAry) throws Throwable {

		int ar[] = { 1, 2, 3, 4 };

		long prefix = B64W6.genB64W6ByAr32(ar);

		Pnk.easyRecurBySwap(ar.length, prefix, 0);

		O.l("len=" + O.f(B.cnt));

	}

	public static void main(String[] sAry) throws Throwable {

		int n = 4;

		KArV32 kV = new KArV32((int) Pnk.int64(n));

		long prefix = B64W6.genB64W6ByAr32(Ar32va.genAscArFrom1(n)), retAr[] = kV.k, t0 = O.t();

		Pnk.easyColBySwap(n, prefix, kV, 0);

		float costT = T64.difInF32Sec(t0);

		Aryva.sortNCheckDup(retAr.clone());

		if (n <= 5) for (int idx = 0; idx != retAr.length; idx++) O.l(B64W6.strByVCellMinus1BySAry(retAr[idx], O.ARY_A_Z));

		O.l("len=" + O.f(O.eq(kV.v, Pnk.int64(n))) + " costT=" + costT + " cnt=" + O.f(B.cnt));

	}
}