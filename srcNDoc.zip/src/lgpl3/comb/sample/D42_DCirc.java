package lgpl3.comb.sample;

import lgpl3.comb.PcirDnk;
import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.thr.ThrToDCirc;
import lgpl3.o.O;
import lgpl3.o.time.T64;

/**
 * 環狀排列且全錯排.<br/>
 * Derangement and circular permutation.
 *
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=D42_DCirc" >src</a>
 *
 * @see P93_PcircAsDnk
 * @see P96_ThrToPCircAsDnk
 * @see P98_PeerByThrToPCircAsDnk
 * @see D42_DCirc
 */
public class D42_DCirc {

	public static void main(String[] sAry) throws Throwable {

		int n = 4;
		int k = 4;

		long ary[], t0 = O.t();

		ThrToDCirc thrToDCirc = new ThrToDCirc();
		thrToDCirc.col(n, k);

		float costT = T64.difInF32Sec(t0);

		ary = thrToDCirc.box.trim().ar;

		O.l("ans=" + PcirDnk.int64(n, k));

		O.eq(thrToDCirc.count32, PcirDnk.int64(n, k));
		O.eq(ary.length, PcirDnk.int64(n, k));

		// Arva.sort(ar);

		O.l("ary[0]=" + B64W6.strByVCellMinus1AftRevBySAry(ary[0], O.ARY_A_Z));

		O.l(Pnk.strByAryOfRevB64W6BySAry(ary, O.ARY_A_Z));

		O.l("len=" + O.f(ary.length));
		O.l("costT=" + costT);

	}
}
