package lgpl3.comb.sample;

import java.util.Arrays;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.comb.wDup.PWDup;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.ary.Seq;
import lgpl3.o.str.Strva;

/**
 * Permutation.<br/>
 *
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=P22_EasyPWDup" >src</a>
 *
 */
public class P22_EasyPWDup {

	private static final Class<?> THIS = P22_EasyPWDup.class;

	public static int ar32[] = { 1, 2, 2, 2, 3, 4, 4, };

	public static void main1(String[] sAry) throws Throwable {

		long prefix = B64W6.genB64W6ByAry32(ar32);

		PWDup.printBySwap(ar32.length, prefix, 0);

		O.l("len=" + O.f(B.cnt));

	}

	public static void main(String[] sAry) throws Throwable {

		String s = Arrays.toString(ar32).replace("[", O.S32);
		s = s.replace("]", O.S32);

		int k = (sAry = O.splitNTrimAll(s, O.S44)).length - 2;
		s = Strva.mergeInStr(sAry, O.S44).toString();

		////////////////////////////////////////////////////////

		DatWDup dat = new DatWDup();

		dat.oriS = s;
		dat.k = k;

		dat.initAll();

		O.l("allBit=" + B64W6.str24(dat.b64As2PowOfQRPlus1), THIS);

		Seq retSeq = new Seq();

		dat.tmpObj = retSeq;

		PWDup.easyColRecur(dat.b64As2PowOfQRPlus1, 0b0L, retSeq, k);

		////////////////////////////////////////////////////////

		long arOfB64W6[] = ((Seq) dat.tmpObj).trim().ary, b64W6;

		arOfB64W6 = Aryva.checkDup(arOfB64W6);

		for (int idx = 0; idx != arOfB64W6.length; idx++) {

			b64W6 = arOfB64W6[idx];

			O.l(B64W6.str24(b64W6));

			O.l((idx + 1) + "=>" + B64W6.strByVCellMinus1AftRevBySAry(b64W6, dat.distSortedSAry));

		}
	}
}