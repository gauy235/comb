package lgpl3.comb.sample;

import lgpl3.comb.Dnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;

/**
 * 排容原理.<br/>
 * 例如 :<br/>
 * A, B, C, D 排成一列, 但 A 不排第 1 位, B 不排第 2 位的方法數 :<br/>
 * 為 4 人有 2 人是限定條件 inEx(4,2).<br/>
 * <br/>
 * To return the inclusion and exclusion function result, the number of<br/>
 * that n people line up but k guys not at their position.<br/>
 * PInEx(n,k)=C(k,0)*n! -C(k,1)*(n-1)! +C(k,2)*(n-2)! - ... +-C(k,k)*(n-k)!
 *
 * @version 2023/11/13_12:30:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=D02_isDnk" >src</a>
 */
public class D02_isDnk {

	public static void main(String[] sAry) throws Throwable {

		long b64W6 = B64W6.genB64W6ByAr32(3, 2, 1);

		boolean isDnk = Dnk.isDnk(b64W6, B64W6.easySortAftTotalVCell(b64W6));

		O.l("isDnk=" + O.f(isDnk));

		b64W6 = B64W6.genB64W6ByAr32(1, 2, 3);

		O.l("b64W6=" + B64W6.str24(b64W6));

		long ret = B64W6.rotR(b64W6, B64W6.totalVCell(b64W6));

		O.l("rotR=" + B64W6.str24(ret));

		b64W6 = B64W6.genB64W6ByAr32(2, 1);

		O.l("b64W6=" + B64W6.str24(b64W6));

		O.l("easySort=" + B64W6.str24(B64W6.easySort(b64W6, B64W6.totalVCell(b64W6))));

	}
}
