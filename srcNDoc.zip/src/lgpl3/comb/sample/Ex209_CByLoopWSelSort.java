package lgpl3.comb.sample;

import lgpl3.b32.B32va;
import lgpl3.comb.Cnk;
import lgpl3.o.O;

/**
 * 組合.<br/>
 * Combination.
 *
 * @version 2022/05/08_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex209_CByLoopWSelSort" > Ex209_CByLoopWSelSort.java</a>
 */
public class Ex209_CByLoopWSelSort {

	public static void main(String[] sAry) throws Throwable {

		int n = 4;
		int k = 3;

		int[] ar32 = Cnk.colByLoopBreadthFirst(n, k);

		// CompaForAr32OfB32As2Pow.selSortDesc(ar);

		for (int idx = 0; idx != ar32.length; idx++)

			O.l(B32va.str16(ar32[idx]));

		O.l(Cnk.strByAryOfB32As2Pow(ar32));

		O.l("len=" + O.eq(ar32.length, Cnk.int64(n, k)));

	}
}
