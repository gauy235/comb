package lgpl3.comb.sample;

import lgpl3.comb.PcirDnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.time.T64;

/**
 * 環狀排列且全錯排.<br/>
 * Derangement and circular permutation.
 *
 * @version 2023/11/30_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=P90_PcirDnk" >src</a>
 *
 * @see P90_PcirDnk
 * @see P93_PcircAsDnk
 * @see P96_ThrToPCircAsDnk
 * @see P98_PeerByThrToPCircAsDnk
 */
public class P90_PcirDnk {

	public static void main(String[] sAry) throws Throwable {

		int n = 4;
		int k = 4;

		long t0 = O.t(), ar[] = PcirDnk.col(n, k);

		float costT = T64.difInF32Sec(t0);

		// B64W6.qSortAr(ar, 0, ar.length - 1);
		B64W6.mgSortAr(ar, 0, ar.length - 1);

		Aryva.checkDup(ar);

		O.l("ans=" + O.eq(ar.length, PcirDnk.int64(n, k)));
		O.l("ar[0]=" + B64W6.str24(ar[0]) + "=" + B64W6.strByVCellMinus1AftRevBySAry(ar[0], O.ARY_A_Z));

		for (int idx = 0; idx != ar.length; idx++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(ar[idx], O.ARY_A_Z) + "=" + B64W6.str24(ar[idx]));

		O.l("costT=" + costT);
	}
}
