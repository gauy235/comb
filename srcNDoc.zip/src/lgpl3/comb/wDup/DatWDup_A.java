package lgpl3.comb.wDup;

import java.io.Serializable;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.filter.CompaByVInKSV32;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Arr;
import lgpl3.o.keyNV.KSV32;
import lgpl3.o.keyNV.MapK64V32;
import lgpl3.o.keyNV.MapKSV32;

/**
 * The datum for to Hxy.<br/>
 *
 * @version 2020/02/19_20:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=DatWDup_A" >src</a>
 *
 * @see DatWDup
 */
public abstract class DatWDup_A implements Serializable { // 同時 for Hxy and C 或是 Hxy and P

	private static final Class<?> THIS = DatWDup_A.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * Default divisor.<br/>
	 */
	public static final int DEF_DIV32 = 6;

	public String oriS;

	public int k;

	public String[] catSortedSAry, distSortedSAry;

	public String[] sortByCntCatSAry, sortByCntDistSAry; // 多數那群放後面

	public long b64As2PowOfQRPlus1, b64W6OfQtyPlus1Desc; // sorted desc => A,B,B,C,C,C => 000000_000010_000011_000100

	public String regToIn = O.Z;

	public String regToEx = O.S64;

	public Matcher matcherIn, matcherEx; // Pattern.compile(regToIn).matcher(O.Z).reset(tmpStr);

	public int total32ToC, total32ToP;

	public int total32ToHxy;

	public MapK64V32 mapK64V32 = new MapK64V32(); // distinct set

	public StringBuilder retStrHxy = new StringBuilder(O.defLenForStr);

	public CharSequence prefixForRowNum = new StringBuilder();

	public CharSequence postfixForRowNum = new StringBuilder(O.S9);

	public CharSequence charSeqAsSeparator = new StringBuilder(O.S44);

	public CharSequence prefixForVal = new StringBuilder(O.S61); // charSeqAsDelimiter

	public CharSequence postfixForVal = new StringBuilder();

	public CharSequence lineWr = O.L;

	public Object tmpObj;

	/**
	 * To gen B64W6 of QRPlus1.<br/>
	 */
	public static long genB64As2PowOfQRPlus1(String[] catSAryAftSort) {

		long retB64As2PowOfQRPlus1 = 0b0L;

		String sHead = catSAryAftSort[0], s;

		for (int iS = 0, q = 0, r = 0; iS != catSAryAftSort.length;)

			if (sHead.equals(s = catSAryAftSort[iS])) {

				if (r++ == DEF_DIV32) throw new IndexOutOfBoundsException("s=" + s);

				retB64As2PowOfQRPlus1 |= 0b1L << (q + r);

				iS++;

			} else {

				sHead = s;

				q += DEF_DIV32;
				r = 0;

			}

		return retB64As2PowOfQRPlus1; // O.l("retB64As2PowOfQRPlus1=" + B64W6.str24(retB64As2PowOfQRPlus1), THIS);
	}

	/**
	 * To init.<br/>
	 */
	public void initHxy() {

		MapKSV32 map = (MapKSV32) new MapKSV32(catSortedSAry).sort(CompaByVInKSV32.COMPA); // sorted // 不可直接取出 map.arr

		O.l("mapHxy=" + O.L + map.toStr());

		sortByCntDistSAry = new String[map.i];

		KSV32 arOfKV[] = map.arr, kSV32;

		Arr<String> arrOfS = new Arr<String>(String.class);

		for (int iMap = 0, cnt; iMap != map.i; iMap++) {

			sortByCntDistSAry[iMap] = (kSV32 = arOfKV[iMap]).k; // O.l("kSV32=" + kSV32.toStr() + O.S64 + THIS);

			for (cnt = kSV32.v; cnt != 0; cnt--)

				arrOfS.a(kSV32.k);

			b64W6OfQtyPlus1Desc = (b64W6OfQtyPlus1Desc << B64W6.$6) | (kSV32.v + 1);

		}

		O.l("sortByCntDistSAry=" + O.L + Arrays.toString(sortByCntDistSAry));

		sortByCntCatSAry = arrOfS.trim().arr;

		O.l("sortByCntCatSAry=" + O.L + Arrays.toString(sortByCntCatSAry));

		O.l("b64W6OfQtyPlus1Desc=" + O.L + B64W6.str24(b64W6OfQtyPlus1Desc));

	}

	/**
	 * To init all.<br/>
	 */
	public void initAll() {

		String[] oriSAry = oriS.split(O.S44);

		Arrays.sort(oriSAry); // important

		catSortedSAry = oriSAry; // aft sort
		O.l("catSortedSAry" + O.S64 + THIS + "=" + O.L + Arrays.toString(catSortedSAry));

		distSortedSAry = new MapKSV32(oriSAry).allKey();
		O.l("distSortedSAry=" + O.L + Arrays.toString(distSortedSAry));

		b64As2PowOfQRPlus1 = genB64As2PowOfQRPlus1(catSortedSAry);
		O.l("b64As2PowOfQRPlus1=" + O.L + B64W6.str24(b64As2PowOfQRPlus1));

		matcherIn = Pattern.compile(regToIn).matcher(O.Z);
		matcherEx = Pattern.compile(regToEx).matcher(O.Z);

		initHxy();

	}
}
