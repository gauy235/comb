package lgpl3.comb.wDup;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.wDup.DatWDup_A.DEF_DIV32;

import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.sample.Ex704_Hxy;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.ary.Seq;

/**
 * CWDup<br/>
 * CWDup
 *
 * @version 2023/10/18_23:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=EasyCWDup" >src</a>
 *
 * @see Ex704_Hxy
 */
public class EasyCWDup {

	private static final Class<?> THIS = EasyCWDup.class;

	/**
	 * 從 1 列全相異數列中取出 k 個數.
	 */
	public static void easyColRecur(long rmdB64, int k, long prefix, Seq retSeq) {

		if (k-- == 0) {

			retSeq.a(prefix);

			return;
		}

		for (long old64 = (prefix <<= $6), cache = old64, low1; rmdB64 != 0b0L;) {

			prefix = old64 | (B64va.log2(low1 = -rmdB64 & rmdB64) / DEF_DIV32 + 1);

			rmdB64 &= ~low1;

			if (prefix != cache) easyColRecur(rmdB64, k, (cache = prefix), retSeq);

		}
	}

	/**
	 * CWDup<br/>
	 */
	public static DatWDup easyColRecur(String s, int k) {

		DatWDup dat = new DatWDup();

		dat.oriS = s;
		dat.k = k;

		dat.initAll();

		O.l("b64OfQRCell=" + O.L + B64W6.str24(dat.b64OfQRCell), THIS);

		easyColRecur(dat.b64OfQRCell, k, 0b0L, (Seq) (dat.tmpObj = new Seq()));

		return dat;
	}

	public static void main(String[] sAry) throws Throwable {

		String s = "A,B,B,C,C,C";

		int k = 3;

		DatWDup dat = easyColRecur(s, k);

		long arOfB64W6[] = ((Seq) dat.tmpObj).trim().ary, b64W6;

		arOfB64W6 = Aryva.checkDup(arOfB64W6);

		for (int idx = 0; idx != arOfB64W6.length; idx++) {

			b64W6 = arOfB64W6[idx];

			O.l((idx + 1) + "=" + B64W6.strByVCellMinus1AftRevBySAry(b64W6, dat.distSortedSAry) + " " + B64W6.str24(b64W6));

		}
	}
}