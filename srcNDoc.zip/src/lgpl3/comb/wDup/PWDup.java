package lgpl3.comb.wDup;

import java.util.Arrays;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.thr.ThrPWDupMan;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.ary.Seq;
import lgpl3.o.str.Strva;
import lgpl3.shareWXyz.Hxy;
import lgpl3.shareWXyz.HxyVal;

/**
 * @version 2019/08/17_18:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=PWDup" >src</a>
 *
 * @see Hxy
 */
public abstract class PWDup extends PWDup_V { // private static final Class<?> THIS = PWDup.class;

	/**
	 * If passes test.<br/>
	 */
	@SuppressWarnings("unused")
	public static void main(String[] sAry) throws Throwable {

		String s = "A,A,A,A,A,A,B,B,B,B,B,B,C,C,C,C,C,C,D,D,D,D,D,D,E,E,E,E,E,E,F,F,F,F,F,F";
		int k = 3;

		DatWDup dat;

		test1: {

			dat = new DatWDup();

			dat.oriS = s;
			dat.k = k;

			dat.initAll();

			long ans = HxyVal.int64WLim0ToMax(k, dat.distSortedSAry.length, dat.b64W6OfQtyPlus1Desc);

			long[] ary = Hxy.colWLim0ToMax(k, dat.distSortedSAry.length, dat.b64W6OfQtyPlus1Desc);

			Arrays.sort(ary);
			Aryva.chkDup(ary);

			O.eq(O.eq(ary.length, ans), 56);

		}

		test2: {

			s = "A,B,B,C,C,C";
			k = 3;

			dat = new DatWDup();

			dat.oriS = s;
			dat.k = k;

			dat.initAll();

			long ans = int64ByHxy(k, dat.sortByQtyDistSAry.length, dat.b64W6OfQtyPlus1Desc);

			new ThrPWDupMan(dat).run();

			O.eq(O.eq(dat.liK64V32.i, ans), 19);

		}

		// if (B.T) return;

		test3: {

			int ar32[] = { 1, 2, 2, 2, 3, 4, 4, };

			PWDup.printBySwap(ar32.length, B64W6.genB64W6ByAr32(ar32), 0);

			O.eq(PWDup.CHECKER.size(), 420);

			/////////////////////////////////////////////////////////

			s = Arrays.toString(ar32).replace("[", O.S32);
			s = s.replace("]", O.S32);

			k = (sAry = O.splitNTrimAll(s, O.S44)).length - 3;
			s = Strva.mergeInStr(sAry, O.S44).toString();

			dat = new DatWDup();

			dat.oriS = s;
			dat.k = k;

			dat.initAll();

			Seq retSeq = new Seq();

			PWDup.easyColRecur(dat.b64OfQRCell, k, 0b0L, retSeq);

			O.eq(Aryva.chkDup(retSeq.trim().ar).length, 114);

		}
	}
}
