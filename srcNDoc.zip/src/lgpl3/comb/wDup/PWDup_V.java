package lgpl3.comb.wDup;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MASK32;
import static lgpl3.comb.wDup.DatWDup_A.DEF_DIV32;

import java.util.HashSet;

import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;

/**
 * @version 2023/11/09_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=PWDup_V" >src</a>
 *
 * @see PWDup
 */
public abstract class PWDup_V extends PWDup_A { // private static final Class<?> THIS = PWDup_V.class;

	public static HashSet<Long> CHECKER = new HashSet<>();

	/**
	 * PWDup then just to print.<br/>
	 * 黃子嘉老師.<br/>
	 */
	public static void printBySwap(final int n, long prefix, int lv) { // easy n == k

		if (++lv == n) {

			B.cnt++;

			if (!CHECKER.add(prefix)) O.x();

			O.lv(lv, B64W6.strByVCellMinus1BySAry(prefix, O.ARY_A_Z) + O.S32 + B64W6.str24(prefix));

			return;
		}

		// O.lv(lv, B64W6.strByVCellMinus1BySAry(prefix, O.ARY_A_Z));

		printBySwap(n, prefix, lv); // 保送 不交換 一次跑到底

		int b = (0b1 << ((int) (prefix >>> ($6 * (lv - 1))) & MASK32)), newB, next = lv; // O.lv(lv, "b=" + B32va.log2(b));

		do if ((b & (newB = 0b1 << ((int) (prefix >>> ($6 * next)) & MASK32))) == 0b0) {

			b |= newB;

			printBySwap(n, B64W6.swapVCell(prefix, lv - 1, next), lv);

		}
		while (++next != n);

	}

	/**
	 * PWDup<br/>
	 */
	public static void easyColRecur(long rmdB64, long prefix, Seq retSeq, int kAsLv) {

		if (kAsLv-- == 0) {

			retSeq.a(prefix);

			return;
		}

		long myPrefix = (prefix <<= $6), cache = myPrefix, all1 = rmdB64, low1;

		for (; all1 != 0b0L; all1 &= ~low1) { // O.lv(kAsLv + 1, "myPrefix=" + B64W6.str24(myPrefix));

			prefix = myPrefix | (B64va.log2(low1 = all1 & -all1) / DEF_DIV32 + 1);

			if (prefix != cache) easyColRecur((rmdB64 & ~low1), (cache = prefix), retSeq, kAsLv);

		}
	}
}
