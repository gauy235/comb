package lgpl3.comb.wDup;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.shareWXyz.Hxy;
import lgpl3.shareWXyz.ShareWXyzVal;

/**
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=PWDup_A" >src</a>
 *
 * @see PWDup_U
 */
public abstract class PWDup_A { // private static final Class<?> THIS = PWDup_A.class;

	/**
	 * To permutate with duplicated char.<br/>
	 */
	public static long int64ByHxy(int k, int lenOfDistSAry, long b64W6OfQtyPlus1Desc) { // todo: 若 [1,1,5] 要先做 5! 後做 1!

		long ary[] = Hxy.colWLim0ToMax(k, lenOfDistSAry, b64W6OfQtyPlus1Desc), facK = Pnk.int64(k), ans = 0L;

		for (int idx = 0; idx != ary.length; idx++) ans += ShareWXyzVal.factorialNDiv(facK, ary[idx]);

		return ans;
	}

	/**
	 * To check.<br/>
	 */
	public static boolean isToPutOn_old(long prefixB64W6, int curQR, boolean isToPermutate) {

		int q = curQR / DatWDup.DEF_DIV32;
		int r = curQR % DatWDup.DEF_DIV32;

		if (prefixB64W6 == 0b0L && r == 0) return B.T;

		// O.l("isToPutOn: qR,q,r=" + O.L + qR + "," + q + "," + r);

		int maxRBehind = Integer.MIN_VALUE;// fuck
		do {

			int b6Minus1 = (((int) prefixB64W6) & B64W6.MSK) - 1;
			int qB6Minus1 = b6Minus1 / DatWDup.DEF_DIV32;

			// O.l("check q, qB6Minus1=" + O.L + q + ", " + qB6Minus1);
			if (q == qB6Minus1) {

				maxRBehind = b6Minus1 % DatWDup.DEF_DIV32; // rB6Minus1

				break;// fuck;

			}

		} while (isToPermutate && ((prefixB64W6 = prefixB64W6 >>> B64W6.$6) != 0b0L));

		// O.l("isToPutOn maxRBehind, q, r=" + O.L + maxRBehind + "," + q + "," + r);

		if (maxRBehind == Integer.MIN_VALUE) { // not the same q

			if (r == 0) return B.T;

		} else // check max r

			if (r == (maxRBehind + 1)) return B.T; // O.l("check rBase=" + rBase);

		return !B.T;
	}
}
