package lgpl3.comb.wDup.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.comb.wDup.PWDup;
import lgpl3.comb.wDup.thr.ThrPWDupMan;
import lgpl3.o.O;
import lgpl3.shareWXyz.Hxy;

/**
 * 排列 with duplicated.<br/>
 *
 * @version 2023/11/09_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex709_PWDup" >src</a>
 *
 * @see Ex704_Hxy
 * @see Ex708_ToC
 * @see Ex709_PWDup
 */
public abstract class Ex709_PWDup {

	public static void main(String[] sAry) throws Throwable {

		String s = "B,A,A,C";

		int k = 3;
		int min = 0;

		DatWDup dat = new DatWDup();

		dat.oriS = s;
		dat.k = k;

		// dat.regToEx = "C";
		// dat.regToIn = "(深,深|_,)";
		// dat.regToEx = "(A,A|_,)";

		dat.initAll();

		/////////////////////////////////////////////////////

		long arOfB64W6[] = Hxy.colWLim0ToMax(dat.k, dat.sortByQtyDistSAry.length, dat.b64W6OfQtyPlus1Desc),

				ans = PWDup.int64ByHxy(dat.k, dat.sortByQtyDistSAry.length, dat.b64W6OfQtyPlus1Desc);

		for (int idx = 0; idx != arOfB64W6.length; idx++)

			O.l("[" + Hxy.strByVCellPlusMinMinus1(arOfB64W6[idx], min) + "]=" + B64W6.str24(arOfB64W6[idx]));

		new ThrPWDupMan(dat).run();

		O.l(dat.strAftCOrP());

		O.l("ans=" + ans + " cntP=" + dat.cntP);

		O.eq(dat.mapK64V32.i, ans); // dat.regToEx = "C";

	}
}
