package lgpl3.comb.wDup.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.comb.wDup.PWDup;
import lgpl3.comb.wDup.thr.ThrToPWDup;
import lgpl3.o.O;
import lgpl3.shareWXyz.Hxy;

/**
 * To pick with duplicated.<br/>
 *
 * @version 2019/08/17_16:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex709_ToP" >Ex709_ToP.java</a>
 *
 * @see Ex704_Hxy
 *
 * @see Ex708_ToC
 *
 * @see Ex709_ToP
 */
public abstract class Ex709_ToP {

	public static void main(String[] sAry) throws Throwable {

		String s = "B,A,A,C";

		int iWantPickN = 3;
		// int min = 0;

		DatWDup dat = new DatWDup();

		dat.oriS = s;
		dat.k = iWantPickN;

		// datum.regToEx = "C";
		// datum.regToIn = "(深,深|_,)";
		// datum.regToEx = "(A,A|_,)";

		dat.initAll();

		/////////////////////////////////////////////////////

		long[] aryOfB64W6 = Hxy.colWLim0ToMax(dat.k, dat.sortByCntDistSAry.length, dat.b64W6OfQtyPlus1Desc);
		O.l("aryOfB64W6.len=" + aryOfB64W6.length);

		final int min = 0;
		for (int i = 0; i != aryOfB64W6.length; i++) {

			O.l("B64W6=" + B64W6.str24(aryOfB64W6[i]));
			StringBuilder retStr = new StringBuilder();
			retStr.append(O.C91).append(Hxy.strByVCellPlusMinMinus1(aryOfB64W6[i], min)).append(O.C93);

			O.l(retStr);

		}

		long ans = PWDup.int64ByHxy(dat.k, dat.sortByCntDistSAry.length, dat.b64W6OfQtyPlus1Desc);

		new ThrToPWDup(dat).run();

		O.l(dat.strAftCOrP());

		O.l("ans=" + O.eq(dat.mapK64V32.i, ans) + " count=" + dat.cntP32);

	}
}
