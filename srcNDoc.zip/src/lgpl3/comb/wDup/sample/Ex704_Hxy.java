package lgpl3.comb.wDup.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.wDup.DatWDup;
import lgpl3.o.O;
import lgpl3.recycle.Zw_EasyCWDup;
import lgpl3.shareWXyz.Hxy;
import lgpl3.shareWXyz.HxyVal;

/**
 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
 * To return the number of ways to share several identical items with every person.
 *
 * @version 2023/09/18_23:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex704_Hxy" >src</a>
 *
 * @see Ex704_Hxy
 *
 * @see Ex708_ToC
 *
 * @see Ex709_ToP
 *
 * @see Zw_EasyCWDup
 */
public abstract class Ex704_Hxy {

	public static void main(String[] sAry) throws Throwable {

		String s = "X,C,C,C";
		// String s = "C,C,C,A";

		int k = 3;

		DatWDup dat = new DatWDup(); // zw108.regToEx = "C,A";
		dat.oriS = s;
		dat.k = k;
		dat.initAll();

		///////////////////////////////////////

		long ans = HxyVal.int64WLim0ToMax(dat.k, dat.sortByCntDistSAry.length, dat.b64W6OfQtyPlus1Desc),

				aryOfB64W6[] = Hxy.colWLim0ToMax(dat.k, dat.sortByCntDistSAry.length, dat.b64W6OfQtyPlus1Desc), b64W6;

		int min = 0, i;
		for (i = 0; i != aryOfB64W6.length; i++) {

			b64W6 = aryOfB64W6[i];

			O.l(B64W6.str24(b64W6));

			O.l(new StringBuilder().append(O.C91).append(Hxy.strByVCellPlusMinMinus1AftRev(b64W6, min)).append(O.C93));

		}

		if (ans != aryOfB64W6.length) O.x("ans=" + ans + ", len=" + aryOfB64W6.length);

		///////////////////////////////////////

		dat.addAftInExByHxy(aryOfB64W6);

		O.l("total=" + O.f(dat.total32ToHxy));
		O.l(dat.retStrHxy);

	}
}
