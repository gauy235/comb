package lgpl3.comb.wDup.sample;

import lgpl3.comb.wDup.DatWDup;
import lgpl3.comb.wDup.thr.ThrToCWDup;
import lgpl3.o.O;
import lgpl3.shareWXyz.HxyVal;

/**
 * To pick with duplicated.<br/>
 *
 * @version 2020/02/15_17:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex708_ToC" >Ex708_ToC.java</a>
 *
 * @see Ex704_Hxy
 *
 * @see Ex708_ToC
 *
 * @see Ex709_PWDup
 */
public abstract class Ex708_ToC {

	public static void main(String[] sAry) throws Throwable {

		// String s = "1,2,3,4,1,2,3,4,5,6,5,6";
		String s = "A,B,B,C,C,C";

		int iWantPickN = 2;
		// int min = 0;

		DatWDup datWDup = new DatWDup();

		datWDup.oriS = s;
		datWDup.k = iWantPickN;

		// datum.regToEx = "C";

		datWDup.initAll();

		ThrToCWDup thrToCWDup = new ThrToCWDup(datWDup);
		thrToCWDup.run();

		long ans = HxyVal.int64WLim0ToMax(iWantPickN, datWDup.sortByQtyDistSAry.length, datWDup.b64W6OfQtyPlus1Desc);
		O.l("ans=" + O.f(ans));

		O.l("toStrAftCOrP=");
		O.l(datWDup.strAftCOrP());

		O.l("cntC=" + datWDup.cntC + O.S9 + Ex708_ToC.class);

	}
}
