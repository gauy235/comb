package lgpl3.comb;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Arr;
import lgpl3.o.keyNV.K64V64V64;

/**
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Pnk_J" >src</a>
 *
 * @see Pnk_W
 */
public abstract class Pnk_J extends Pnk_H {

	private static final Class<?> THIS = Pnk_J.class;

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * 剪尾巴後再延伸法, 砲彈互斥法.
	 */
	// rule: [1,2,3] => 1,2,31,32=>1,2,31,(321)=>1,2,(312),(321)=>1,23,21,(312),(321)=>...

	public static long[] colByLoopBreadthNDepthFirst(int n, int kAsLv) { // 原創

		int rmdB32 = ~(-0b1 << n), all1 = rmdB32, low1, iStk = 0, iRet = 0;

		K64V64V64 stack[] = new K64V64V64[(n - 1) * kAsLv + 1], topKV; // todo: 縮小 stack size

		O.l("stackLen=" + stack.length, THIS);

		long ret[] = new long[(int) int64(n, kAsLv)], prefix;

		if (--kAsLv == 0) {

			do ret[iRet++] = n; while (--n != 0);

			return ret;
		}

		// init [rmd, prefix, k as lv]

		do stack[iStk++] = new K64V64V64((~(low1 = -all1 & all1) & rmdB32), B32va.log2NPlus1(low1), kAsLv);

		while ((all1 = ~low1 & all1) != 0b0);

		// init end

		O.l("kAsLv=" + kAsLv, THIS);
		O.l("stack=" + O.L + new Arr<K64V64V64>(stack).toStr(), THIS);
		O.l("iStk=" + iStk, THIS);

		do {
			topKV = stack[--iStk];

			rmdB32 = (int) topKV.k; // O.l("rmdB32=" + B32va.str16(rmdB32), THIS);
			prefix = topKV.v1 << B64W6.$6;
			kAsLv = (int) topKV.v2;

			if (--kAsLv == 0) // 檢查是否剩下最後 1 個位元

				do ret[iRet++] = (prefix | B64va.log2NPlus1(low1 = -rmdB32 & rmdB32)); while ((rmdB32 = ~low1 & rmdB32) != 0b0);
			else {

				all1 = rmdB32;

				do stack[iStk++] = new K64V64V64((~(low1 = -all1 & all1) & rmdB32), (prefix | B32va.log2NPlus1(low1)), kAsLv);

				while ((all1 = ~low1 & all1) != 0b0); // stack 增長 長尾巴
			}

		} while (iStk != 0);

		return ret;
	}
}
