package lgpl3.comb;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;
import lgpl3.o.keyNV.KArV32;

/**
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Pnk_H" >src</a>
 *
 * @see Pnk_J
 */
public abstract class Pnk_H extends Pnk_A { // private static final Class<?> THIS = Pnk_H.class;

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * To pick several numbers from a list of distinct numbers then to permutate.
	 */
	public static void colRecurWNEqK(int rmdB32, long prefix, KArV32 ar) {

		prefix <<= $6;

		if ((-rmdB32 & rmdB32) == rmdB32) {

			ar.k[ar.v++] = prefix | B32va.log2NPlus1(rmdB32);

			return;
		}

		int all1 = rmdB32, low1; // O.l("bullet=" + B32va.str16(allBullet));

		do colRecurWNEqK((~(low1 = (-all1 & all1)) & rmdB32), (prefix | B64va.log2NPlus1(low1)), ar);

		while ((all1 = (~low1 & all1)) != 0b0); // 子彈打完
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * To pick several numbers from a list of distinct numbers then to permutate.
	 */
	public static long[] colRecur(int n, int k) { // fuck, about 30, see toStrToOntoBySAryByB32, B32va.log2

		if (n <= 0 || n > 30 || k <= 0 || n < k) O.x("n=" + n + ", k=" + k);

		int[] ar32 = Cnk.colRecur(n, k);

		KArV32 retKV = new KArV32(int64(n, k));

		for (int idx = 0; idx != ar32.length; idx++) colRecurWNEqK(ar32[idx], 0b0L, retKV);

		return retKV.k;
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * To pick several numbers from a list of distinct numbers then to permutate.
	 */
	public static void colRecurWNGteK(int rmdB32, long prefix, KArV32 ar, int lv) {

		B.cnt++;

		prefix <<= $6;

		if (--lv == 0) { // O.l("rmdB32=" + rmdB32);

			// 借用 lv 當 lowest1
			do ar.k[ar.v++] = (prefix | B64va.log2NPlus1(lv = -rmdB32 & rmdB32)); while ((rmdB32 = ~lv & rmdB32) != 0b0);

			return;
		}

		int all1 = rmdB32, low1; // O.l("bullet=" + B32va.str16(allBullet)); // todo: bullet => low1

		do colRecurWNGteK((~(low1 = -all1 & all1) & rmdB32), (prefix | B64va.log2NPlus1(low1)), ar, lv);

		while ((all1 = ~low1 & all1) != 0b0); // 子彈打完
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * To pick several numbers from a list of distinct numbers then to permutate.
	 */
	public static void colByLoopBreadth(int baseB32, long prefix, Seq seq) {

		baseB32 = B64W6.filterAftToB32As2PowByVCell(baseB32, prefix); // 借用 baseB32 當 rmdB32

		prefix <<= $6;

		int low1;

		do seq.a(prefix | B32va.log2NPlus1(low1 = (-baseB32 & baseB32))); while ((baseB32 = (~low1 & baseB32)) != 0b0);
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 * To pick several numbers from a list of distinct numbers then to permutate.
	 */
	public static long[] colByLoopBreadth(int n, int k) { // 如同廣先搜尋

		int baseB32 = ~(-0b1 << n), idx = 1; // O.l("baseB32=" + baseB32, THIS);

		Seq seqHot = new Seq(), seqCold = new Seq(), tmpSeq; // 提升可閱讀性 但是浪費記憶體

		// init
		do seqHot.a(idx); while (idx++ != n);

		if (--k == 0) return seqHot.trim().ary;

		do {
			idx = 0;
			n = seqHot.i;

			// 如同廣先搜尋
			do colByLoopBreadth(baseB32, seqHot.ary[idx], seqCold); while (++idx != n); // termination condition

			// swap 重複使用
			tmpSeq = seqHot;
			seqHot = seqCold;
			(seqCold = tmpSeq).i = 0; // 原創 節省空間
			tmpSeq = null;
			// end swap 重複使用

		} while (--k != 0);

		return seqHot.trim().ary;
	}
}
