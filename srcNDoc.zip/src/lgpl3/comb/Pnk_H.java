package lgpl3.comb;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;
import lgpl3.o.keyNV.KArV32;

/**
 * @version 2023/11/12_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Pnk_H" >src</a>
 *
 * @see Pnk_J
 */
public abstract class Pnk_H extends Pnk_A { // private static final Class<?> THIS = Pnk_H.class;

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static void colRecurWNEqK(int rmdB32, long prefix, KArV32 retKV) {

		prefix <<= $6;

		if ((-rmdB32 & rmdB32) == rmdB32) {

			retKV.k[retKV.v++] = prefix | B32va.lgAd(rmdB32);

			return;
		}

		int allLo1 = rmdB32, lo1; // O.l("allLo1=" + B32va.str16(allLo1));

		do colRecurWNEqK((rmdB32 & ~(lo1 = -allLo1 & allLo1)), (prefix | B64va.lgAd(lo1)), retKV);

		while ((allLo1 &= ~lo1) != 0b0); // allLo1 子彈打完
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static long[] colRecur(int n, int k) { // fuck, about 30, see toStrToOntoBySAryByB32, B32va.lg

		if (n <= 0 || n > 30 || k <= 0 || n < k) O.x("n=" + n + ", k=" + k);

		int[] ar32 = Cnk.colRecur(n, k);

		KArV32 retKV = new KArV32((int) int64(n, k));

		for (k = 0; k != ar32.length; k++) colRecurWNEqK(ar32[k], 0b0L, retKV); // 借 k 來用

		return retKV.k;
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static void colRecurWNGteK(int rmdB32, int kAsLv, long prefix, KArV32 retKV) {

		B.cnt++;

		prefix <<= $6;

		if (--kAsLv == 0) { // O.l("rmdB32=" + rmdB32);

			int lo1;

			do retKV.k[retKV.v++] = (prefix | B64va.lgAd(lo1 = -rmdB32 & rmdB32)); while ((rmdB32 &= ~lo1) != 0b0);

			return;
		}

		int allLo1 = rmdB32, lo1; // O.l("allLo1=" + B32va.str16(allLo1));

		do colRecurWNGteK((rmdB32 & ~(lo1 = -allLo1 & allLo1)), kAsLv, (prefix | B64va.lgAd(lo1)), retKV);

		while ((allLo1 &= ~lo1) != 0b0); // allLo1 子彈打完
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static void convertNFilterNCol(long prefix, int baseB32, Seq seq) {

		long pre = prefix << $6;

		int keptB32OrLo1 = 0b0;

		do keptB32OrLo1 |= 0b1 << (((int) prefix & B64W6.MSK) - 1); while ((prefix >>>= $6) != 0b0L);

		baseB32 &= ~keptB32OrLo1; // 排除既有

		do seq.a(pre | B32va.lgAd(keptB32OrLo1 = -baseB32 & baseB32)); while ((baseB32 &= ~keptB32OrLo1) != 0b0);
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static long[] colByLoopBreadth(int n, int k) { // 如同廣先搜尋

		int baseB32 = ~(-0b1 << n), idx = 1; // O.l("baseB32=" + B32va.str16(baseB32), THIS);

		Seq allBody = new Seq(), allTail = new Seq(), tmp;

		// init
		do allBody.a(idx); while (idx++ != n);

		if (--k == 0) return allBody.trim().ar;

		do {
			idx = 0;

			do convertNFilterNCol(allBody.ar[idx], baseB32, allTail); while (++idx != allBody.i); // 如同廣先搜尋

			// swap 重複使用空間

			tmp = allBody;
			allBody = allTail;
			(allTail = tmp).i = 0; // 原創 節省空間

			// end swap 重複使用空間

		} while (--k != 0); // 廣先 第幾層

		return allBody.trim().ar;
	}
}
