package lgpl3.comb;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MASK32;

/**
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=PcirDnk_Q" >src</a>
 *
 * @see PcirDnk
 */
public abstract class PcirDnk_Q extends PcirDnk_J { // private static final Class<?> THIS = PcirDnk_Q.class;

	/**
	 * To swap.
	 */
	public static long[] swapV(long[] ary, int i, int j) {

		long tmpV = ary[i];

		ary[i] = ary[j];
		ary[j] = tmpV;

		return ary;
	}

	/**
	 * To compare.<br/>
	 */
	public static int compaB64W6(long b64W6A, long b64W6B) { // 比較 head

		int vA, vB; // O.l("b64W6A=" + B64W6.str24(b64W6A));
		do {
			vA = (int) b64W6A & MASK32;
			vB = (int) b64W6B & MASK32;

			if ((vA -= vB) != 0) return vA;

			b64W6A >>>= $6;

		} while ((b64W6B >>>= $6) != 0b0L);

		return 0;
	}

	/**
	 * To partition.<br/>
	 */
	public static int easyIdxPivot(long[] ary, int left, int right) {

		int iCnt = left;

		long pivot = ary[left]; // 陣列頭當 pivot

		for (int j = left + 1; j <= right; j++)

			if ((compaB64W6(ary[j], pivot) < 0) && (++iCnt != j)) swapV(ary, iCnt, j); // 小的排在我左邊

		swapV(ary, left, iCnt); // 最後 跟 那群小朋友的尾巴 交換

		return iCnt;
	}

	/**
	 * quickSort.<br/>
	 */
	public static long[] quickSortAryOfB64W6(long[] ary, int left, int right) {

		if (left < right) {

			int iPivot = easyIdxPivot(ary, left, right);

			quickSortAryOfB64W6(ary, left, iPivot - 1);

			quickSortAryOfB64W6(ary, iPivot + 1, right);
		}

		return ary;
	}
}
