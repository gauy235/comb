package lgpl3.comb;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MASK32;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.keyNV.KArV32;

/**
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=DCirc_J" >src</a>
 *
 * @see DCirc
 */
public abstract class DCirc_J extends DCirc_A {

	private static final Class<?> THIS = DCirc_J.class;

	public static boolean isPCircAsDnk(long b64W6, int b32As2PowByVCell) {

		int len = B64W6.totalVCell(b64W6);
		do {
			if (Dnk.isDnk(b64W6, b32As2PowByVCell)) return B.T;

			b64W6 = (b64W6 >>> $6) | ((b64W6 & MASK32) << --len * $6);

		} while (len != 0);

		return !B.T;
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static void colRecurWNEqK(int rmdB32, long prefix, KArV32 retKV) {

		prefix <<= $6;

		if ((-rmdB32 & rmdB32) == rmdB32) {

			prefix |= B32va.lgAd(rmdB32); // 等到最末尾 VCell 加入 才檢查嗎

			if (isPCircAsDnk(prefix, B64W6.b32As2PowByVCell(prefix))) retKV.k[retKV.v++] = prefix;

			return;
		}

		int allLo1 = rmdB32, lo1; // O.l("allLo1=" + B32va.str16(allLo1));

		do colRecurWNEqK((rmdB32 & ~(lo1 = -allLo1 & allLo1)), (prefix | B64va.lgAd(lo1)), retKV);

		while ((allLo1 &= ~lo1) != 0b0); // allLow1 子彈打完
	}

	/**
	 * 從 1 列全相異數列中取出 k 個數.<br/>
	 * To pick several numbers from a list of distinct numbers.
	 */
	public static void cBefColWNEqK(final int boundBit, int rmdK, int prefix, int curBit, KArV32 ret) {

		if (--rmdK == 0) {

			// 先環狀排列

			do colRecurWNEqK((curBit | prefix), 0b0L, ret); while ((curBit <<= 1) != boundBit);

			return;
		}

		int newBoundBit = boundBit >>> rmdK;

		do cBefColWNEqK(boundBit, rmdK, (curBit | prefix), (curBit <<= 1), ret);

		while (curBit != newBoundBit);
	}

	/**
	 * 在一個已完成的錯排隊伍 (全錯排) 中, 若 n 坐了第 k 位:<br/>
	 * 情況 1: 假設 k 去坐第 n 位時, 除了 n 和 k 以外還有 n-2 人, 其錯排數為 D(n-2)<br/>
	 *
	 * 情況 2: 假設 k 不坐在第 n 位 (強假設), 可把第 n 位當成一個另類的 "第 k 位" (k 的忌諱)<br/>
	 * 這時包括 k 在內的剩下 n-1 人形成的每一種錯排,<br/>
	 * 都等價於 n-1 人隊伍的錯排 (只是其中 k 這人的忌諱已變成第 n 位)<br/>
	 *
	 * 尼古拉一世·伯努利: Dn=(n-1)*(Dn-1+Dn-2)
	 */
	public static long[] col(int n, int k) { // fuck, about 30, see toStrToOntoBySAryByB32, B32va.lgAtB32

		if (n <= 0 || n > 30 || k <= 0 || n < k) O.x("n=" + n + ", k=" + k);

		if (k == 1) return O.ARY0;

		KArV32 retKV = new KArV32((int) int64(n, k));

		cBefColWNEqK((0b1 << n), k, 0b0, 0b1, retKV);

		return retKV.k;
	}
}
