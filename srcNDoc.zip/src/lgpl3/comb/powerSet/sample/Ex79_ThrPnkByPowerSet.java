package lgpl3.comb.powerSet.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.powerSet.thr.ThrCnkByPowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.time.T64;
import lgpl3.shareWXyz.Hnr;
import lgpl3.shuffle.Shuffler;

/**
 * To Pnk.<br/>
 * To Pnk.
 *
 * @version 2023/05/17_18:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex79_ThrPnkByPowerSet" >src</a>
 *
 */
public class Ex79_ThrPnkByPowerSet {

	public static void main(String[] sAry) throws Throwable {

		int n = 11;
		int k = n - 4;

		float rate = 2.4F;

		long ans = Pnk.int64(n, k), retAr[];

		ThrCnkByPowerSet thr = new ThrCnkByPowerSet(n, k, B.T);

		Hnr.transposeArOfB64W6(thr.box);

		for (; (retAr = Shuffler.shuffleForPnk(thr.box, k, rate)).length != ans; rate *= rate);

		Aryva.sortNCheckDup(retAr);

		if (k <= 4) for (int idx = 0; idx != retAr.length; idx++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(retAr[idx], O.ARY_A_Z));

		O.l("len=" + O.f(retAr.length) + " t=" + T64.difInF32Sec(thr.tStart) + " ans=" + O.f(ans));

	}
}
