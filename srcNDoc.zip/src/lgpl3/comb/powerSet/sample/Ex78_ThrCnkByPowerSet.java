package lgpl3.comb.powerSet.sample;

import lgpl3.comb.Cnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.powerSet.thr.ThrCnkByPowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.shareWXyz.Hnr;

/**
 * To gen subset.<br/>
 *
 * @version 2023/11/28_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex78_ThrCnkByPowerSet" >src</a>
 *
 */
public class Ex78_ThrCnkByPowerSet {

	public static void main(String[] sAry) throws Throwable {

		final int nOfElem = 5;
		final int k = 4;

		ThrCnkByPowerSet thr = new ThrCnkByPowerSet(nOfElem, k, B.T);

		O.l("bef box[0]=" + B64W6.str24(thr.box[0]));

		long[] transposedAr = Hnr.transposeArOfB64W6(thr.box);

		O.l("box[0]=" + B64W6.str24(thr.box[0]));

		for (int idx = 0; idx != transposedAr.length; idx++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(transposedAr[idx], O.ARY_A_Z) + "=" + B64W6.str24(transposedAr[idx]));

		O.l("ans=" + O.eq(thr.iLen, Cnk.int64(nOfElem, k)));

		O.l("B.cnt=" + B.cnt);

		B.cnt = 0;

	}
}
