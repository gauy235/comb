package lgpl3.comb.powerSet.sample;

import lgpl3.b32.B32va;
import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;

/**
 * To gen all subsets.<br/>
 *
 * @version 2023/04/24_23:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex17_ColRecurByExtTail" >src</a>
 *
 */
public class Ex17_ColRecurByExtTail {

	public static void main(String[] sAry) throws Throwable {

		int n = 4;

		int ret[] = PowerSet.colRecurByExtTail(n), idx = 0, len = Ar32va.checkDup(ret).length;

		while (idx != len) O.l(B32va.strByLog2Hi1BySAry(ret[idx++], O.ARY_A_Z));

		O.l("total=" + ret.length);

		O.l("B.cnt=" + B.cnt);

		B.cnt = 0;

	}
}
