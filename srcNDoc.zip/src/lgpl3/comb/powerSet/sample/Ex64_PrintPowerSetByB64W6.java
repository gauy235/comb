package lgpl3.comb.powerSet.sample;

import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.B;
import lgpl3.o.O;

/**
 * printPowerSetByB64W6.<br/>
 * printPowerSetByB64W6.
 *
 * @version 2022/11/29_10:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex64_PrintPowerSetByB64W6" >src</a>
 *
 */
public class Ex64_PrintPowerSetByB64W6 {

	public static void main(String[] sAry) throws Throwable {

		int[] ary = { 10, 20, 30 };

		O.l("ary=");
		O.l(ary);
		O.l("=======");

		PowerSet.printByB64W6(ary, 0b0L, 0, 0);

		O.l("B.n32=" + B.cnt);
		B.cnt = 0;

	}
}
