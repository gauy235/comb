package lgpl3.comb.powerSet.thr;

import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.thr.ThrWBox;

/**
 * To give change.<br/>
 * To give change.
 *
 * @version 2022/01/28_20:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ThrGiveChange" >ThrGiveChange.java</a>
 *
 */
public class ThrGiveChange extends ThrWBox<long[]> {

	// private static final Class<?> THIS = ThrGiveChange.class;

	public int[] baseAr32;

	public int targetV32;

	/**
	 * 建構方法.<br/>
	 * baseAr32 array must be descend.<br/>
	 * baseAr32 array can not contain 0 or negative element.
	 */
	public ThrGiveChange(int[] baseAr32, int targetV, boolean isToRun) {

		this.baseAr32 = baseAr32;
		this.targetV32 = targetV;

		if (isToRun)

			run();

	}

	@Override
	public void run() {

		box = PowerSet.colAllMatchV(baseAr32, targetV32);
	}
}