package lgpl3.comb.powerSet.thr;

import lgpl3.comb.Cnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.thr.ThrWBox;

/**
 * To gen subset.<br/>
 * To gen subset.
 *
 * @version 2022/09/20_21:30:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ThrCnkByPowerSet" >src</a>
 *
 */
public class ThrCnkByPowerSet extends ThrWBox<long[]> { // in Eastern way

	private static final Class<?> THIS = ThrCnkByPowerSet.class;

	public final int nOfElem;

	public final int k;

	public static final int $YES = 0b1; // todo: 吃 Hnr $YES

	public static final int $NO = 0b0; // todo: 吃 Hnr $$NO

	public int iLen;

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	public ThrCnkByPowerSet(int nOfElem, int k, boolean isToRun) {

		this.nOfElem = nOfElem;

		this.k = k;

		box = new long[(int) Cnk.int64(nOfElem, k)];

		if (isToRun) // pickItOrNot(0b0L, nOfElem);

			run();

	}

	/**
	 * To pick it or not.<br/>
	 * 旗標跟人名互換:<br/>
	 *
	 * 甲 乙 丙 丁<br/>
	 * Y N N Y => 甲丁
	 *
	 * 甲 乙 丙 丁<br/>
	 * Y Y N N => 甲乙
	 *
	 * 另外想法:<br/>
	 * [A,B,D|C] => 甲甲乙甲
	 */
	public void pickItOrNot(long prefix, int lv) {

		B.cnt++;

		O.lv(lv, "prefix=" + B64W6.str24(prefix));

		if (lv == nOfElem) {

			if (Long.bitCount(prefix) == k)

				O.lv(lv, "ad=" + B64W6.str24(box[iLen++] = prefix));

			return;

		}

		int bitCount = Long.bitCount(prefix);

		if ((bitCount > k) || (bitCount + (nOfElem - lv)) < k) {

			O.lv(lv, "termin=" + B64W6.str24(prefix));

			return;

		}

		if (bitCount == k)

			O.lv(lv, "ad2=" + B64W6.str24(box[iLen++] = prefix << (B64W6.$6 * (nOfElem - lv))));

		else { // bitCount < k

			pickItOrNot(((prefix << B64W6.$6) | $YES), lv + 1);
			pickItOrNot(((prefix << B64W6.$6) | $NO), lv + 1);

		}
	}

	@Override
	public void run() {

		pickItOrNot($YES, 1);
		pickItOrNot($NO, 1);

	}

	/**
	 * To transpose.
	 */
	// 會改變 box 內容
	public long[] transpose() { // 原創

		long oldB64, newB64;

		for (int iBox = 0, myOrder; iBox != iLen; box[iBox++] = newB64) {

			oldB64 = box[iBox]; // O.l("oldB64=" + B64W6.str24(oldB64), THIS);

			myOrder = 1;
			newB64 = 0b0L;

			do {
				if ((((int) oldB64) & B64W6.MASK32) == $YES)

					newB64 = (newB64 << B64W6.$6) | myOrder;

				if ((oldB64 >>>= B64W6.$6) == 0b0L)

					break;

				myOrder++;

			} while (B.T);

		}

		return box;

	}
}
