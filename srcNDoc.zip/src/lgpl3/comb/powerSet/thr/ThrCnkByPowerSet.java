package lgpl3.comb.powerSet.thr;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;

import lgpl3.comb.Cnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.thr.ThrWBox;

/**
 * To gen subset.<br/>
 *
 * @version 2023/11/28_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=ThrCnkByPowerSet" >src</a>
 *
 */
public class ThrCnkByPowerSet extends ThrWBox<long[]> { // in Eastern way

	// private static final Class<?> THIS = ThrCnkByPowerSet.class;

	public final int nOfElem;

	public final int k;

	public static final int $YES = 0b1; // todo: 吃 Hnr $YES

	public static final int $NO = 0b0; // todo: 吃 Hnr $$NO

	public int iLen;

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	public ThrCnkByPowerSet(int nOfElem, int k, boolean isToRun) {

		this.nOfElem = nOfElem;

		this.k = k;

		box = new long[(int) Cnk.int64(nOfElem, k)];

		if (isToRun) run(); // pickItOrNot(0b0L, nOfElem);

	}

	/**
	 * To pick it or not.<br/>
	 * 旗標跟人名互換:<br/>
	 *
	 * 甲 乙 丙 丁<br/>
	 * Y N N Y => 甲丁
	 *
	 * 甲 乙 丙 丁<br/>
	 * Y Y N N => 甲乙
	 *
	 * 另外想法:<br/>
	 * [A,B,D|C] => 甲甲乙甲
	 */
	public void pickItOrNot(long prefix, int lv) {

		B.cnt++;

		O.lv(lv, "prefix=" + B64W6.str24(prefix));

		if (lv == nOfElem) {

			if (Long.bitCount(prefix) == k) O.lv(lv, "ad=" + B64W6.str24(box[iLen++] = prefix));

			return;
		}

		int bitCount = Long.bitCount(prefix);

		if ((bitCount > k) || (bitCount + (nOfElem - lv)) < k) {

			O.lv(lv, "termin=" + B64W6.str24(prefix));

			return;
		}

		if (bitCount == k) O.lv(lv, "ad2=" + B64W6.str24(box[iLen++] = prefix << ($6 * (nOfElem - lv))));

		else { // bitCount < k

			pickItOrNot(((prefix << $6) | $YES), lv + 1);
			pickItOrNot(((prefix << $6) | $NO), lv + 1);
		}
	}

	@Override
	public void run() {

		pickItOrNot($YES, 1);
		pickItOrNot($NO, 1);
	}
}
