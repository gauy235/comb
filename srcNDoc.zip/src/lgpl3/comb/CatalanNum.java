package lgpl3.comb;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.selfCallva.SelfCallva;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;
import lgpl3.o.ary.Aryva;
import lgpl3.o.keyNV.KArV32;

/**
 * C(2n,n)-C(2n,n-1)<br/>
 * Catalan number: 1, 2, 5, 14...
 *
 * @version 2022/10/06_11:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=CatalanNum" >src</a>
 *
 * @see SelfCallva
 */
public abstract class CatalanNum {

	private static final Class<?> THIS = CatalanNum.class;

	public static final int ID_AS_WIN = 0b01;

	public static final int ID_AS_LOSE = 0b10;

	/**
	 * Catalan number.<br/>
	 * <br/>
	 * C1 = C0*C0<br/>
	 * C2 = C0*C1 + C1*C0<br/>
	 * C3 = C0*C2 + C1*C1 + C2*C0
	 */
	public static long int64Recur(int n) {

		if (n == 0 || n == 1)

			return 1L;

		long ans = 0L;

		n--;

		for (int k = 0; k <= n; k++)

			ans += int64Recur(k) * int64Recur(n - k);

		return ans;
	}

	/**
	 * Catalan number.<br/>
	 * C(2n,n)-C(2n,n-1)
	 */
	public static long int64(int n) {

		return (Cnk.int64(n << 1, n) / (n + 1));
	}

	/**
	 * 考慮一個含 n 個 1, n 個 0 的 2n 位二進位序列, 從頭掃描到第 2k+1 位時有 k+1 個 0 和 k 個 1<br/>
	 * (直觀上必存在這樣的情況),<br/>
	 * 則後續剩下的序列中必有 n-k 個 1 和 n-k-1 個 0, 將第 2k+2 及其以後的序列, 把 0 變 1, 1 變 0,<br/>
	 * 則對應一個 n+1 個 0 和 n-1 個 1 的二進位序列.<br/>
	 *
	 * 如:<br/>
	 * ACACCAAC // 轉折點第 5 位<br/>
	 * 把 A 變 C, C 變 A:<br/>
	 * ACACC[CCA]<br/>
	 *
	 * 合法序列減掉不合法序列:<br/>
	 *
	 * C(2n,n)-C(2n,n-1)
	 */
	public static void winLose(final int totalW, long prefix, int countW, int countL, KArV32 kV) { // first time must be 0b1L

		// if (++B.n32 > 15) O.x();

		if (countW == totalW) {

			if (countW > countL) {

				O.lv((countW + countL), "prefix=" + B64W6.strByVCellAftRev(prefix) + " W > L 補滿");

				do prefix = ((prefix << B64W6.$6) | ID_AS_LOSE); // O.l("loop=" + B64W6.str24(prefix));

				while (++countL != countW);

				kV.k[kV.v++] = prefix; // kV.a(prefix);

				return;

			}

			// if (countW == countL)

		}

		// countW < totalWin

		if (countW > countL) {

			O.lv((countW + countL), "prefix=" + B64W6.strByVCellAftRev(prefix) + " W > L");

			winLose(totalW, ((prefix << B64W6.$6) | ID_AS_WIN), (countW + 1), countL, kV);
			winLose(totalW, ((prefix << B64W6.$6) | ID_AS_LOSE), countW, (countL + 1), kV);

			return;

		}

		O.lv((countW + countL), "prefix=" + B64W6.strByVCellAftRev(prefix) + " W == L");

		winLose(totalW, ((prefix << B64W6.$6) | ID_AS_WIN), (countW + 1), countL, kV);

	}

	/**
	 * C(2n,n)-C(2n,n-1)<br/>
	 * C(2n,n)-C(2n,n-1)
	 */
	public static void push(long base, long stack, long ret, KArV32 kV) {

		// O.l("bef push base=" + B64W6.str24(base));
		// O.l("bef push in=" + B64W6.str24(in));
		// O.l("bef push out=" + B64W6.str24(out));

		// if (base == 0b0L) return;

		// O.l("push vCell=" + B64W6.str24(vCell=(int) (base & B64W6.MASK32)));

		stack = (stack << B64W6.$6) | (base & B64W6.MASK32); // vCell= (int) (base & B64W6.MASK32)

		pushPop((base >>> B64W6.$6), stack, ret, kV);

	}

	/**
	 * C(2n,n)-C(2n,n-1)<br/>
	 * C(2n,n)-C(2n,n-1)
	 */
	public static void pop(long base, long stack, long ret, KArV32 kV) {

		ret = (ret << B64W6.$6) | (stack & B64W6.MASK32); // vCell= (int) (stack & B64W6.MASK32)

		pushPop(base, (stack >>> B64W6.$6), ret, kV);

	}

	/**
	 * C(2n,n)-C(2n,n-1)<br/>
	 * C(2n,n)-C(2n,n-1)
	 */
	public static void pushPop(long base, long stack, long ret, KArV32 kV) {

		if (base == 0b0L) {

			// O.l("bef ret= base=" + B64W6.str24(base));
			// O.l("bef ret= in=" + B64W6.str24(in));
			// O.l("bef ret= out=" + B64W6.str24(out));

			// stack 此情況下不空

			do ret = (ret << B64W6.$6) | (stack & B64W6.MASK32); // O.l("loop out=" + B64W6.str24(out));

			while ((stack >>>= B64W6.$6) != 0b0L);

			kV.k[kV.v++] = ret;

			// B32va.l(0, null, 0);

			// O.l("ret=" + B64W6.toStrByVCellMinus1BySAry(out, O.S_ARY_A_Z));

			return;

		}

		push(base, stack, ret, kV);

		if (stack != 0b0L)

			pop(base, stack, ret, kV);

	}

	/**
	 * To postfix.<br/>
	 */
	public static StringBuilder strMatrixChainMul(long b64W6) { // 原創

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		b64W6 = B64W6.revAmongVCell(b64W6);

		char c = O.C65;

		ret.append(c); // 上帝先給 A, 上帝說要有光 然後就有了光

		do ret.append(((((int) b64W6) & B64W6.MASK32) == ID_AS_WIN) ? (++c) : O.C42);

		while (((int) (b64W6 >>>= B64W6.$6)) != 0b0);

		return ret;

	}

	public static void main1(String[] sAry) throws Throwable {

		int n = 3;

		String[] aryOfDyck = { "W", "L" };

		KArV32 kV = new KArV32((int) int64(n));

		winLose(n, ID_AS_WIN, 1, 0, kV);

		long[] aryAsSet = Aryva.sortNCheckDup(kV.k);

		for (int idx = 0, size = aryAsSet.length; idx != size; idx++)

			// O.l(B64W6.strByVCellMinus1AftRevBySAry(aryAsSet[idx], aryOfDyck));
			O.l(strMatrixChainMul(aryAsSet[idx]));

		O.l("len=" + O.eq(kV.v, aryAsSet.length));

	}

	public static void main(String[] sAry) throws Throwable {

		main1(null);

		int n = 3;

		long base = B64W6.genB64W6ByAr32(Ar32va.genAscArFrom1(n));

		O.l("init base=" + B64W6.str24(base), THIS);

		KArV32 kV = new KArV32((int) int64(n));

		pushPop(base, 0b0L, 0b0L, kV);

		Aryva.checkDup(kV.k);
		// Aryva.sortNCheckDup(kV.k);

		for (int idx = 0, size = kV.k.length; idx != size; idx++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(kV.k[idx], O.ARY_A_Z));

		O.l("len=" + O.eq(kV.k.length, kV.v));

	}
}
