package lgpl3.comb.stirlingN;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ary2D;
import lgpl3.o.str.Strva;
import lgpl3.other.jsp.Jsp;

/**
 * @version 2023/11/27_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=S2Pcir_Z" >src</a>
 *
 * @see S2Pcir
 */
public abstract class S2Pcir_Z extends S2Pcir_Y { // private static final Class<?> THIS = S2Pcir_Z.class;

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder toStrByAry2DOfB64W6BySAry(Ary2D ary2D, String[] sAry, CharSequence lineWr) { // for S1

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		long[][] aryOfAry = ary2D.ar;

		int lenBig = ary2D.i, iBig, iSmall;

		long[] ary;

		for (iBig = 0; iBig != lenBig;) {

			ary = aryOfAry[iBig];
			ret.append(O.C91);

			for (iSmall = 0; iSmall != ary.length;) {

				ret.append(B64W6.strByVCellMinus1AftRevBySAry(ary[iSmall], sAry));

				if (++iSmall != ary.length) ret.append(O.C124);

			}

			ret.append(O.C93);

			if (++iBig != lenBig) ret.append(lineWr);

		}

		return ret;
	}

	/**
	 * To string by B64W6.<br/>
	 */
	public static StringBuilder rowHtmlAftS1S3(long b64W6, String[] sAry) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		if (b64W6 == 0L) return ret.append(Jsp.C_A_6_HTML_BLANK);

		b64W6 = B64W6.revAmongVCell(b64W6); // O.l("revAmongVCell=" + B64W6.str24(b64W6));

		int cnt = 0;
		do {
			ret.append(sAry[((int) b64W6 & B64W6.MASK32) - 1]).append(O.C32);

			if ((b64W6 >>>= B64W6.$6) == 0b0L) return ret;

			else if (++cnt == Strva.numOfWordPerLineForS2) {

				ret.append(Jsp.BR);
				cnt = 0;
			}

		} while (B.T);
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder toHtmlAftS1S3(Ary2D ary2D, String[] sAry, CharSequence sHtmlClass) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		StringBuilder htmlStart1 = new StringBuilder("<table class=\"").append(sHtmlClass).append("\" ><thead><tr><td>");
		StringBuilder htmlEnd1 = new StringBuilder("</td></tr></thead><tr><td>");

		long[][] arrOfAry = ary2D.ar;
		long[] ary;

		int iBig, lenBig = ary2D.i, iSmall;

		for (iBig = 0; iBig != lenBig;) {

			ary = arrOfAry[iBig];

			ret.append(htmlStart1).append(iBig + 1).append(htmlEnd1);

			for (iSmall = 0; iSmall != ary.length;) {

				ret.append(rowHtmlAftS1S3(ary[iSmall], sAry));

				if (++iSmall != ary.length) ret.append(Strva.STR_HTML_MIDDLE_TD);

			}

			ret.append(Strva.STR_HTML_TABLE_END);

			if (++iBig != lenBig)

				if (iBig == Strva.maxRowInHtml) return ret;

				else ret.append(Jsp.L);

		}

		return ret;
	}
}
