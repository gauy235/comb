package lgpl3.comb.stirlingN;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MSK;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.filter.Condi;
import lgpl3.comb.onto.Onto;
import lgpl3.divIntoHeap.Dih;
import lgpl3.o.B;
import lgpl3.o.O;

/**
 * @version 2023/11/27_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=S2Pcir_Y" >src</a>
 *
 * @see S2Pcir_Z
 */
public abstract class S2Pcir_Y extends S2Pcir_A { // private static final Class<?> THIS = S2Pcir_Y.class;

	/**
	 * Stirling number of the first kind.<br/>
	 *
	 * @see Onto #script(Condi, CharSequence)
	 */
	public static StringBuilder script(Condi condi, CharSequence lineWr) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		final int dif = condi.min - 1; // reduced for performance
		long[] ary = Dih.col(condi.n, condi.k, condi.min, condi.max);

		long b64W6C, b64W6Dup;

		int restN = condi.n, val, iAr = 0;
		do {
			b64W6Dup = b64W6C = B64W6.revAmongVCell(ary[iAr]);

			if (condi.min == 0) while (((int) b64W6Dup & MSK) == 1) b64W6Dup >>>= $6;

			b64W6Dup = B64W6.listCntOfDupNRev(b64W6Dup); // O.l("b64W6Dup=" + O.L + B64W6.str24(b64W6Dup), THIS);
			do {
				val = ((int) b64W6C & MSK) + dif;

				ret.append(O.C67).append(O.C40).append(restN).append(O.C44).append(val).append(O.C41);
				ret.append(O.C42).append("Pc(").append(val).append(")");

				restN -= val;

				if ((b64W6C >>>= $6) != 0b0L) ret.append(O.C42);

				else break;

			} while (B.T);

			while (b64W6Dup != 0b0L) { // O.l("b64W6Dup=" + O.L + B64W6.str24(b64W6Dup), THIS);

				ret.append(O.C47).append((int) b64W6Dup & MSK).append(O.C33); // 除以 n!
				b64W6Dup >>>= $6;
			}

			restN = condi.n;

			if (++iAr < ary.length) ret.append(lineWr).append(O.C43);

		} while (iAr != ary.length);

		return ret;
	}
}
