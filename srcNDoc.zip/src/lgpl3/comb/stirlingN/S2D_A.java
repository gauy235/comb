package lgpl3.comb.stirlingN;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MASK32;

import lgpl3.comb.Dnk;
import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.filter.Condi;
import lgpl3.divIntoHeap.Dih;

/**
 * Stirling number of the second kind.<br/>
 * <br/>
 * 简称: 5 人分 3 群.<br/>
 *
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=S2D_A" >src</a>
 *
 * @see S2D
 */
public abstract class S2D_A extends S2nk_Z { // private static final Class<?> THIS = S2D_A.class;

	/**
	 * Stirling number of the second kind.<br/>
	 */
	public static long int64ByDih(Condi condi) {

		long ary[] = Dih.col(condi.n, condi.k, condi.min, condi.max), b64W6C, b64W6Dup, tmpAns, ans = 0L;

		int myN, dif = (condi.min - 1), idx = 0, vCell;

		do {
			myN = condi.n;

			b64W6Dup = b64W6C = B64W6.revAmongVCell(ary[idx]);

			tmpAns = 1L;
			do {
				tmpAns *= Dnk.int64(myN, vCell = ((int) b64W6C & MASK32) + dif);
				myN -= vCell;

			} while ((b64W6C >>>= $6) != 0b0L);

			if (condi.min == 0) while (((int) b64W6Dup & MASK32) == 1) b64W6Dup >>>= $6; // 去掉 qty 為 1 次者 減低負擔

			for (b64W6Dup = B64W6.listCntOfDupNRev(b64W6Dup); b64W6Dup != 0b0L; b64W6Dup >>>= $6)

				tmpAns /= Pnk.int64((int) b64W6Dup & MASK32);

			ans += tmpAns;

		} while (++idx != ary.length); // O.l("ans=" + ans, THIS);

		return ans;
	}
}
