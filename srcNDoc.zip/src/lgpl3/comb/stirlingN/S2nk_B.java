package lgpl3.comb.stirlingN;

import lgpl3.b32.B32va;
import lgpl3.comb.Cnk;
import lgpl3.comb.filter.Condi;
import lgpl3.comb.filter.FilterInComb;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32_2D;
import lgpl3.o.keyNV.KAr32V32;

/**
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=S2nk_B" >src</a>
 *
 * @see S2nk_U
 */
public abstract class S2nk_B extends S2nk_A { // private static final Class<?> THIS = S2nk_B.class;

	/**
	 * The tail process of S2 function.<br/>
	 * <br/>
	 * S2: 水平组合後再垂直组合<br/>
	 * Onto: 水平排列後再垂直组合
	 */
	// put on VS put upon
	public static void putOnVerticallyIfGt(int[] arOfB32, final int rmdB32, Condi condi, Ar32_2D retAr32_2D) {

		B.cnt++;

		int lo1 = (-rmdB32 & rmdB32), idx = 0, tmp32, clonedAr32[];

		if (lo1 == rmdB32) { // termination condition

			// 想: for (int i = arOfB32.length - 1; i >= iHorizontal; i--) 4 去壓 [123] 3 不用去壓 [124] 的最末

			for (; idx != arOfB32.length; idx++) {

				if (lo1 < (tmp32 = arOfB32[idx])) return; // all items are distinct and 8 > 4+2+1

				(clonedAr32 = arOfB32.clone())[idx] = lo1 | tmp32; // to put on

				// if (B32va.countOf1(tmp32) >= condi.min && B32va.countOf1(tmp32) <= condi.max) { // condi.max maybe n
				// O.l("lowest1=" + B32va.toStrByLgAtB32BySAry(lowest1, O.ARY_A_Z));
				// O.l("idx=" + idx + " bitCount=" + B32va.countOf1(tmp32) , THIS);
				// O.l("=" + Cnk.toStrToCByB32As2PowBySAry(clonedAr32, O.ARY_A_Z, "|"));

				if (FilterInComb.ifEveryBitCountInAr32Between(clonedAr32, condi.min, condi.max)) retAr32_2D.a(clonedAr32);

			}

			return;
		}

		for (; idx != arOfB32.length; idx++) {

			if (lo1 < (tmp32 = arOfB32[idx])) return;

			if (B32va.countOf1(tmp32) < condi.max) {

				(clonedAr32 = arOfB32.clone())[idx] = lo1 | tmp32; // to put on

				putOnVerticallyIfGt(clonedAr32, (~lo1 & rmdB32), condi, retAr32_2D);

			} // else O.l("FilterInComb here=" , THIS);
		}
	}

	/**
	 * To collect.<br/>
	 */
	public static Ar32_2D colRecur(Condi condi) {

		Ar32_2D ret = new Ar32_2D();

		int baseB32 = ~(-0b1 << condi.n);

		int boundBit = 0b1 << (condi.n - condi.min + 1); // important

		if (condi.k == 1) {

			ret.a(new int[] { baseB32 });

			return ret;
		}

		if (condi.n == condi.k) {

			ret.a(B32va.distributeOver1Ar32(baseB32));

			return ret;
		}

		KAr32V32 kAr32V32 = new KAr32V32((int) int64ByDih(condi));

		// the 'A' symbol must be at the most left hand side
		Cnk.colRecur(boundBit, (condi.k - 1), 0b1, 0b10, kAr32V32);

		////////////////////////
		// O.l(Cnk.strByAryOfB32As2Pow(kAr32V32.k), THIS);
		////////////////////////

		for (int idx = 0, keptB32; idx != kAr32V32.v; idx++)

			putOnVerticallyIfGt(B32va.distributeOver1Ar32(keptB32 = kAr32V32.k[idx]), (~keptB32 & baseB32), condi, ret);

		return ret;
	}

	/**
	 * min=0, To collect.<br/>
	 */
	public static Ar32_2D colToK(Condi condi) { // ThrS2WDynaB64(n,k) while 9*8 =72 超過 64 bit

		if (condi.n < condi.k) O.x("condi.n=" + condi.n + " condi.k=" + condi.k); // 天然 自然的檢驗

		Condi clonedCondi = condi.clone();
		clonedCondi.min = 1; // min starts from 1

		Ar32_2D retAr32_2D = new Ar32_2D(), tmpAr32_2D;

		for (int k = condi.k; k != 0; k--) {

			clonedCondi.k = k;

			retAr32_2D.appendAll((tmpAr32_2D = colRecur(clonedCondi)).ar, 0, tmpAr32_2D.i); // O.l("n,k=", clonedCondi.n, k);
		}

		return retAr32_2D;
	}
}
