package lgpl3.comb.stirlingN;

import lgpl3.b32.B32va;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32_2D;
import lgpl3.o.str.Strva;
import lgpl3.other.jsp.Jsp;

/**
 * @version 2022/05/07_11:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=S2nk_Z" >src</a>
 *
 * @see S2nk
 */
public abstract class S2nk_Z extends S2nk_Y { // private static final Class<?> THIS = S2nk_Z.class;

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder strByAr32_2DOfB32BySAry(Ar32_2D ar32_2D, String[] sAry) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		int arOfAr32[][] = ar32_2D.ar, ar32[], iBig, lenBig = ar32_2D.i, iSmall, tmpB32;

		for (iBig = 0; iBig != lenBig;) {

			ar32 = arOfAr32[iBig];
			ret.append(O.C91);

			for (iSmall = 0; iSmall != ar32.length;) {

				// the char '_'
				ret.append(((tmpB32 = ar32[iSmall]) == 0b0) ? O.S95 : B32va.strByLgLo1BySAry(tmpB32, sAry));

				if (++iSmall != ar32.length) ret.append(O.C124);

			}

			ret.append(O.C93);

			if (++iBig != lenBig) ret.append(O.C_A_L);

		}

		return ret;
	}

	/**
	 * To StringBuilder from String ary via bit32.<br/>
	 */
	public static StringBuilder rowHtmlByB32BySAry(int b32As2Pow, String[] sAry) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		// if (b32As2Pow == 0b0) return ret.append(Jsp.C_A_6_HTML_BLANK);

		int lo1, cnt = 0;

		do if ((lo1 = -b32As2Pow & b32As2Pow) == b32As2Pow) return ret.append(sAry[B32va.lg(lo1)]);

		else {
			ret.append(sAry[B32va.lg(lo1)]);

			if (++cnt == Strva.numOfWordPerLineForS2) {

				ret.append(Jsp.BR);
				cnt = 0;

			} else ret.append(O.C32);
		}
		while ((b32As2Pow &= ~lo1) != 0b0);

		throw new RuntimeException(); // never reaches
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder htmlByAr32_2DOfB32BySAry(Ar32_2D ar32_2D, String[] sAry, CharSequence sHtmlClass) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		StringBuilder htmlStart1 = new StringBuilder("<table class=\"").append(sHtmlClass).append("\" ><thead><tr><td>");
		StringBuilder htmlEnd1 = new StringBuilder("</td></tr></thead><tr><td>");

		int arOfAr32[][] = ar32_2D.ar, ar32[], iBig, lenBig = ar32_2D.i, iSmall;

		for (iBig = 0; iBig != lenBig;) {

			ar32 = arOfAr32[iBig];

			ret.append(htmlStart1).append(iBig + 1).append(htmlEnd1);

			for (iSmall = 0; iSmall != ar32.length;) {

				ret.append(rowHtmlByB32BySAry(ar32[iSmall], sAry));

				if (++iSmall != ar32.length) ret.append(Strva.STR_HTML_MIDDLE_TD);

			}

			ret.append(Strva.STR_HTML_TABLE_END);

			if (++iBig != lenBig)

				if (iBig == Strva.maxRowInHtml) return ret;

				else ret.append(Jsp.L);
		}

		return ret;
	}
}
