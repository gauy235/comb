package lgpl3.comb.stirlingN;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MSK;

import java.math.BigInteger;

import lgpl3.comb.Cnk;
import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.filter.Condi;
import lgpl3.divIntoHeap.Dih;
import lgpl3.o.O;

/**
 * Stirling number of the third kind.<br/>
 * Lah numbers.<br/>
 * 简称: 5 人排 3 队. <br/>
 * <br/>
 * 5! eq 定值 eq C(5,2)*2!*C(3,3)*3!<br/>
 * C(6,1)*C(5,2)*C(3,3) eq 定值 eq C(6,2)*C(4,3)*C(1,1)
 *
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=S2P_A" >src</a>
 *
 * @see S2P_Y
 */
public abstract class S2P_A extends S2nk_Z { // private static final Class<?> THIS = S2P_A.class;

	/**
	 * Divide into then to permutate.<br/>
	 *
	 * @see #bigIntByDih(Condi)
	 */
	public static long int64ByDih(Condi condi) {

		long ary[] = Dih.col(condi.n, condi.k, condi.min, condi.max), b64W6C, b64W6Dup, tmpAns, ans = 0L;

		int myN, dif = (condi.min - 1), idx = 0, vCell;
		do {
			myN = condi.n;

			b64W6Dup = b64W6C = B64W6.revAmongVCell(ary[idx]);

			tmpAns = 1L;
			do {
				tmpAns *= Pnk.int64(myN, vCell = ((int) b64W6C & MSK) + dif); // O.l("tmpAns=" + tmpAns, THIS);
				myN -= vCell;

			} while ((b64W6C >>>= $6) != 0b0L);

			if (condi.min == 0) while (((int) b64W6Dup & MSK) == 1) b64W6Dup >>>= $6; // 去掉 qty 為 1 次者 減低負擔

			for (b64W6Dup = B64W6.listCntOfDupNRev(b64W6Dup); b64W6Dup != 0b0L; b64W6Dup >>>= $6)

				tmpAns /= Pnk.int64((int) b64W6Dup & MSK);

			ans += tmpAns;

		} while (++idx != ary.length); // O.l("ans=" + ans, THIS);

		return ans;
	}

	/**
	 * Divide into then to permutate.<br/>
	 *
	 * @see #int64ByDih(Condi)
	 */
	public static BigInteger bigIntByDih(Condi condi) {

		long ary[] = Dih.col(condi.n, condi.k, condi.min, condi.max), b64W6C, b64W6Dup;

		int myN, dif = (condi.min - 1), idx = 0, vCell;

		BigInteger ans = BigInteger.ZERO, tmpAns;
		do {
			myN = condi.n;

			b64W6Dup = b64W6C = B64W6.revAmongVCell(ary[idx]);

			tmpAns = BigInteger.ONE;
			do {
				tmpAns = tmpAns.multiply(Pnk.bigInt(myN, vCell = ((int) b64W6C & MSK) + dif));
				myN -= vCell;

			} while ((b64W6C >>>= $6) != 0b0L);

			if (condi.min == 0) while (((int) b64W6Dup & MSK) == 1) b64W6Dup >>>= $6; // 去掉 qty 為 1 次者 減低負擔

			for (b64W6Dup = B64W6.listCntOfDupNRev(b64W6Dup); b64W6Dup != 0b0L; b64W6Dup >>>= $6)

				tmpAns = tmpAns.divide(Pnk.bigInt((int) b64W6Dup & MSK));

			ans = ans.add(tmpAns);

		} while (++idx != ary.length); // O.l("ans=" + ans, THIS);

		return ans;
	}

	/**
	 * Stirling number of the third kind.<br/>
	 * S3(n,k) = C(n-1,k-1)*n!/k!<br/>
	 * Lah Number.
	 */
	public static long int64(int n, int k) {

		if (n <= 0 || k <= 0 || n < k) O.x("n=" + n + ", k=" + k);

		return (k == 1) ? Pnk.int64(n) : (Cnk.int64(n - 1, k - 1) * (Pnk.int64(n) / Pnk.int64(k)));
	}

	/**
	 * Stirling number of the third kind.<br/>
	 * S3(n,k) = C(n-1,k-1)*n!/k!<br/>
	 * Lah Number.
	 */
	public static BigInteger bigInt(int n, int k) {

		if (n <= 0 || k <= 0 || n < k) O.x("n=" + n + ", k=" + k);

		return (k == 1) ? Pnk.bigInt(n) : Cnk.bigInt(n - 1, k - 1).multiply(Pnk.bigInt(n).divide(Pnk.bigInt(k)));
	}
}
