package lgpl3.comb;

/**
 * @version 2021/05/22_19:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=VandermondeConvol" >VandermondeConvol.java</a>
 *
 * @see Cnk_A
 */
public abstract class VandermondeConvol extends VandermondeConvol_A {

}
