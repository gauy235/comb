package lgpl3.comb;

/**
 * 環狀排列.<br/>
 * Circular permutation.
 *
 * @version 2016/08/25_20:47:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=PCirc" >PCirc.java</a>
 *
 */
public abstract class PCirc extends PCirc_Z {

}
