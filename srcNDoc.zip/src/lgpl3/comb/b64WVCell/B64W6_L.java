package lgpl3.comb.b64WVCell;

import lgpl3.o.B;
import lgpl3.o.O;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2022/04/16_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_L" >src</a>
 *
 * @see B64W6
 */
public abstract class B64W6_L extends B64W6_G { // private static final Class<?> THIS = B64W6_L.class;

	/**
	 * For 0b0000_000001_000100_000100_001000 as 8,4,4,1<br/>
	 */
	public static StringBuilder strByVCell(long b64W6) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);
		do {
			ret.append((int) b64W6 & MASK32);

			if ((int) (b64W6 >>>= $6) == 0b0) return ret;

			ret.append(O.C44);

		} while (B.T);
	}

	/**
	 * For 0b0000_000001_000100_000100_001000 as 1,4,4,8<br/>
	 */
	public static StringBuilder strByVCellAftRev(long b64W6) {

		return strByVCell(revAmongVCell(b64W6));
	}

	/**
	 * To string by B64W6.<br/>
	 */
	public static StringBuilder strByVCellMinus1BySAry(long b64W6, String[] sAry) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		if (b64W6 == 0b0L) return ret;

		do {
			ret.append(sAry[((int) b64W6 & MASK32) - 1]);

			if ((int) (b64W6 >>>= $6) == 0b0) return ret;

			ret.append(O.C44);

		} while (B.T);
	}

	/**
	 * To string by B64W6.<br/>
	 */
	public static StringBuilder strByVCellMinus1AftRevBySAry(long b64W6, String[] sAry) {

		return strByVCellMinus1BySAry(revAmongVCell(b64W6), sAry);
	}
}
