package lgpl3.comb.b64WVCell;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2022/04/16_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_L" >src</a>
 *
 * @see B64W6
 */
public abstract class B64W6_L extends B64W6_G { // private static final Class<?> THIS = B64W6_L.class;

}
