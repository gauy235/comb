package lgpl3.comb.b64WVCell;

import lgpl3.b32.B32va;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;

/**
 * To make a 64-bit long divide into every 6-bit cell.<br/>
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/10/27_11:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6" >src</a>
 *
 * @see B32va
 */
public abstract class B64W6 extends B64W6_L { // private static final Class<?> THIS = B64W6.class;

	/**
	 * The int[]{1,2,3} returns 0011_0010_0001<br/>
	 */
	public static long genB64W6ByAr32(int... positiveAr32) {

		long ret = 0b0L;

		for (int len = positiveAr32.length; len != 0;) ret = (ret << $6) | positiveAr32[--len];

		return ret;
	}

	/**
	 * To gen the B64W6 with value 1 in every cell.
	 */
	public static long genB64W6WAll1(int len) {

		if (len <= 0) throw new IllegalArgumentException("len" + len);

		long ret = 0b1L;

		while (--len != 0) ret = (ret << $6) | 0b1;

		return ret; // O.l("ret=" + O.L + str24(ret), THIS);
	}

	/**
	 * To find the key sequentially.<br/>
	 */
	public static int findIdx(long b64W6, int key32) {

		if (((int) b64W6 & MASK32) == key32) return 0;

		if ((((int) b64W6 & MASK32_1_7TO_12) >>> 6) == key32) return 1;

		if ((((int) b64W6 & MASK32_1_13TO_18) >>> 12) == key32) return 2;

		if ((((int) b64W6 & MASK32_1_19TO_24) >>> 18) == key32) return 3;

		if ((((int) b64W6 & MASK32_1_25TO_30) >>> 24) == key32) return 4;

		if ((int) ((b64W6 & MASK1_31TO_36) >>> 30) == key32) return 5;

		if ((int) ((b64W6 & MASK1_37TO_42) >>> 36) == key32) return 6;

		if ((int) ((b64W6 & MASK1_43TO_48) >>> 42) == key32) return 7;

		if ((int) ((b64W6 & MASK1_49TO_54) >>> 48) == key32) return 8;

		if ((int) ((b64W6 & MASK1_55TO_60) >>> 54) == key32) return 9;

		return Integer.MIN_VALUE;
	}

	/**
	 * The bounds and 0 are both inclusive.<br/>
	 *
	 * @see Ar32va #findFirstOccurDownTo0(int[], int, int)
	 */
	public static int findFirstOccurDownTo0(long b64W6, int bound /* inclusive */, int key32) {

		do if (((int) (b64W6 >>> $6 * bound) & MASK32) == key32) return bound; while (--bound >= 0);

		return Integer.MIN_VALUE;
	}

	/**
	 * To count the duplicated occurrence of every value.<br/>
	 * Inputing 0b000010_000001_000001_000001 returns: 000000_000011<br/>
	 * Inputing 0b000000_000000_000001_000011 returns: 000000_000000
	 *
	 * @see #countDup(long)
	 */
	public static int countDupNRev(long sortedB64W6) {

		int min = ((int) sortedB64W6 & MASK32) /* sortedB64W6 must not be 0b0L */, vCell, cnt = 1, retB32W6 = 0b0;

		do {
			if ((vCell = (int) (sortedB64W6 >>>= $6) & MASK32) == 0b0) {

				if (cnt != 1) retB32W6 = (retB32W6 << $6) | cnt;

				return retB32W6;
			}

			if (vCell == min) cnt++;

			else {
				if (cnt != 1) retB32W6 = (retB32W6 << $6) | cnt; // O.l("cnt=" + cnt, THIS);

				min = vCell; // change to next
				cnt = 1; // fuck
			}

		} while (B.T);
	}

	/**
	 * To count the occurrence.<br/>
	 * The int[]{1, 3, 3} returns: 0b000001_000010
	 *
	 * @see #countAllOccur(long)
	 */
	public static long countAllOccurNRev(long sortedB64W6) { // sortedB64W6 must not be 0b0L

		int min = ((int) sortedB64W6 & MASK32) /* sortedB64W6 not 0b0L */, vCell, cnt = 1;

		long ret = 0b0L;
		do {
			if ((vCell = (int) (sortedB64W6 >>>= $6) & MASK32) == 0b0) return ret = (ret << $6) | cnt;

			if (vCell == min) cnt++; // O.l("retB64W6=" + O.L + str24(retB64W6), THIS);

			else {
				ret = (ret << $6) | cnt; // O.l("cnt=" + cnt, THIS);

				min = vCell; // check if pass This.genB64W6ByAr32(1, 1, 2, 3, 4)
				cnt = 1; // fuck
			}

		} while (B.T);
	}

	/**
	 * To count the duplicated occurrence of every value.<br/>
	 * Inputing 0b000010_000001_000001_000001 returns: 000000_000011<br/>
	 * Inputing 0b000000_000000_000001_000011 returns: 000000_000000
	 */
	public static int countDup(long sortedB64W6) {

		return revAmongVCell(countDupNRev(sortedB64W6));
	}

	/**
	 * To count the occurrence.<br/>
	 * The int[]{1, 3, 3} returns: 0b000010_000001
	 */
	public static long countAllOccur(long sortedB64W6) { // sortedB64W6 must not be 0b0L

		return revAmongVCell(countAllOccurNRev(sortedB64W6));
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder str24(long int64) { // int64 &= $HEAD4_0_OF_64BIT

		int len = 27, idx = len, iUd = 0; // O.l("int64=" + int64 , THIS);

		char[] cAr = new char[len];

		while (idx-- != 0) cAr[idx] = O.C48;

		idx = len - 1;
		do {
			if ((((int) int64) & 0b1) != 0b0) cAr[idx] = O.C49;

			if (++iUd == 6 || iUd == 12 || iUd == 18) cAr[--idx] = O.C95; // O.l("iUd=" + iUd, THIS);

			int64 >>>= 1;

		} while (idx-- != 0);

		return new StringBuilder(len).append(cAr);
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder str(long int64) { // int64 &= $HEAD4_0_OF_64BIT; O.l("int64=" + int64 , THIS);

		int len = 74, idx = len, iUd = 0;

		char[] cAr = new char[len];

		while (idx-- != 0) cAr[idx] = O.C48;

		idx = len - 1;
		do {
			if ((((int) int64) & 0b1) != 0b0) cAr[idx] = O.C49;

			if (++iUd == 6 || iUd == 12 || iUd == 18 || iUd == 24 || iUd == 30 || iUd == 36 || iUd == 42 || iUd == 48 ||

					iUd == 54 || iUd == 60)

				cAr[--idx] = O.C95;

			int64 >>>= 1;

		} while (idx-- != 0);

		return new StringBuilder(len).append(cAr);
	}
}
