package lgpl3.comb.b64WVCell;

import lgpl3.o.B;
import lgpl3.o.ary.Ar32va;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/11/25_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_Q" >src</a>
 *
 * @see B64W6
 */
public abstract class B64W6_Q extends B64W6_G { // private static final Class<?> THIS = B64W6_Q.class;

	/**
	 * The int[]{1,2,3} returns 0011_0010_0001<br/>
	 */
	public static long genB64W6ByAr32(int... positiveAr32) {

		long ret = 0b0L;

		for (int len = positiveAr32.length; len != 0;) ret = (ret << $6) | positiveAr32[--len];

		return ret;
	}

	/**
	 * To gen the B64W6 with value 1 in every cell.
	 */
	public static long genB64W6WAll1(int len) {

		if (len <= 0) throw new IllegalArgumentException("len" + len);

		long ret = 0b1L;

		while (--len != 0) ret = (ret << $6) | 0b1;

		return ret; // O.l("ret=" + O.L + str24(ret), THIS);
	}

	/**
	 * To find the key sequentially.<br/>
	 */
	public static int findIdx(long b64W6, int key32) {

		if (((int) b64W6 & MASK32) == key32) return 0;

		if ((((int) b64W6 & MASK32_1_7TO_12) >>> 6) == key32) return 1;

		if ((((int) b64W6 & MASK32_1_13TO_18) >>> 12) == key32) return 2;

		if ((((int) b64W6 & MASK32_1_19TO_24) >>> 18) == key32) return 3;

		if ((((int) b64W6 & MASK32_1_25TO_30) >>> 24) == key32) return 4;

		if ((int) ((b64W6 & MASK1_31TO_36) >>> 30) == key32) return 5;

		if ((int) ((b64W6 & MASK1_37TO_42) >>> 36) == key32) return 6;

		if ((int) ((b64W6 & MASK1_43TO_48) >>> 42) == key32) return 7;

		if ((int) ((b64W6 & MASK1_49TO_54) >>> 48) == key32) return 8;

		if ((int) ((b64W6 & MASK1_55TO_60) >>> 54) == key32) return 9;

		return Integer.MIN_VALUE;
	}

	/**
	 * The bounds and 0 are both inclusive.<br/>
	 *
	 * @see Ar32va #findFirstOccurDownTo0(int[], int, int)
	 */
	public static int findFirstOccurDownTo0(long b64W6, int bound /* inclusive */, int key32) {

		do if (((int) (b64W6 >>> $6 * bound) & MASK32) == key32) return bound; while (--bound >= 0);

		return Integer.MIN_VALUE;
	}

	/**
	 * To count the duplicated occurrence of every value.<br/>
	 * Inputing 0b000010_000001_000001_000001 returns: 000000_000011<br/>
	 * Inputing 0b000000_000000_000001_000011 returns: 000000_000000<br/>
	 *
	 * @return the B64W6
	 *
	 * @see #listCntOfDup(long)
	 */
	public static int listCntOfDupNRev(long sortedB64W6) { // sortedB64W6 must not be 0b0L

		int min = ((int) sortedB64W6 & MASK32), vCell, cnt = 1, retB32W6 = 0b0;

		do {
			if ((vCell = (int) (sortedB64W6 >>>= $6) & MASK32) == 0b0) {

				if (cnt != 1) retB32W6 = (retB32W6 << $6) | cnt;

				return retB32W6;
			}

			if (vCell == min) cnt++;

			else {
				if (cnt != 1) retB32W6 = (retB32W6 << $6) | cnt; // O.l("cnt=" + cnt, THIS);

				min = vCell; // change to next
				cnt = 1; // fuck
			}

		} while (B.T);
	}

	/**
	 * Lists the all the counts of the occurrence.<br/>
	 * The int[]{1, 3, 3} returns: 0b000001_000010<br/>
	 *
	 * @return the B64W6
	 *
	 * @see #listCntOfOccur(long)
	 */
	public static long listCntOfOccurNRev(long sortedB64W6) { // sortedB64W6 must not be 0b0L

		int min = ((int) sortedB64W6 & MASK32) /* sortedB64W6 not 0b0L */, vCell, cnt = 1;

		long ret = 0b0L;
		do {
			if ((vCell = (int) (sortedB64W6 >>>= $6) & MASK32) == 0b0) return ret = (ret << $6) | cnt;

			if (vCell == min) cnt++; // O.l("retB64W6=" + O.L + str24(retB64W6), THIS);

			else {
				ret = (ret << $6) | cnt; // O.l("cnt=" + cnt, THIS);

				min = vCell;
				cnt = 1; // fuck
			}

		} while (B.T);
	}

	/**
	 * Counts the duplicated occurrence of every value.<br/>
	 * Inputing 0b000010_000001_000001_000001 returns: 000000_000011<br/>
	 * Inputing 0b000000_000000_000001_000011 returns: 000000_000000<br/>
	 *
	 * @return the B64W6
	 */
	public static int listCntOfDup(long sortedB64W6) {

		return revAmongVCell(listCntOfDupNRev(sortedB64W6));
	}

	/**
	 * Lists the all the counts of the occurrence.<br/>
	 * The int[]{1, 3, 3} returns: 0b000010_000001<br/>
	 *
	 * @return the B64W6
	 */
	public static long listCntOfOccur(long sortedB64W6) { // sortedB64W6 must not be 0b0L

		return revAmongVCell(listCntOfOccurNRev(sortedB64W6));
	}

	/**
	 * All values must be under 11.<br/>
	 * The int[]{1, 3, 3} returns: 2
	 */
	public static int distrNCnt(long unsortedB64W6) { // 各自歸位法 unsortedB64W6 must not be 0b0L

		long b64W6 = 0b0L; // O.l("unsortedB64W6=" + B64W6.str24(unsortedB64W6));

		int cnt = 0;

		do b64W6 |= 0b1L << ($6 * ((int) unsortedB64W6 & MASK32)); while ((unsortedB64W6 >>>= $6) != 0b0L);

		for (; ((int) b64W6 & MASK32) == 0b0; b64W6 >>>= $6); // trim 跳過空 cell // O.l( "cnt=" + cnt);

		do if (((int) b64W6 & MASK32) != 0b0) cnt++; while ((b64W6 >>>= $6) != 0b0L);

		return cnt;
	}

	/**
	 * Compares.<br/>
	 * 比較 2 個 B64W6 的 head VCell.<br/>
	 */
	public static int compaB64W6FromR(long b64W6A, long b64W6B) {

		int vA, vB; // O.l("b64W6A=" + str24(b64W6A));
		do {
			vA = (int) b64W6A & MASK32;
			vB = (int) b64W6B & MASK32;

			if ((vA -= vB) != 0) return vA;

			b64W6A >>>= $6;

		} while ((b64W6B >>>= $6) != 0b0L);

		return 0;
	}

	/**
	 * Partition.<br/>
	 */
	public static int goPivot(long[] arOfB64W6, int left, int right /* both inclusive */) {

		int iCnt = left;

		long pivot = arOfB64W6[left], tmpV; // 陣列頭當 pivot

		for (int j = left + 1; j <= right; j++) if ((compaB64W6FromR(arOfB64W6[j], pivot) < 0) && (++iCnt != j)) {

			tmpV = arOfB64W6[iCnt]; // swap(iCnt, j) 小的排在我左邊
			arOfB64W6[iCnt] = arOfB64W6[j];
			arOfB64W6[j] = tmpV;
		}

		arOfB64W6[left] = arOfB64W6[iCnt]; // swap(left, iCnt) 最後 跟 那群小朋友的尾巴 交換
		arOfB64W6[iCnt] = pivot;

		return iCnt;
	}

	/**
	 * QuickSort.<br/>
	 * 比較 2 個 B64W6 的 head VCell.<br/>
	 */
	public static long[] qSortAr(long[] arOfB64W6, int left, int right /* both inclusive */) {

		if (left < right) {

			int idxPivot = goPivot(arOfB64W6, left, right);

			qSortAr(arOfB64W6, left, idxPivot - 1);

			qSortAr(arOfB64W6, idxPivot + 1, right);
		}

		return arOfB64W6;
	}
}
