package lgpl3.comb.b64WVCell;

import lgpl3.o.B;
import lgpl3.o.ary.Ar32va;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/11/25_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_Q" >src</a>
 *
 * @see B64W6_Y
 */
public abstract class B64W6_Q extends B64W6_G { // private static final Class<?> THIS = B64W6_Q.class;

	/**
	 * The int[]{1,2,3} returns 0011_0010_0001<br/>
	 */
	public static long genB64W6ByAr32(int... positiveAr32) {

		long ret = 0b0L;

		for (int len = positiveAr32.length; len != 0;) ret = (ret <<= $6) | positiveAr32[--len];

		return ret;
	}

	/**
	 * To gen the B64W6 with value 1 in every cell.
	 */
	public static long genB64W6WAll1(int len) {

		if (len <= 0) throw new IllegalArgumentException("len" + len);

		long ret = 0b1L;

		while (--len != 0) ret = (ret <<= $6) | 0b1;

		return ret; // O.l("ret=" + O.L + str24(ret), THIS);
	}

	/**
	 * To find the key sequentially.<br/>
	 */
	public static int findIdx(long b64W6, int key32) {

		if (((int) b64W6 & MSK) == key32) return 0;

		if ((((int) b64W6 & MSK32_6TO11) >>> 6) == key32) return 1;

		if ((((int) b64W6 & MSK32_12TO17) >>> 12) == key32) return 2;

		if ((((int) b64W6 & MSK32_18TO23) >>> 18) == key32) return 3;

		if ((((int) b64W6 & MSK32_24TO29) >>> 24) == key32) return 4;

		if ((int) ((b64W6 &= MSK_30TO35) >>> 30) == key32) return 5;

		if ((int) ((b64W6 &= MSK_36TO41) >>> 36) == key32) return 6;

		if ((int) ((b64W6 &= MSK_42TO47) >>> 42) == key32) return 7;

		if ((int) ((b64W6 &= MSK_48TO53) >>> 48) == key32) return 8;

		if ((int) ((b64W6 &= MSK_54TO59) >>> 54) == key32) return 9;

		return Integer.MIN_VALUE;
	}

	/**
	 * The bounds and 0 are both inclusive.<br/>
	 *
	 * @see Ar32va #findFirstOccurDownTo0(int[], int, int)
	 */
	public static int findFirstOccurDownTo0(long b64W6, int bound /* inclusive */, int key32) {

		do if (((int) (b64W6 >>> $6 * bound) & MSK) == key32) return bound; while (--bound >= 0);

		return Integer.MIN_VALUE;
	}

	/**
	 * Find the key sequentially.<br/>
	 */
	public static boolean ifContain(long b64W6, int key32) {

		do if (((int) b64W6 & MSK) == key32) return B.T;

		while ((b64W6 >>>= $6) != 0b0L);

		return !B.T;
	}

	/**
	 * To count the duplicated occurrence of every value.<br/>
	 * Inputing 0b000010_000001_000001_000001 returns: 000000_000011<br/>
	 * Inputing 0b000000_000000_000001_000011 returns: 000000_000000<br/>
	 *
	 * @return the B64W6
	 *
	 * @see #listCntOfDup(long)
	 */
	public static int listCntOfDupNRev(long sortedB64W6) { // sortedB64W6 must not be 0b0L

		int min = ((int) sortedB64W6 & MSK), vCell, cnt = 1, retB32W6 = 0b0;

		do {
			if ((vCell = (int) (sortedB64W6 >>>= $6) & MSK) == 0b0) {

				if (cnt != 1) retB32W6 = (retB32W6 <<= $6) | cnt;

				return retB32W6;
			}

			if (vCell == min) cnt++;

			else {
				if (cnt != 1) retB32W6 = (retB32W6 <<= $6) | cnt; // O.l("cnt=" + cnt, THIS);

				min = vCell; // change to next
				cnt = 1; // fuck
			}
		} while (B.T);
	}

	/**
	 * Lists the all the counts of the occurrence.<br/>
	 * The int[]{1, 3, 3} returns: 0b000001_000010<br/>
	 *
	 * @return the B64W6
	 *
	 * @see #listCntOfOccur(long)
	 */
	public static long listCntOfOccurNRev(long sortedB64W6) { // sortedB64W6 must not be 0b0L

		int min = ((int) sortedB64W6 & MSK) /* sortedB64W6 not 0b0L */, vCell, cnt = 1;

		long ret = 0b0L;
		do {
			if ((vCell = (int) (sortedB64W6 >>>= $6) & MSK) == 0b0) return ret = (ret <<= $6) | cnt;

			if (vCell == min) cnt++; // O.l("retB64W6=" + O.L + str24(retB64W6), THIS);

			else {
				ret = (ret <<= $6) | cnt; // O.l("cnt=" + cnt, THIS);

				min = vCell;
				cnt = 1; // fuck
			}
		} while (B.T);
	}

	/**
	 * Counts the duplicated occurrence of every value.<br/>
	 * Inputing 0b000010_000001_000001_000001 returns: 000000_000011<br/>
	 * Inputing 0b000000_000000_000001_000011 returns: 000000_000000<br/>
	 *
	 * @return the B64W6
	 */
	public static int listCntOfDup(long sortedB64W6) {

		return revAmongVCell(listCntOfDupNRev(sortedB64W6));
	}

	/**
	 * Lists the all the counts of the occurrence.<br/>
	 * The int[]{1, 3, 3} returns: 0b000010_000001<br/>
	 *
	 * @return the B64W6
	 */
	public static long listCntOfOccur(long sortedB64W6) { // sortedB64W6 must not be 0b0L

		return revAmongVCell(listCntOfOccurNRev(sortedB64W6));
	}
}
