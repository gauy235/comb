package lgpl3.comb.b64WVCell;

import lgpl3.o.B;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/10/05_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_B" >src</a>
 *
 * @see B64W6_D
 */
public abstract class B64W6_B extends B64W6BitPerCellFromR { // private static final Class<?> THIS = B64W6_B.class;

	/**
	 * The total none 0 cells in the B64W6.
	 */
	public static int totalVCell(long b64W6) {

		int b32W6 = (int) b64W6;

		if ((b32W6 & MSK) == 0b0) return 0;

		if ((b32W6 & MSK32_6TO11) == 0b0) return 1;

		if ((b32W6 & MSK32_12TO17) == 0b0) return 2;

		if ((b32W6 & MSK32_18TO23) == 0b0) return 3;

		if ((b32W6 & MSK32_24TO29) == 0b0) return 4;

		if ((b64W6 & MSK_30TO35) == 0b0L) return 5;

		if ((b64W6 & MSK_36TO41) == 0b0L) return 6;

		if ((b64W6 & MSK_42TO47) == 0b0L) return 7;

		if ((b64W6 & MSK_48TO53) == 0b0L) return 8;

		if ((b64W6 & MSK_54TO59) == 0b0L) return 9;

		return 10;
	}

	/**
	 * Reverses among every value cell.<br/>
	 */
	public static long revAmongVCell(long b64W6) { // if (b64W6 == 0b0L) return 0b0L;

		long ret = 0b0L;
		do {
			ret |= (int) b64W6 & MSK;

			if ((b64W6 >>>= $6) == 0b0L) return ret; // b64 可在兩 cell 之間會有空的 cell

			ret <<= $6;

		} while (B.T); // O.l("revAmongVCell=" + str24(ret));
	}

	/**
	 * To reverse against every 6-bit cell.<br/>
	 */
	public static int revAmongVCell(int b32W6) {

		int retB32W6 = 0b0;
		do {
			retB32W6 |= (b32W6 & MSK);

			if ((b32W6 >>>= $6) == 0b0) return retB32W6;

			retB32W6 <<= $6;

		} while (B.T);
	}

	// public static int at(long b64W6, int idx) { return ((int) (b64W6 >>> ($6 * idx))) & MASK32;}

	/**
	 * Gets the leftmost none 0 value in the cell of a B64W6.<br/>
	 */
	public static int tailV(long b64W6) {

		if (((int) b64W6 & MSK) == 0b0) return 0;

		if (((int) b64W6 & MSK32_6TO11) == 0b0) return (int) b64W6;

		if (((int) b64W6 & MSK32_12TO17) == 0b0) return (int) b64W6 >>> 6;

		if (((int) b64W6 & MSK32_18TO23) == 0b0) return (int) b64W6 >>> 12;

		if (((int) b64W6 & MSK32_24TO29) == 0b0) return (int) b64W6 >>> 18;

		if ((b64W6 & MSK_30TO35) == 0b0L) return (int) (b64W6 >>>= 24);

		if ((b64W6 & MSK_36TO41) == 0b0L) return (int) (b64W6 >>>= 30);

		if ((b64W6 & MSK_42TO47) == 0b0L) return (int) (b64W6 >>>= 36);

		if ((b64W6 & MSK_48TO53) == 0b0L) return (int) (b64W6 >>>= 42);

		if ((b64W6 & MSK_54TO59) == 0b0L) return (int) (b64W6 >>>= 48);

		// if ((b64W6 & MSK_60TO63) == 0b0L)

		return (int) (b64W6 >>>= 54);
	}

	/**
	 * Gets the min.<br/>
	 */
	public static int getMin(long b64W6) {

		int min = $MAX_INT32_IN_CELL, vCell; // O.l("vCell=" + vCell, THIS);

		do if ((vCell = (int) b64W6 & MSK) < min) min = vCell; while ((b64W6 >>>= $6) != 0b0L);

		return min;
	}

	/**
	 * Gets the max.<br/>
	 */
	public static int getMax(long b64W6) {

		int max = 1, vCell;

		do if ((vCell = (int) b64W6 & MSK) > max) max = vCell; while ((b64W6 >>>= $6) != 0b0L);

		return max;
	}

	/**
	 * Swaps the values in the two cells.<br/>
	 */
	public static long swapVCell(long b64W6, int idx1, int idx2) {

		int v1 = (int) (b64W6 >>> $6 * idx1) & MSK; // at(b64W6, idx1);
		int v2 = (int) (b64W6 >>> $6 * idx2) & MSK; // at(b64W6, idx2);

		////////////// pasteAt(b64W6, idx1, v2);

		if (idx1 == 0) b64W6 = (b64W6 & MSK32_0) | v2; // clear cell first

		else if (idx1 == 1) b64W6 = (b64W6 & MSK32_0_6TO11) | (v2 << 6); // clear cell first

		else if (idx1 == 2) b64W6 = (b64W6 & MSK32_0_12TO17) | (v2 << 12); // clear cell first

		else if (idx1 == 3) b64W6 = (b64W6 & MSK32_0_18TO23) | (v2 << 18); // clear cell first

		else if (idx1 == 4) b64W6 = (b64W6 & MSK32_0_24TO29) | (v2 << 24); // clear cell first

		else if (idx1 == 5) b64W6 = (b64W6 & MSK0_30TO35) | ((long) v2 << 30); // clear cell first

		else if (idx1 == 6) b64W6 = (b64W6 & MSK0_36TO41) | ((long) v2 << 36); // clear cell first

		else if (idx1 == 7) b64W6 = (b64W6 & MSK0_42TO47) | ((long) v2 << 42); // clear cell first

		else if (idx1 == 8) b64W6 = (b64W6 & MSK0_48TO53) | ((long) v2 << 48); // clear cell first

		else b64W6 = (b64W6 & MSK0_54TO59) | ((long) v2 << 54); // if (idx1 == 9)

		////////////// pasteAt(b64W6, idx2, v1);

		if (idx2 == 0) return (b64W6 & MSK32_0) | v1; // clear cell first

		if (idx2 == 1) return (b64W6 & MSK32_0_6TO11) | (v1 << 6); // clear cell first

		if (idx2 == 2) return (b64W6 & MSK32_0_12TO17) | (v1 << 12); // clear cell first

		if (idx2 == 3) return (b64W6 & MSK32_0_18TO23) | (v1 << 18); // clear cell first

		if (idx2 == 4) return (b64W6 & MSK32_0_24TO29) | (v1 << 24); // clear cell first

		if (idx2 == 5) return (b64W6 & MSK0_30TO35) | ((long) v1 << 30); // clear cell first

		if (idx2 == 6) return (b64W6 & MSK0_36TO41) | ((long) v1 << 36); // clear cell first

		if (idx2 == 7) return (b64W6 & MSK0_42TO47) | ((long) v1 << 42); // clear cell first

		if (idx2 == 8) return (b64W6 & MSK0_48TO53) | ((long) v1 << 48); // clear cell first

		return (b64W6 & MSK0_54TO59) | ((long) v1 << 54); // if (idx2 == 9)
	}

	/**
	 * Replaces the cell at the index of B64W6.<br/>
	 */
	public static long pasteAt(long b64W6, int idx, int v32) { // first index is 0

		if (idx == 0) return (b64W6 & MSK32_0) | v32; // clear cell first

		if (idx == 1) return (b64W6 & MSK32_0_6TO11) | (v32 << 6); // clear cell first

		if (idx == 2) return (b64W6 & MSK32_0_12TO17) | (v32 << 12); // clear cell first

		if (idx == 3) return (b64W6 & MSK32_0_18TO23) | (v32 << 18); // clear cell first

		if (idx == 4) return (b64W6 & MSK32_0_24TO29) | (v32 << 24); // clear cell first

		if (idx == 5) return (b64W6 & MSK0_30TO35) | ((long) v32 << 30); // clear cell first

		if (idx == 6) return (b64W6 & MSK0_36TO41) | ((long) v32 << 36); // clear cell first

		if (idx == 7) return (b64W6 & MSK0_42TO47) | ((long) v32 << 42); // clear cell first

		if (idx == 8) return (b64W6 & MSK0_48TO53) | ((long) v32 << 48); // clear cell first

		return (b64W6 & MSK0_54TO59) | ((long) v32 << 54); // if (idx == 9)
	}
}
