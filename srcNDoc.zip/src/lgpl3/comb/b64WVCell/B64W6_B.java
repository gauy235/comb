package lgpl3.comb.b64WVCell;

import lgpl3.o.B;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/10/05_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_B" >src</a>
 *
 * @see B64W6_D
 */
public abstract class B64W6_B extends B64W6BitPerCellFromR { // private static final Class<?> THIS = B64W6_B.class;

	/**
	 * The total none 0 cells in a B64W6.
	 */
	public static int totalVCell(long b64W6) {

		int b32W6 = (int) b64W6;

		if ((b32W6 & MASK32) == 0b0) return 0;

		if ((b32W6 & MASK32_1_7TO_12) == 0b0) return 1;

		if ((b32W6 & MASK32_1_13TO_18) == 0b0) return 2;

		if ((b32W6 & MASK32_1_19TO_24) == 0b0) return 3;

		if ((b32W6 & MASK32_1_25TO_30) == 0b0) return 4;

		if ((b64W6 & MASK1_31TO_36) == 0b0L) return 5;

		if ((b64W6 & MASK1_37TO_42) == 0b0L) return 6;

		if ((b64W6 & MASK1_43TO_48) == 0b0L) return 7;

		if ((b64W6 & MASK1_49TO_54) == 0b0L) return 8;

		if ((b64W6 & MASK1_55TO_60) == 0b0L) return 9;

		return 10;
	}

	/**
	 * To reverse among every 6-bit cell.<br/>
	 */
	public static long revAmongVCell(long b64W6) { // if (b64W6 == 0b0L) return 0b0L;

		long ret = 0b0L;
		do {
			ret |= ((int) b64W6) & MASK32;

			if ((b64W6 >>>= $6) == 0b0L) return ret; // b64 可在兩 cell 之間會有空的 cell

			ret <<= $6;

		} while (B.T); // O.l("revAmongVCell=" + str24(ret));
	}

	/**
	 * To reverse against every 6-bit cell.<br/>
	 */
	public static int revAmongVCell(int b32W6) {

		int retB32W6 = 0b0;
		do {
			retB32W6 |= (b32W6 & MASK32);

			if ((b32W6 >>>= $6) == 0b0) return retB32W6;

			retB32W6 <<= $6;

		} while (B.T);
	}

	// public static int at(long b64W6, int idx) { return ((int) (b64W6 >>> ($6 * idx))) & MASK32;}

	/**
	 * To get the leftest none 0 value in the cell of a B64W6.<br/>
	 */
	public static int tailV(long b64W6) { // if (b64W6 == 0b0L) throw new IllegalArgumentException();

		do
			if ((b64W6 >>> $6) == 0b0L) return (int) b64W6; // the rightmost cell

		while ((b64W6 >>>= $6) != 0b0L);

		throw new IllegalArgumentException();
	}

	/**
	 * To get min.<br/>
	 */
	public static int getMin(long b64W6) {

		int min = $MAX_INT32_IN_CELL, vCell;
		do
			if ((vCell = (((int) b64W6) & MASK32)) < min) min = vCell; // O.l("vCell=" + vCell, THIS);

		while ((b64W6 >>>= $6) != 0b0L);

		return min;
	}

	/**
	 * To get max.<br/>
	 */
	public static int getMax(long b64W6) {

		int max = 1, vCell;
		do
			if ((vCell = (((int) b64W6) & MASK32)) > max) max = vCell; // O.l("vCell=" + vCell, THIS);

		while ((b64W6 >>>= $6) != 0b0L);

		return max;
	}

	/**
	 * To swap the values in the two cells.<br/>
	 */
	public static long swapVCell(long b64W6, int idx1, int idx2) {

		int v1 = ((int) (b64W6 >>> ($6 * idx1))) & MASK32; // at(b64W6, idx1);
		int v2 = ((int) (b64W6 >>> ($6 * idx2))) & MASK32; // at(b64W6, idx2);

		////////////// pasteAt(b64W6, idx1, v2);

		if (idx1 == 0) b64W6 = (b64W6 & MASK32_0) | v2; // clear cell first

		else if (idx1 == 1) b64W6 = (b64W6 & MASK32_0_7TO_12) | (v2 << 6); // clear cell first

		else if (idx1 == 2) b64W6 = (b64W6 & MASK32_0_13TO_18) | (v2 << 12); // clear cell first

		else if (idx1 == 3) b64W6 = (b64W6 & MASK32_0_19TO_24) | (v2 << 18); // clear cell first

		else if (idx1 == 4) b64W6 = (b64W6 & MASK32_0_25TO_30) | (v2 << 24); // clear cell first

		else if (idx1 == 5) b64W6 = (b64W6 & MASK0_31TO_36) | ((long) v2 << 30); // clear cell first

		else if (idx1 == 6) b64W6 = (b64W6 & MASK0_37TO_42) | ((long) v2 << 36); // clear cell first

		else if (idx1 == 7) b64W6 = (b64W6 & MASK0_43TO_48) | ((long) v2 << 42); // clear cell first

		else if (idx1 == 8) b64W6 = (b64W6 & MASK0_49TO_54) | ((long) v2 << 48); // clear cell first

		else b64W6 = (b64W6 & MASK0_55TO_60) | ((long) v2 << 54); // if (idx1 == 9)

		////////////// pasteAt(b64W6, idx2, v1);

		if (idx2 == 0) return (b64W6 & MASK32_0) | v1; // clear cell first

		if (idx2 == 1) return (b64W6 & MASK32_0_7TO_12) | (v1 << 6); // clear cell first

		if (idx2 == 2) return (b64W6 & MASK32_0_13TO_18) | (v1 << 12); // clear cell first

		if (idx2 == 3) return (b64W6 & MASK32_0_19TO_24) | (v1 << 18); // clear cell first

		if (idx2 == 4) return (b64W6 & MASK32_0_25TO_30) | (v1 << 24); // clear cell first

		if (idx2 == 5) return (b64W6 & MASK0_31TO_36) | ((long) v1 << 30); // clear cell first

		if (idx2 == 6) return (b64W6 & MASK0_37TO_42) | ((long) v1 << 36); // clear cell first

		if (idx2 == 7) return (b64W6 & MASK0_43TO_48) | ((long) v1 << 42); // clear cell first

		if (idx2 == 8) return (b64W6 & MASK0_49TO_54) | ((long) v1 << 48); // clear cell first

		return (b64W6 & MASK0_55TO_60) | ((long) v1 << 54); // if (idx2 == 9)
	}

	/**
	 * To replace the cell at index of B64W6.<br/>
	 */
	public static long pasteAt(long b64W6, int idx, int v32) { // first index is 0

		if (idx == 0) return (b64W6 & MASK32_0) | v32; // clear cell first

		if (idx == 1) return (b64W6 & MASK32_0_7TO_12) | (v32 << 6); // clear cell first

		if (idx == 2) return (b64W6 & MASK32_0_13TO_18) | (v32 << 12); // clear cell first

		if (idx == 3) return (b64W6 & MASK32_0_19TO_24) | (v32 << 18); // clear cell first

		if (idx == 4) return (b64W6 & MASK32_0_25TO_30) | (v32 << 24); // clear cell first

		if (idx == 5) return (b64W6 & MASK0_31TO_36) | ((long) v32 << 30); // clear cell first

		if (idx == 6) return (b64W6 & MASK0_37TO_42) | ((long) v32 << 36); // clear cell first

		if (idx == 7) return (b64W6 & MASK0_43TO_48) | ((long) v32 << 42); // clear cell first

		if (idx == 8) return (b64W6 & MASK0_49TO_54) | ((long) v32 << 48); // clear cell first

		return (b64W6 & MASK0_55TO_60) | ((long) v32 << 54); // if (idx == 9)
	}
}
