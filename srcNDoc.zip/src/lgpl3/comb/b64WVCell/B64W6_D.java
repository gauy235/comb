package lgpl3.comb.b64WVCell;

import lgpl3.o.B;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_D" >src</a>
 *
 * @see B64W6_G
 */
public abstract class B64W6_D extends B64W6_B { // private static final Class<?> THIS = B64W6_D.class;

	/**
	 * The most right hand side is the smallest.<br/>
	 */
	public static long easySort(long b64W6, int totalVCell) { // 簡單粗暴: 找最大, 放到容器; 找最大, 放到容器

		int max, vCell;

		long tmp64, ret = 0b0L;
		do {
			max = 1;
			tmp64 = b64W6;

			do {
				if ((vCell = (int) tmp64 & MSK) == 0) continue; // 之後的操作會填 0

				if (vCell > max) max = vCell; // O.lv(lv, "continue=" + B64W6.strByVCell(tmp64) + "=" + B64W6.str(tmp64));

			} while ((tmp64 >>>= $6) != 0b0L);

			ret = (ret <<= $6) | max;

			if (--totalVCell == 0) return ret; // 提早結束

			if (((int) b64W6 & MSK) == max) b64W6 &= MSK32_0_0TO5; // 原本 max 處填 0

			else if (((int) b64W6 & MSK32_6TO11) >>> 6 == max) b64W6 &= MSK32_0_6TO11;

			else if (((int) b64W6 & MSK32_12TO17) >>> 12 == max) b64W6 &= MSK32_0_12TO17;

			else if (((int) b64W6 & MSK32_18TO23) >>> 18 == max) b64W6 &= MSK32_0_18TO23;

			else if (((int) b64W6 & MSK32_24TO29) >>> 24 == max) b64W6 &= MSK32_0_24TO29;

			else if ((int) ((b64W6 & MSK_30TO35) >>> 30) == max) b64W6 &= MSK0_30TO35;

			else if ((int) ((b64W6 & MSK_36TO41) >>> 36) == max) b64W6 &= MSK0_36TO41;

			else if ((int) ((b64W6 & MSK_42TO47) >>> 42) == max) b64W6 &= MSK0_42TO47;

			else if ((int) ((b64W6 & MSK_48TO53) >>> 48) == max) b64W6 &= MSK0_48TO53;

			else if ((int) ((b64W6 & MSK_54TO59) >>> 54) == max) b64W6 &= MSK0_54TO59;

		} while (B.T);
	}

	/**
	 * The most right hand side is the smallest.<br/>
	 */
	public static long easySortAftTotalVCell(long b64W6) {

		return easySort(b64W6, totalVCell(b64W6));
	}

	/**
	 * Sorts in descending order.<br/>
	 */
	public static long easySortDesc(long b64W6, int totalVCell) {

		return revAmongVCell(easySort(b64W6, totalVCell(b64W6)));
	}
}
