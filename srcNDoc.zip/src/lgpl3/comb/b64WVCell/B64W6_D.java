package lgpl3.comb.b64WVCell;

import lgpl3.o.B;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_D" >src</a>
 *
 * @see B64W6_G
 */
public abstract class B64W6_D extends B64W6_B { // private static final Class<?> THIS = B64W6_D.class;

	/**
	 * The most right hand side is the smallest.<br/>
	 */
	public static long easySort(long b64W6, int totalVCell) { // 簡單粗暴: 找最大, 放到容器; 找最大, 放到容器

		int max, vCell;

		long tmpB64W6, ret = 0b0L;
		do {
			max = 0b1;
			tmpB64W6 = b64W6;

			do if ((vCell = (int) tmpB64W6 & MSK) > max) max = vCell; while ((tmpB64W6 >>>= $6) != 0b0L); // O.l("v=" + vCell);

			ret = (ret <<= $6) | max;

			if (--totalVCell == 0) return ret;

			///////////////////////////////////////////////

			if (((int) b64W6 & MSK) == max)

				b64W6 = (b64W6 &= MSK32_0_0TO5) | 0b00_000000_000000_000000_000000_000001; // 改成最小值 1

			else if (((int) b64W6 & MSK32_6TO11) >>> 6 == max)

				b64W6 = (b64W6 &= MSK32_0_6TO11) | 0b00_000000_000000_000000_000001_000000;

			else if (((int) b64W6 & MSK32_12TO17) >>> 12 == max)

				b64W6 = (b64W6 &= MSK32_0_12TO17) | 0b00_000000_000000_000001_000000_000000;

			else if (((int) b64W6 & MSK32_18TO23) >>> 18 == max)

				b64W6 = (b64W6 &= MSK32_0_18TO23) | 0b00_000000_000001_000000_000000_000000;

			else if (((int) b64W6 & MSK32_24TO29) >>> 24 == max)

				b64W6 = (b64W6 &= MSK32_0_24TO29) | 0b00_000001_000000_000000_000000_000000;

			else if ((int) ((b64W6 & MSK_30TO35) >>> 30) == max)

				b64W6 = (b64W6 &= MSK0_30TO35) | 0b0000_000000_000000_000000_000000_000001_000000_000000_000000_000000_000000L;

			else if ((int) ((b64W6 & MSK_36TO41) >>> 36) == max)

				b64W6 = (b64W6 &= MSK0_36TO41) | 0b0000_000000_000000_000000_000001_000000_000000_000000_000000_000000_000000L;

			else if ((int) ((b64W6 & MSK_42TO47) >>> 42) == max)

				b64W6 = (b64W6 &= MSK0_42TO47) | 0b0000_000000_000000_000001_000000_000000_000000_000000_000000_000000_000000L;

			else if ((int) ((b64W6 & MSK_48TO53) >>> 48) == max)

				b64W6 = (b64W6 &= MSK0_48TO53) | 0b0000_000000_000001_000000_000000_000000_000000_000000_000000_000000_000000L;

			else if ((int) ((b64W6 & MSK_54TO59) >>> 54) == max)

				b64W6 = (b64W6 &= MSK0_54TO59) | 0b0000_000001_000000_000000_000000_000000_000000_000000_000000_000000_000000L;

		} while (B.T);
	}

	/**
	 * The most right hand side is the smallest.<br/>
	 */
	public static long easySortAftTotalVCell(long b64W6) {

		return easySort(b64W6, totalVCell(b64W6));
	}

	/**
	 * To sort in descending order.<br/>
	 */
	public static long easySortDesc(long b64W6, int totalVCell) {

		int min, vCell;

		long tmp64, ret = 0b0L;
		do {
			min = $MAX_INT32_IN_CELL;
			tmp64 = b64W6;

			do if ((vCell = (int) tmp64 & MSK) < min) min = vCell; while ((tmp64 >>>= $6) != 0b0L);

			ret = (ret <<= $6) | min;

			if (--totalVCell == 0) return ret;

			///////////////////////////////////////////////

			if (((int) b64W6 & MSK) == min) b64W6 |= MSK; // 原本 min 處 改 63 最大

			else if (((int) b64W6 & MSK32_6TO11) >>> 6 == min) b64W6 |= MSK32_6TO11;

			else if (((int) b64W6 & MSK32_12TO17) >>> 12 == min) b64W6 |= MSK32_12TO17;

			else if (((int) b64W6 & MSK32_18TO23) >>> 18 == min) b64W6 |= MSK32_18TO23;

			else if (((int) b64W6 & MSK32_24TO29) >>> 24 == min) b64W6 |= MSK32_24TO29;

			else if ((int) ((b64W6 &= MSK_30TO35) >>> 30) == min) b64W6 |= MSK_30TO35;

			else if ((int) ((b64W6 &= MSK_36TO41) >>> 36) == min) b64W6 |= MSK_36TO41;

			else if ((int) ((b64W6 &= MSK_42TO47) >>> 42) == min) b64W6 |= MSK_42TO47;

			else if ((int) ((b64W6 &= MSK_48TO53) >>> 48) == min) b64W6 |= MSK_48TO53;

			else if ((int) ((b64W6 &= MSK_54TO59) >>> 54) == min) b64W6 |= MSK_54TO59;

		} while (B.T);
	}
}
