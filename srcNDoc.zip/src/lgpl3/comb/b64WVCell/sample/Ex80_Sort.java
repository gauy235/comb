package lgpl3.comb.b64WVCell.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.shuffle.Shuffler;

/**
 * sorts.<br/>
 *
 * @version 2023/12/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex80_Sort" >src</a>
 *
 */
public class Ex80_Sort {

	public static void main(String[] sAry) throws Throwable {

		int[] ar = { 40, 50, 12, 9, 4, 6, 10 };

		Shuffler.shuffle(ar);

		long b64W6 = B64W6.genB64W6ByAr32(ar);
		O.l("bef=" + O.L + B64W6.strByVCell(b64W6) + "=" + B64W6.str24(b64W6));

		b64W6 = B64W6.easySort(b64W6, B64W6.totalVCell(b64W6));
		// b64W6 = B64W6.easySortDesc(b64W6, B64W6.totalVCell(b64W6));

		O.l("easySort=" + O.L + B64W6.strByVCell(b64W6) + "=" + B64W6.str24(b64W6));

		O.l("min=" + B64W6.getMin(b64W6));
		O.l("max=" + B64W6.getMax(b64W6));

	}
}
