package lgpl3.comb.b64WVCell.sample;

import java.util.Arrays;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;
import lgpl3.shuffle.Shuffler;

/**
 * To find index.<br/>
 *
 * @version 2023/10/21_22:00:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex07_FindIdx" >src</a>
 *
 */
public class Ex07_FindIdx {

	public static void main(String[] sAry) throws Throwable {

		int ar[] = { 20, 30, 40, 50 }, max;

		Shuffler.shuffle(ar);

		long b64W6 = B64W6.genB64W6ByAr32(ar);

		O.l("ar=" + Arrays.toString(ar));
		O.l("b64W6=" + B64W6.str24(b64W6));

		max = B64W6.getMax(b64W6);
		O.l("max=" + max);

		O.l("iFound=" + O.eq(B64W6.findIdx(b64W6, max), Ar32va.findFirstOccurDownTo0(ar, ar.length - 1, max)));

	}
}
