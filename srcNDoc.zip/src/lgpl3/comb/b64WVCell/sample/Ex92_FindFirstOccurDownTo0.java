package lgpl3.comb.b64WVCell.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;

/**
 * @version 2020/04/22_12:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex92_FindFirstOccurDownTo0" >src</a>
 *
 * @see Ex88_TestSelSort
 */
public class Ex92_FindFirstOccurDownTo0 {

	public static void main(String[] sAry) throws Throwable {

		int[] ar = { 10, 63, 20, 40, 63 }; // max 63

		long b64W6 = B64W6.genB64W6ByAr32(ar);

		O.l("b64W6=" + O.L + B64W6.str(b64W6));

		O.l("iFound=" + B64W6.findFirstOccurDownTo0(b64W6, ar.length, 63));
	}
}