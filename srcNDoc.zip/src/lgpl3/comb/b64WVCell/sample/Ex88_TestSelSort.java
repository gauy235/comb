package lgpl3.comb.b64WVCell.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.shuffle.Shuffler;

/**
 * @version 2022/12/22_11:20:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex88_TestSelSort" >src</a>
 *
 */
public class Ex88_TestSelSort {

	public static void main(String[] sAry) throws Throwable {

		int[] ary32 = new int[] { 10, 20, 30, 40, 50 };

		O.l("ary32=");
		O.l(Shuffler.shuffle(ary32));
		O.l("==========");

		long b64W6 = B64W6.genB64W6ByAry32(ary32);
		long b64W6_2 = B64W6.genB64W6ByAry32(ary32);

		b64W6_2 = B64W6.easySortAftTotalVCell(b64W6_2);

		O.l(B64W6.strByVCellAftRev(b64W6));

		b64W6 = B64W6.revAmongVCell(b64W6);

		O.l(B64W6.strByVCellAftRev(b64W6));

	}
}