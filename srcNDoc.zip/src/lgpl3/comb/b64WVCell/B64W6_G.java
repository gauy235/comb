package lgpl3.comb.b64WVCell;

import lgpl3.b32.B32va;
import lgpl3.o.B;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/10/28_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_G" >src</a>
 *
 * @see B64W6_Q
 */
public abstract class B64W6_G extends B64W6_D { // private static final Class<?> THIS = B64W6_G.class;

	/**
	 * rotateR<br/>
	 */
	public static long rotR(long b64W6, int len) {

		return ((b64W6 & MASK32) << ($6 * --len)) | (b64W6 >>> $6);
	}

	/**
	 * plus a value in the cell.<br/>
	 */
	public static long plusAt(long b64W6, int idx, int v32) {

		v32 = ((int) (b64W6 >>> ($6 * idx)) & MASK32) + v32; // O.l("v32=" + v32);

		return (b64W6 & ~(MASK1_1TO_6 << idx)) | ((long) v32 << idx);
	}

	/**
	 * plus a value in all the cells.<br/>
	 */
	public static long plusAllVCellNRev(long b64W6, int v32) {

		long ret = 0b0L;
		do {
			ret |= ((int) b64W6 & MASK32) + v32;

			if ((b64W6 >>>= $6) == 0b0L) return ret;

			ret <<= $6;

		} while (B.T);
	}

	/**
	 * plus a value in all the cells.<br/>
	 */
	public static long plusAllVCell(long b64W6, int v32) {

		return revAmongVCell(plusAllVCellNRev(b64W6, v32));
	}

	/**
	 * Converts.<br/>
	 *
	 * @see #b32As2PowByVCell(long)
	 */
	public static int[] ar32OfB32As2Pow(long b64W6) {

		int ret[] = new int[totalVCell(b64W6)], idx = 0;

		do ret[idx++] = 0b1 << (((int) b64W6 & MASK32) - 1 /* 再減 1 */); while ((b64W6 >>>= $6) != 0b0L);

		// b64W6 不會在兩 cell 之間有空的 cell

		return ret;
	}

	/**
	 * Converts.<br/>
	 *
	 * @see #b64As2PowByVCell(long)
	 */
	public static long genDescByLgAd(int b32As2Pow) {

		long ret = 0b0L;

		int low1;

		do ret = (ret <<= $6) | B32va.lgAd(low1 = -b32As2Pow & b32As2Pow); while ((b32As2Pow &= ~low1) != 0b0); // asc

		return ret;
	}

	/**
	 * Converts.<br/>
	 *
	 * @see #b64As2PowByVCell(long)
	 */
	public static long genByLgAd(int b32As2Pow) {

		return revAmongVCell(genDescByLgAd(b32As2Pow));
	}

	/**
	 * Converts.<br/>
	 *
	 * @see #b64As2PowByVCell(long)
	 */
	public static int b32As2PowByVCell(long b64W6) { // if (b64W6 == 0b0L) return 0b0;

		int ret = 0b0;

		do ret |= 0b1 << (((int) b64W6 & MASK32) - 1); while ((int) (b64W6 >>>= $6) != 0b0); // b64W6 在兩 cell 之間沒空的 cell

		return ret;
	}

	/**
	 * Converts.<br/>
	 *
	 * @see #genDescByLgAd(int)
	 */
	public static long b64As2PowByVCell(long b64W6) {

		if (b64W6 == 0b0L) return 0b0L; // b64W6 can be 0

		long ret = 0b0L; // todo: 先 sort 後, 大的去聯集小的

		do ret |= 0b1L << (((int) b64W6 & MASK32) - 1 /* 再減 1 */); while ((b64W6 >>>= $6) != 0b0L);

		// b64W6 在兩 cell 之間沒空的 cell

		return ret;
	}

	/**
	 * To sum.<br/>
	 */
	public static int sum32(long b64W6) {

		int ret = 0;

		do ret += (int) b64W6 & MASK32; while ((b64W6 >>>= $6) != 0b0L);

		return ret;
	}
}
