package lgpl3.comb.b64WVCell;

import lgpl3.b32.B32va;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/10/05_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_G" >src</a>
 *
 * @see B64W6_L
 */
public abstract class B64W6_G extends B64W6_D { // private static final Class<?> THIS = B64W6_G.class;

	/**
	 * To convert.<br/>
	 *
	 * @see #toB32As2PowByB6Cell(long)
	 */
	public static int[] ary32OfB32As2Pow(long b64W6) {

		int ret[] = new int[totalVCell(b64W6)], idx = 0;
		do
			ret[idx++] = 0b1 << ((((int) b64W6) & MASK32) - 1); // minus 1

		while (((int) (b64W6 >>>= $6)) != 0b0); // b64W6 不會在兩 cell 之間有空的 cell

		return ret;
	}

	/**
	 * To convert.<br/>
	 *
	 * @see #toB64As2PowByB6Cell(long)
	 */
	public static long toB64W6ByLog2NPlus1(int b32As2Pow) {

		long ret = 0b0L;

		int low1;
		do
			ret = (ret << $6) | B32va.log2NPlus1(low1 = (-b32As2Pow & b32As2Pow));

		while ((b32As2Pow = (~low1 & b32As2Pow)) != 0b0);

		return revAmongVCell(ret);
	}

	/**
	 * To convert.<br/>
	 * To convert.
	 *
	 * @see #toB64As2PowByB6Cell(long)
	 */
	public static long toDescB64W6ByLog2NPlus1(int b32As2Pow) {

		long ret = 0b0L;

		int low1;
		do
			ret = (ret << $6) | B32va.log2NPlus1(low1 = (-b32As2Pow & b32As2Pow));

		while ((b32As2Pow = (~low1 & b32As2Pow)) != 0b0);

		return ret;
	}

	/**
	 * To convert.<br/>
	 *
	 * @see #toB64As2PowByB6Cell(long)
	 */
	public static int toB32As2PowByB6Cell(long b64W6) { // if (b64W6 == 0b0L) return 0b0; // b64W6 may be 0

		int ret = 0b0;
		do
			ret |= 0b1 << ((((int) b64W6) & MASK32) - 1);

		while ((int) (b64W6 >>>= $6) != 0b0); // b64W6 不會在兩 cell 之間有空的 cell

		return ret;
	}

	/**
	 * To convert.<br/>
	 *
	 * @see #toDescB64W6ByLog2NPlus1(int)
	 */
	public static long toB64As2PowByB6Cell(long b64W6) {

		if (b64W6 == 0b0L) return 0b0L; // b64W6 can be 0

		long ret = 0b0L;
		do
			ret |= 0b1L << ((((int) b64W6) & MASK32) - 1); // todo: 先 sort 後, 大的去聯集小的

		while ((int) (b64W6 >>>= $6) != 0b0); // b64W6 不會在兩 cell 之間有空的 cell

		return ret;
	}

	/**
	 * To filter.
	 */
	public static int filterAftToB32As2PowByVCell(int baseB32, long b64W6) {

		int b32 = 0b0;
		do
			b32 |= (0b1 << ((((int) b64W6) & MASK32) - 1));

		while (((int) (b64W6 >>>= $6)) != 0b0); // b64W6 不會在兩 cell 之間有空的 cell

		return (~b32 & baseB32);
	}

	/**
	 * To sum.<br/>
	 */
	public static int sum32(long b64W6) {

		int ret = 0;
		do
			ret += (((int) b64W6) & MASK32);

		while ((b64W6 >>>= $6) != 0b0L);

		return ret;

	}
}
