package lgpl3.comb.b64WVCell;

import lgpl3.b32.B32va;
import lgpl3.o.B;
import lgpl3.o.ary.Aryva;

/**
 * The first index of cell from the right hand side is 0.
 *
 * @version 2023/12/03_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64W6_Y" >src</a>
 *
 * @see B64W6
 */
public abstract class B64W6_Y extends B64W6_Q { // private static final Class<?> THIS = B64W6_Y.class;

	/**
	 * All values must be under 11.<br/>
	 * The int[]{1, 3, 3} returns: 2
	 */
	public static int distrNCnt(long unsortedB64W6) { // distributive sort 各自歸位法 unsortedB64W6 must not be 0b0L

		long b64W6 = 0b0L; // O.l("unsortedB64W6=" + str24(unsortedB64W6));

		int cnt = 0;

		do b64W6 |= 0b1L << $6 * (((int) unsortedB64W6 & MSK) - 1); while ((unsortedB64W6 >>>= $6) != 0b0L);

		for (; ((int) b64W6 & MSK) == 0b0; b64W6 >>>= $6); // trim 跳過空 cell // O.l( "cnt=" + cnt);

		do if (((int) b64W6 & MSK) != 0b0) cnt++; while ((b64W6 >>>= $6) != 0b0L);

		return cnt;
	}

	/**
	 * All values must be under 11.<br/>
	 * The int[]{1, 4, 3} returns: 0b000001_000011_000100
	 */
	public static long distrSortDesc(long unsortedDistB64W6) { // distributive sort 各自歸位法

		// 注意 第 1 個值放在第 0 cell, 第 2 個值 放在第 1 cell, 當第 11 個值放在第 10 cell, long 會變負數

		long ret = 0b0L, tmp;

		int v32;
		do {
			v32 = (int) (tmp = unsortedDistB64W6 & MSK);

			ret |= tmp <<= ($6 * --v32);

		} while ((unsortedDistB64W6 >>>= $6) != 0b0L);

		tmp = ret;

		ret = 0b0L; // O.l("tmp & MASK32=" + str((int) (tmp & MASK32))); // long 可能變負數

		do if ((v32 = (int) (tmp & MSK)) != 0b0) ret = (ret <<= $6) | v32; while ((tmp >>>= $6) != 0b0L);

		return ret; // O.l("ret=" + str(ret));
	}

	/**
	 * All values must be under 11.<br/>
	 * The int[]{1, 4, 3} returns: 0b000100_000011_000001
	 */
	public static long distrSort(long unsortedDistB64W6) { // distributive sort 各自歸位法

		return revAmongVCell(distrSortDesc(unsortedDistB64W6));
	}

	/**
	 * Compares.<br/>
	 * 比較 2 個 B64W6 的 head VCell.<br/>
	 */
	public static int compaB64W6FromR(long b64W6A, long b64W6B) {

		int vA; // O.l("b64W6A=" + str24(b64W6A));
		do {
			vA = (int) b64W6A & MSK;

			if ((vA -= (int) b64W6B & MSK) != 0) return vA;

			if ((b64W6A >>>= $6) == 0b0L) return 0; // 假設 b64W6A 跟 b64W6B len 相同

			b64W6B >>>= $6;

		} while (B.T);
	}

	/**
	 * sorts by to convert.<br/>
	 */
	public static long sortByLgAdDesc(long b64W6) {

		int allLo1 = 0b0, lo1;

		do allLo1 |= 0b1 << ((int) b64W6 & MSK) - 1; while ((b64W6 >>>= $6) != 0b0L);

		do b64W6 = (b64W6 <<= $6) | B32va.lgAd(lo1 = -allLo1 & allLo1); while ((allLo1 &= ~lo1) != 0b0);

		return b64W6;
	}

	/**
	 * sorts by to convert.<br/>
	 */
	public static long sortByLgAd(long b64W6) {

		return revAmongVCell(sortByLgAdDesc(b64W6));
	}

	/**
	 * merge sort.<br/>
	 *
	 * @see Aryva #merge(long[], int, int, int)
	 */
	public static void mergeAr(long[] arOfB64W6, int l, int mid, int r) {

		long tmpAr[] = new long[r - l + 1], vL, vM; // 使用額外空間

		int iL = l, iM = (mid + 1), iT = 0;

		while (iL <= mid && iM <= r)

			if (compaB64W6FromR(vL = arOfB64W6[iL], vM = arOfB64W6[iM]) < 0) {

				tmpAr[iT++] = vL;
				iL++; // // 此情況下 iL 延長

			} else {

				tmpAr[iT++] = vM;
				iM++; // // 此情況下 iM 延長
			}

		while (iL <= mid) tmpAr[iT++] = arOfB64W6[iL++];

		while (iM <= r) tmpAr[iT++] = arOfB64W6[iM++];

		iT = 0;

		do arOfB64W6[l++] = tmpAr[iT++]; while (l <= r); // 回寫回去
	}

	/**
	 * merge sort.<br/>
	 */
	public static long[] mgSortAr(long[] arOfB64W6, int l, int r) {

		if (l < r) {

			int mid = (l + r) >>> 1;

			mgSortAr(arOfB64W6, l, mid);

			mgSortAr(arOfB64W6, (mid + 1), r);

			mergeAr(arOfB64W6, l, mid, r);
		}

		return arOfB64W6;
	}

	// / **
	// * merge sort.<br/>
	// */
	// public static long[] mgSortArDesc(long[] arOfB64W6, int l, int r) {

	// return Aryva.rev(mgSortAr(arOfB64W6, l, r));

	// 注意: 比較最右邊的順序 不等於比較最左邊後再反向

	// B64W6A=[60 20 30]
	// B64W6B=[50 40 10]

	// 比右: B64W6A > B64W6B
	// 比左: 仍然 B64W6A > B64W6B
	// }

	/**
	 * Partition.<br/>
	 */
	public static int goPivot(long[] arOfB64W6, int left, int right /* both inclusive */) {

		int iCnt = left, j;

		long pivot = arOfB64W6[left], tmpV; // 陣列頭當 pivot

		for (j = left + 1; j <= right; j++) if ((compaB64W6FromR(arOfB64W6[j], pivot) < 0) && (++iCnt != j)) {

			tmpV = arOfB64W6[iCnt]; // swap(iCnt, j) 小的排在我左邊
			arOfB64W6[iCnt] = arOfB64W6[j];
			arOfB64W6[j] = tmpV;
		}

		arOfB64W6[left] = arOfB64W6[iCnt]; // swap(left, iCnt) 最後 跟 那群小朋友的尾巴 交換
		arOfB64W6[iCnt] = pivot;

		return iCnt;
	}

	/**
	 * QuickSort.<br/>
	 * 比較 2 個 B64W6 的 head VCell.<br/>
	 */
	public static long[] qSortAr(long[] arOfB64W6, int left, int right /* both inclusive */) {

		if (left < right) {

			int iPivot = goPivot(arOfB64W6, left, right);

			qSortAr(arOfB64W6, left, (iPivot - 1));

			qSortAr(arOfB64W6, (iPivot + 1), right);
		}

		return arOfB64W6;
	}
}
