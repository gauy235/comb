package lgpl3.comb;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MSK;

import lgpl3.b32.B32va;
import lgpl3.b64.B64va;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.keyNV.KArV32;

/**
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=PcirDnk_J" >src</a>
 *
 * @see PcirDnk
 */
public abstract class PcirDnk_J extends PcirDnk_A { // private static final Class<?> THIS = PcirDnk_J.class;

	public static int k;

	public static long sortedB64W6;

	/**
	 * If Derangement.<br/>
	 */
	public static boolean isDnkAftPcir(long b64W6) {

		long asc64 = sortedB64W6;

		int cnt = k; // 可以少比 1 次嗎 不可 上層有旋轉過
		do {
			if (((int) b64W6 & MSK) == ((int) asc64 & MSK)) return !B.T;

			if (--cnt == 0) return B.T;

			b64W6 >>>= $6;
			asc64 >>>= $6;

		} while (B.T);
	}

	/**
	 * 環狀排列且全錯排.<br/>
	 * Circular permutation and Derangement.
	 */
	public static long checkPcirAsDnk(long b64W6) { // 直接檢查 不用 B64W6.revAmongVCell

		int cnt = ((k & 0b1) == 0b0) ? (k - 1) : (k - 2); // 偶數可以少比 1 次
		do {
			if (isDnkAftPcir(b64W6)) return b64W6; // O.l("b64W6=" + B64W6.str24(b64W6));

			if (--cnt == 0) return 0b0L; // 提早跳出

			b64W6 = ((b64W6 & MSK) << $6 * (k - 1)) | (b64W6 >>> $6); // 向右旋轉 1 步

		} while (B.T);
	}

	/**
	 * 環狀排列且全錯排.<br/>
	 * Circular permutation and Derangement.
	 */
	public static void recurPcirWNEqK(int rmdB32, long prefix, KArV32 retKV) {

		prefix <<= $6;

		if ((-rmdB32 & rmdB32) == rmdB32) { // 等加入到最末尾 VCell 才檢查

			// O.l("pre=" + B64W6.strByVCellMinus1BySAry(prefix, O.ARY_A_Z) + "=" + B64W6.str24(prefix));

			// if ((prefix = checkPcirAsDnk(prefix |= B32va.lgAd(rmdB32), B64W6.distrSort(prefix))) != 0b0L)

			// if ((prefix = checkPcirAsDnk(prefix |= B32va.lgAd(rmdB32), B64W6.easySort(prefix, k))) != 0b0L)

			// if ((prefix = checkPcirAsDnk(prefix |= B32va.lgAd(rmdB32), B64W6.sortByLgAd(prefix))) != 0b0L)

			if ((prefix = checkPcirAsDnk(prefix |= B32va.lgAd(rmdB32))) != 0b0L) retKV.k[retKV.v++] = prefix;

			return;
		}

		int allLo1 = rmdB32, lo1; // O.l("allLo1=" + B32va.str16(allLo1));

		do recurPcirWNEqK(rmdB32 & ~(lo1 = -allLo1 & allLo1), (prefix | B64va.lgAd(lo1)), retKV);

		while ((allLo1 &= ~lo1) != 0b0); // allLo1 子彈打完
	}

	/**
	 * 從 1 列全相異數列中取出 k 個數.<br/>
	 * Picks several numbers from a list of distinct numbers.
	 */
	public static void recurC(final int boundBit, int rmdK, int allKept, int curBit, KArV32 retKV) {

		if (--rmdK == 0) {

			int allLo1, lo1;
			do {
				PcirDnk.sortedB64W6 = B64W6.genByLgAd(allLo1 = curBit | allKept); // 事先排序好

				// 環狀排列 最低位元塞在 B64W6 首位置

				recurPcirWNEqK(allLo1 & ~(lo1 = -allLo1 & allLo1), B32va.lgAd(lo1), retKV);

			} while ((curBit <<= 1) != boundBit);

			return;
		}

		int newBoundBit = boundBit >>> rmdK;

		do recurC(boundBit, rmdK, (curBit | allKept), (curBit <<= 1), retKV);

		while (curBit != newBoundBit);
	}

	/**
	 * 環狀排列且全錯排.<br/>
	 * Circular permutation and Derangement.
	 */
	public static long[] col(int n, int k) { // fuck, about 30, see toStrToOntoBySAryByB32, B32va.lgAd(b32)

		if (n <= 0 || n > 30 || k <= 0 || n < k) O.x("n=" + n + ", k=" + k);

		if (k == 1) return O.ARY0;

		PcirDnk.k = k;

		KArV32 retKV = new KArV32((int) int64(n, k));

		recurC((0b1 << n), k, 0b0, 0b1, retKV);

		return retKV.k;
	}
}
