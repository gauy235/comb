package lgpl3.comb;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MSK;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.keyNV.KArV32;

/**
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Pnk_W" >src</a>
 *
 * @see Pnk_Z
 */
public abstract class Pnk_W extends Pnk_J { // private static final Class<?> THIS = Pnk_W.class;

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static void easyRecurBySwap(int n, long prefix, int lv) {

		if (++lv == n) {

			B.cnt++;

			O.l(B64W6.strByVCellMinus1BySAry(prefix, O.ARY_A_Z) + "=" + B64W6.str24(prefix));

			return;
		}

		easyRecurBySwap(n, prefix, lv); // 保送 不交換 一次跑到底

		for (int idx = lv; idx != n; idx++) easyRecurBySwap(n, B64W6.swapVCell(prefix, (lv - 1), idx), lv); // todo:用 do while
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static void easyColBySwap(int n, long prefix, KArV32 kV, int lv) {

		B.cnt++;

		int next = lv + 1;

		if (next == n - 1) { // 剩下 2 個

			// O.l("lv=" + lv + " prefix=" + B64W6.strByVCellMinus1BySAry(prefix, O.ARY_A_Z), THIS);

			kV.k[kV.v++] = prefix;

			do kV.k[kV.v++] = B64W6.swapVCell(prefix, lv, next); while (++next != n); // 剩下的這 2 個交換

			return;
		}

		easyColBySwap(n, prefix, kV, next); // 保送 不交換 一次跑到底

		do easyColBySwap(n, B64W6.swapVCell(prefix, lv, next), kV, (lv + 1)); while (++next != n);
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static void cBefColBySwap(final int boundBit, int rmdK, int prefix, int curBit, KArV32 kV) {

		if (--rmdK == 0) {

			final int n = Integer.bitCount(prefix) + 1; // O.l("n=" + n, THIS);

			do easyColBySwap(n, B64W6.genByLgAd(curBit | prefix), kV, 0); while ((curBit <<= 1) != boundBit);

			return;
		}

		int newBoundBit = boundBit >>> rmdK;

		do cBefColBySwap(boundBit, rmdK, (curBit | prefix), (curBit <<= 1), kV); while (curBit != newBoundBit);
	}

	/**
	 * 從 1 全相異數列中取出 k 個數做排列.<br/>
	 */
	public static long[] colBySwap(int n, int k) {

		KArV32 retKV = new KArV32((int) int64(n, k));

		cBefColBySwap((0b1 << n), k, 0b0, 0b1, retKV);

		return retKV.k;
	}

	/**
	 * To pick several numbers from a list of distinct numbers then to permutate.<br/>
	 */
	public static void colBySwapWNGteK(int n, int k, long prefix, KArV32 kV, int lv) {

		B.cnt++;

		int next = lv + 1;

		if (next == k) { // mask 遮蔽, 只取前幾個

			long mask = ~(B64W6.MASK0_1TO_6 << ($6 * lv)), ar[] = kV.k; // O.l("mask=" + B64W6.str(mask), THIS);

			ar[kV.v++] = prefix & mask; // 縮短

			// 從後面 cell 抓來貼到前面
			do ar[kV.v++] = (B64W6.pasteAt(prefix, lv, ((int) (prefix >>> ($6 * next)) & MSK)) & mask); while (++next != n);

			return;
		}

		colBySwapWNGteK(n, k, prefix, kV, next); // 保送 不交換 一次跑到底

		do colBySwapWNGteK(n, k, B64W6.swapVCell(prefix, lv, next), kV, (lv + 1)); while (++next != n);
	}
}