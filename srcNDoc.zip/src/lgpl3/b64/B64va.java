package lgpl3.b64;

import lgpl3.b32.B32va;
import lgpl3.o.O;

/**
 * 本類別是使用 2 進位.<br/>
 * The 2 bit digit.
 *
 * @version 2022/05/10_20:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=B64va" >src</a>
 *
 * @see B32va
 */
public abstract class B64va extends B64va_L { // private static final Class<?> THIS = B64va.class;

	/**
	 * 回傳 2 進位字串建立者.<br/>
	 * To StringBuilder of 2 bit digit.
	 */
	public static StringBuilder str(long int64) {

		if (int64 == 0L) return new StringBuilder(S_64BIT_$0_W_UNDERLINE);

		if (int64 == 1L) return new StringBuilder(S_64BIT_$1_W_UNDERLINE);

		int len = 79, idx = len, iUd = 0;

		char[] cAr = new char[len];

		while (idx-- != 0)

			cAr[idx] = O.C48;

		idx = len - 1;
		do {
			if (((int) int64 & 0b1) != 0b0) cAr[idx] = O.C49;

			if (++iUd == 4 || iUd == 8 || iUd == 12 || iUd == 16 || iUd == 20 || iUd == 24 || iUd == 28 || iUd == 32 ||

					iUd == 36 || iUd == 40 || iUd == 44 || iUd == 48 || iUd == 52 || iUd == 56 || iUd == 60)

				cAr[--idx] = O.C95; // O.l("iUd=" + iUd, THIS);

			int64 >>>= 1;

		} while (idx-- != 0); // O.l("int64=" + int64, THIS);

		return new StringBuilder(len).append(cAr);

	}

	/**
	 * To StringBuilder from String array via bit64.<br/>
	 */
	public static StringBuilder strByLgInB64BySAry(long b64As2Pow, String[] sAry) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		long lowest1;
		do
			if ((lowest1 = (-b64As2Pow & b64As2Pow)) == b64As2Pow) return ret.append(sAry[lg(lowest1)]);

			else ret.append(sAry[lg(lowest1)]).append(O.C44);

		while ((b64As2Pow = (~lowest1 & b64As2Pow)) != 0b0L);

		throw new IllegalArgumentException("b64As2Pow=" + str(b64As2Pow));

	}
}
