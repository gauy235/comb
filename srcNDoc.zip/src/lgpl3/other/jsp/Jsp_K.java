package lgpl3.other.jsp;

import static java.lang.System.out;

import java.io.IOException;
import java.util.Arrays;

import lgpl3.o.str.SW;
import lgpl3.other.iO.IOr;

/**
 * @version 2021/06/16_09:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Jsp_K" >src</a>
 *
 * @see Jsp_U
 */
public abstract class Jsp_K extends Jsp_D {

	// private static final Class<?> THIS = Jsp_K.class;

	/**
	 * To StringBuilder by Exception.<br/>
	 * To StringBuilder by Exception.
	 */
	public static StringBuilder toStrByThrowable(Throwable throwable, CharSequence lineWr) {

		StringBuilder ret = new StringBuilder(defLenForStr);
		ret.append(throwable.toString()).append(lineWr);

		StackTraceElement[] allStackTraceElem = throwable.getStackTrace();

		for (int idx = 0; idx != allStackTraceElem.length; idx++)

			ret.append(allStackTraceElem[idx].toString()).append(lineWr);

		return ret;

	}

	/**
	 * To gen array.<br/>
	 * To gen array.
	 */
	public static int[] genAr32FromDirtyCharSeq(CharSequence charSeq) {

		final String sSeparator = S44;

		final String theChineseBlank = new String("\u3000"); // 全形空白
		final String theChineseComma = new String("\uFF0C"); // 全形逗號 全形逗點

		l("theChineseBlank=" + theChineseBlank);
		l("theChineseComma=" + theChineseComma);

		String dirtyS = ((charSeq instanceof String) ? (String) charSeq : charSeq.toString());

		dirtyS = dirtyS.replace(theChineseBlank, sSeparator);
		dirtyS = dirtyS.replace(theChineseComma, sSeparator);
		dirtyS = dirtyS.replace(S32, sSeparator); // 空白

		l("new dirtyS=" + dirtyS);

		String[] sAry = splitNTrimAll(dirtyS, sSeparator);

		int[] retAr32 = new int[sAry.length];

		int iRet = 0;
		for (int idx = 0; idx != sAry.length; idx++) {

			try {
				retAr32[iRet] = Integer.parseInt(sAry[idx]);

			} catch (NumberFormatException numberFormatEx) {

				out.println(numberFormatEx.toString());

				continue; // go to idx++

			}

			iRet++; // fuck

		}

		// l("retAr32=" + S32 + THIS);
		// l(retAr32);

		return delTailAll0(retAr32);

	}

	/**
	 * To view.<br/>
	 * To view.
	 */
	public static StringBuilder viewSource(String fromPath, String link) throws IOException {

		SW str = new SW();
		str.lineWr = L;

		// ex: ".java", ".html", ".jar", ".bat", ".xml", ".jsp";

		String regToIn = Z;
		String regToEx = "@@@@@"; // L.toString();

		StringBuilder strOfPath = IOr.listSubFileNDir(fromPath, regToIn, regToEx);

		String[] aryOfPath = strOfPath.toString().split(LINE_SEPARATOR); // fuck

		Arrays.sort(aryOfPath);

		for (int i = 0; i != aryOfPath.length; i++) {

			String sPath = aryOfPath[i].trim();

			sPath = sPath.replace(fromPath, Z);

			sPath = sPath.replace("\\", "/");
			String nameOfClassTxt = sPath.substring(sPath.lastIndexOf("/") + 1);

			sPath = link + sPath + "\" id=\"" + nameOfClassTxt
					+ "\" style=\"font-size:20px; color: #000000;\" target=\"_blank\" >" + sPath + "</a>";

			str.l(sPath);

		}

		return str.str;

	}
}