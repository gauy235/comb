package lgpl3.other.sample;

import java.util.Arrays;

import lgpl3.comb.Pnk;
import lgpl3.o.O;
import lgpl3.o.ary.Arr;
import lgpl3.o.time.T64;

/**
 * PByLoopBreadthFirst<br/>
 *
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex013_PByLoopBreadthFirst" >src</a>
 *
 * @see Ex009_FacByPostDfs
 */
public class Ex013_PByLoopBreadthFirst {

	public static void main(String[] sAry) throws Throwable {

		Arr arr = new Arr<String>(String.class);

		arr.trim();

		O.l("i=" + arr.i);

		arr.a("vvv");

		int n = 5;
		int k = 3;

		long t0 = O.t(), ar[] = Pnk.colByLoopBreadthNDepthFirst(n, k);

		O.l("costT=" + T64.difInF32Sec(t0));

		if (n <= 8) {

			Arrays.sort(ar);
			O.l(Pnk.strByAryOfRevB64W6BySAry(ar, O.ARY_A_Z));

		}

		O.l("len=" + O.eq(ar.length, Pnk.int64(n, k)));

	}
}
