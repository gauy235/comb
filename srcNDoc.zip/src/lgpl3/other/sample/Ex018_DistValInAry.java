package lgpl3.other.sample;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.shuffle.Shuffler;

/**
 * To distinct.<br/>
 *
 * @version 2023/10/11_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex018_DistValInAry" >src</a>
 *
 */
public class Ex018_DistValInAry {

	public static void main(String[] sAry) throws Throwable {

		long[] ary = { 20, 20, 40, 40, 40, 50, 50, 80 }, clonedAry = ary.clone();

		Shuffler.shuffle(ary);

		Arrays.sort(ary);

		O.l("easyDist=" + O.L + Arrays.toString(ary = Aryva.easyDist(ary)));

		Arrays.sort(clonedAry);

		if (!Arrays.equals(ary, Aryva.dist(clonedAry))) O.x();

	}
}