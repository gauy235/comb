package lgpl3.other.sample;

import lgpl3.o.O;

/**
 * To negate.<br/>
 * To negate.
 *
 * @version 2023/01/02_18:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex008_Neg" >src</a>
 *
 */
public class Ex008_Neg { // negate

	public static int neg(int n) { // 1 變 0, 0 變 1 再加 1

		return (~n + 0b1);
	}

	public static void main(String[] sAry) {

		int n = 13;

		O.l("neg n=" + O.eq(neg(n), -n));

	}
}
