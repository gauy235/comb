package lgpl3.other.sample;

/**
 * To get free space of disk.<br/>
 * <br/>
 * To get free space of disk.
 * 
 * @version 2019/05/10_13:30:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex133_Recycle" >Ex133_Recycle.java</a>
 * 
 */
public class Ex133_Recycle {

	public static void main(String[] sAry) throws Throwable {

		// rd /s /q C:\tmp
		// md C:\tmp

		// rd /s /q %systemdrive%\$Recycle.bin
		// rd /s /q D:\$Recycle.bin
		// rd /s /q O:\$Recycle.bin

	}

}