package lgpl3.other.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.powerSet.PowerSet;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.shareWXyz.Hxy;

/**
 * To match the target value with coins in the power set.<br/>
 * The power set.
 *
 * @version 2023/10/26_13:40:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex261_MatchVInPowerSet" >src</a>
 *
 */
public class Ex261_MatchVInPowerSet {

	public static void main(String[] sAry) throws Throwable {

		int[] base = { 50, 20, 20, 15, 10, 2, 1, 1, 1 };

		int targetV = 75;

		long[] ary = PowerSet.colAllMatchV(base, targetV);

		for (int idx = 0, size = ary.length; idx != size; idx++) {

			long b64W6 = ary[idx];
			O.l(B64W6.str(b64W6));
			O.l(Hxy.toStrByVCellPlusMinMinus1(ary[idx], 1));

		}

		O.l("B.cnt=" + B.cnt);
		B.cnt = 0;

	}
}