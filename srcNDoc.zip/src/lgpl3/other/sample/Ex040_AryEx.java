package lgpl3.other.sample;

import java.util.Arrays;

import lgpl3.o.O;
import lgpl3.o.ary.Ar32va;

/**
 * Exclude.<br/>
 *
 * @version 2023/11/11_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex040_AryEx" >src</a>
 *
 */
public class Ex040_AryEx {

	public static void main1(String sAry[]) throws Throwable {

		int[] ar = { 10, 20, 20, 30, 30, 30, 40, 50, 60 };
		int[] exAr = { 10, 30, 70 };

		O.l("ar=" + Arrays.toString(ar));

		Arrays.sort(exAr);

		O.l(Ar32va.ex(ar, exAr));
	}

	public static void main(String sAry[]) throws Throwable {

		int[] ar = { 10, 20, 60 };
		int key = -50;

		int iFound = Arrays.binarySearch(ar, 1, ar.length, key); // 新發現 srhFrom + -insertionPoint - 1

		O.l("iFound=" + iFound);
	}
}
