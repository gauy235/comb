package lgpl3.other.uI;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

/**
 * 收集一些 swing 元件.<br/>
 * Collects some swing components.
 *
 * @version 2023/11/04_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=MySwingva_A" >src</a>
 *
 * @see MySwingva_F
 */
public abstract class MySwingva_A { // private static final Class<?> THIS = MySwingva_A.class;

	public static final Color COLOR_BACKGROUND = new Color(0xB0DDF2); // 0xFFAACC, 0xC0FFCC

	public static final Color COLOR_TXT_BACKGROUND = new Color(0xC8DDF2);
	// 0xCCDEF3, MetalTabbedPaneUI.paintTabBackground

	public static final EmptyBorder EMPTY_BORDER = new EmptyBorder(0, 0, 0, 0);

	public static final Container TMP_CONTAINER = new Container();

	/**
	 * 裝元件的 list.<br/>
	 */
	public static final LiK32V<JTextField> LIST_OF_TXTFLD = new LiK32V<JTextField>();

	/**
	 * 裝元件的 list.<br/>
	 */
	public static final LiK32V<JButton> LIST_OF_BTN = new LiK32V<JButton>();

	/**
	 * 裝元件的 list.<br/>
	 */
	public static final LiK32V<JProgressBar> LIST_OF_PROGR_BAR = new LiK32V<JProgressBar>();

	/**
	 * 裝元件的 list.<br/>
	 */
	public static final LiK32V<JTextArea> LIST_OF_TXTAREA = new LiK32V<JTextArea>();

	/**
	 * 裝元件的 list.<br/>
	 */
	public static final LiK32V<JScrollPane> LIST_OF_SCRLPANE = new LiK32V<JScrollPane>();

	/**
	 * 裝元件的 list.<br/>
	 */
	public static final LiK32V<JPanel> LIST_OF_PANEL = new LiK32V<JPanel>();

	/////////////////////////////////////////////////////////////////////////////

	public static Font dynaFontDialog_1_17; // MP5

	public static Font dynaFontDialog_1_26; // rec

	public static Font dynaFontDialog_1_43; // big txtfld

	public static FontMetrics metricOfFontDialog_1_26;

	public static FontMetrics metricOfFontDialog_1_30;

	public static int hOfFontDialog_1_26;

	/////////////////////////////////////////////////////////////////////////////

	public static final String TXT_FOR_MP0 = "12,345,678";

	public static final String TXT_FOR_MP1 = "1";

	public static final String TXT_FOR_MP5 = "MinePrime";

	public static final String TXT_FOR_EP0 = "1";

	public static final String TXT_FOR_EP1 = "3,037,000,507";

	public static final String TXT_FOR_EP5 = "EtchPrime";

	public static final String TXT_FOR_DIY5 = "DIY "; // with 1 blank

	public static final String TXT_FOR_CONF5 = "Conf "; // with 1 blank

	public static final String TXT_FOR_REC5 = "Rec "; // with 1 blank

	public static Dimension getDimOfScreen() {

		try {
			return Toolkit.getDefaultToolkit().getScreenSize();

		} catch (Throwable throwable) {

			throwable.printStackTrace();
		}

		return new Dimension(1600, 900); // for Linux in VM
	}

	public static final Dimension DIM_OF_SCREEN = getDimOfScreen();

	public static final float W_SCREEN_F32 = (float) DIM_OF_SCREEN.getWidth();

	public static final float H_SCREEN_F32 = (float) DIM_OF_SCREEN.getHeight();

	public static final int W_SCREEN = (int) W_SCREEN_F32;

	public static final int H_SCREEN = (int) H_SCREEN_F32;

	public static int int32Width;

	public static int int32Height;

}
