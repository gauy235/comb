package lgpl3.other.uI;

import java.util.Arrays;

import lgpl3.o.B;
import lgpl3.o.ary.Arr;
import lgpl3.o.keyNV.K32V;

/**
 * A map for K32V.<br/>
 *
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=LiK32V" >src</a>
 *
 * @see K32V
 */
public class LiK32V<V> extends Arr<K32V<V>> {

	private static final Class<?> THIS = LiK32V.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	@SuppressWarnings("unchecked")
	public LiK32V() {

		super((Class<K32V<V>>) ((Class<V>) K32V.class)); // super((Class<K32V<V>>) K32V.class);
	}

	/**
	 * 加入.<br/>
	 */
	public LiK32V<V> a(int k, V v) {

		if (i == baseLen) extLen();

		ar[i++] = new K32V<V>(k, v);

		return this;
	}

	/**
	 * Gets value.<br/>
	 */
	public V get(int key) {

		int iFound = Arrays.binarySearch(ar, 0, i, new K32V<V>(key, null));

		return (iFound < 0 ? null : ar[iFound].v);
	}
}
