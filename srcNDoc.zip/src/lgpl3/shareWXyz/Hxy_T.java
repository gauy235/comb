package lgpl3.shareWXyz;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MSK;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.divIntoHeap.Dih;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;

/**
 * @version 2022/03/09_16:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hxy_T" >src</a>
 *
 * @see Hxy_U
 */
public abstract class Hxy_T extends Hxy_A {

	private static final Class<?> THIS = Hxy_T.class;

	/**
	 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
	 * To return the number of ways to share several identical items with every person.<br/>
	 */
	public static void colRecurWLim0ToMax(int n, int k, final int min, final long b64W6OfQtyPlus1Desc, long prefix, Seq seq) {

		// 先假設 min 是固定的, 因為 min 大部分從 1 或 0 開始

		B.cnt++;

		prefix <<= $6;

		if (k-- == 1) { // termination condition

			if (n <= ((int) b64W6OfQtyPlus1Desc & MSK)) seq.a(prefix | n); // limMax

			return; // O.l("add=" + B64W6.str24( prefix | n), THIS);
		}

		// note: read every max from leftmost
		final int curMax = ((int) (b64W6OfQtyPlus1Desc >>> ($6 * k))) & MSK;

		final int globalMax = ((int) b64W6OfQtyPlus1Desc) & MSK; // tail // O.l("globalMax=" + globalMax, THIS);

		// Hxy(10,3) with limMax[2,9,9]
		// diyMax may be 8 as 8 + 1 + 1 = 10
		// but diyMax can not > 2

		int diyMax = ((diyMax = n - min * k) > curMax) ? curMax : diyMax; // predict

		// Hxy(10,3) with limMax[2,8,9] // more and more larger
		// diyMin may be -6 as -6 + 8 + 8 = 10
		// but diyMin can not < 1

		int diyMin = ((diyMin = n - globalMax * k) < min) ? min : diyMin; // predict

		for (; diyMin <= diyMax; diyMin++) {

			colRecurWLim0ToMax((n - diyMin), k, min, b64W6OfQtyPlus1Desc, (prefix | diyMin), seq);
		}
	}

	/**
	 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
	 * To return the number of ways to share several identical items with every person.
	 *
	 * @see HxyVal #int64WLim0ToMax(int, int, long)
	 */
	// (5, 5, 3) => 000011_000101_000101 is good
	public static long[] colWLim0ToMax(int n, int k, long b64W6OfQtyPlus1Desc) {

		B.cnt = 0;

		n = n + k; // min==0

		Dih.checkArg(n, k, 1, n); // min=1, the b64W6OfQtyPlus1Desc will limit all

		Seq seq = new Seq();
		colRecurWLim0ToMax(n, k, 1, b64W6OfQtyPlus1Desc, 0b0L, seq);

		O.l(B64W6.str24(b64W6OfQtyPlus1Desc), THIS);

		O.l("B.n32=" + B.cnt, THIS);

		B.cnt = 0;

		return seq.trim().ar;
	}
}
