package lgpl3.shareWXyz;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.str.Strva;

/**
 * @version 2023/10/16_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hxy_Z" >src</a>
 *
 * @see Hxy
 */
public abstract class Hxy_Z extends Hxy_U { // private static final Class<?> THIS = Hxy_Z.class;

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder toStrByVCellPlusMinMinus1(long b64W6, int min) { // todo: rename strByVCellPlusMinMinus1

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		--min;

		do {
			ret.append((((int) b64W6) & B64W6.MASK32) + min);

			if (((int) (b64W6 >>>= B64W6.$6)) == 0b0) return ret;

			ret.append(O.C44);

		} while (B.T);
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder strByVCellPlusMinMinus1AftRev(long b64W6, int min) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		b64W6 = B64W6.revAmongVCell(b64W6);

		--min;
		do {
			ret.append((((int) b64W6) & B64W6.MASK32) + min);

			if (((int) (b64W6 >>>= B64W6.$6)) == 0b0) return ret;

			ret.append(O.C44);

		} while (B.T);
	}

	/**
	 * To StringBuilder as [1,1,2].<br/>
	 */
	public static StringBuilder toStrByVCellPlusMinMinus1ByAry(long[] aryOfB64W6, int min, CharSequence lineWr) {

		StringBuilder retStr = new StringBuilder(O.defLenForStr);

		for (int idx = 0, len = aryOfB64W6.length; idx != len;) {

			retStr.append(O.C91).append(toStrByVCellPlusMinMinus1(aryOfB64W6[idx], min)).append(O.C93);

			if (++idx != len)

				if (idx == Strva.maxRowInHtml) return retStr;

				else retStr.append(lineWr);

		}

		return retStr;

	}

	/**
	 * To StringBuilder by B64W6.<br/>
	 */
	public static StringBuilder rowStrAftRev(long b64W6, int min, String[] sAry) {

		// sample:
		// [1,1,4]
		// [2,1,3]
		// [4,1,1]

		// String s = "紅,黑,白";
		// from 紅,紅,紅
		// to 白,白,白
		// 人類習慣不用 revAmongVCell

		// 有嘗試過類似 B64W6.plusAllWV32 加入 -1 來 reduce 但效果不好

		b64W6 = B64W6.revAmongVCell(b64W6);

		StringBuilder ret = new StringBuilder(O.defLenForStr), tmpStr;

		for (int dif = (min - 1), vCell, idx = 0; B.T; idx++) {

			// O.l("vCell=" + ((((int) b64W6) & B64W6.MASK32) + dif), THIS);

			if ((vCell = (((int) b64W6) & B64W6.MASK32) + dif) != 0) {

				tmpStr = new StringBuilder(O.defLenForStr);

				do
					tmpStr.append(sAry[idx]).append(O.C44);

				while (--vCell != 0);

				ret.append(tmpStr);

			}

			if (((int) (b64W6 >>>= B64W6.$6)) == 0b0) // todo: need to improve

				return ret.deleteCharAt(ret.length() - 1); // just one time

		}
	}

	/**
	 * To StringBuilder by B64W6.<br/>
	 */
	public static StringBuilder strByAryOfB64W6BySAry(long[] aryOfB64W6, final int min, String[] sAry, CharSequence prefix,

			CharSequence lineWr) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		for (int idx = 0, len = aryOfB64W6.length; idx != len;) {

			ret.append(idx + 1).append(prefix).append(rowStrAftRev(aryOfB64W6[idx], min, sAry));

			if (++idx != len)

				if (idx == Strva.maxRowInHtml) return ret;

				else ret.append(lineWr);

		}

		return ret;

	}
}
