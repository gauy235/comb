package lgpl3.shareWXyz;

import java.util.Arrays;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.divIntoHeap.Dih;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.str.Strva;
import lgpl3.other.jsp.Jsp;

/**
 * @version 2023/11/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hxy" >src</a>
 *
 * @see Dih
 *
 * @see HxyVal
 *
 * @see Hxy
 */
public abstract class Hxy extends Hxy_Z { // private static final Class<?> THIS = Hxy.class;

	/**
	 * The base char array.<br/>
	 */
	public static char[] genCharAryOf$() {

		int len = 64;

		char[] ret = new char[len];

		do ret[--len] = O.C36; while (len != 0);

		return ret;
	}

	/**
	 * The base char array.<br/>
	 */
	public static final char[] CHAR_ARY_OF_$ = genCharAryOf$();

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder strOf$AftRev(long b64W6, int min) { // it is like: $,$,$$$

		StringBuilder ret = new StringBuilder(); // new StringBuilder(O.defLenForStr)

		b64W6 = B64W6.revAmongVCell(b64W6); // O.l("revAmongVCell=" + B64W6.str24(b64W6), THIS);

		--min;
		int vCell;
		do {
			vCell = ((int) b64W6 & B64W6.MASK32) + min;

			if ((b64W6 >>>= B64W6.$6) == 0b0L) { // terminate

				if (vCell == 0) ret.append(O.C95);

				else ret.append(Arrays.copyOfRange(CHAR_ARY_OF_$, 0, vCell));

				return ret;
			}

			if (vCell == 0) ret.append("_,");

			else ret.append(Arrays.copyOfRange(CHAR_ARY_OF_$, 0, vCell)).append(O.C44);

		} while (B.T);
	}

	/**
	 * To StringBuilder.<br/>
	 * 一整組哦:<br/>
	 * [_,_,$$$]<br/>
	 * [_,$,$$]<br/>
	 * [_,$$,$]<br/>
	 * [_,$$$,_]<br/>
	 */
	public static StringBuilder strOf$ByAryOfB64W6AftRev(long[] aryOfB64W6, int min, CharSequence lineWr) { // lineWr for JSP

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		for (int idx = 0, len = aryOfB64W6.length; idx != len;) {

			ret.append(O.C91).append(strOf$AftRev(aryOfB64W6[idx], min)).append(O.C93);

			if (++idx != len) ret.append(lineWr);

		}

		return ret;
	}

	/**
	 * To StringBuilder by B64W6.<br/>
	 */
	public static StringBuilder rowHtmlWHead(long b64W6, int min, StringBuilder htmlHead) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		b64W6 = B64W6.revAmongVCell(b64W6);

		ret.append(htmlHead).append(O.C_A_L);
		ret.append("<tr><td>");

		min--;
		do {
			ret.append((((int) b64W6) & B64W6.MASK32) + min);

			if ((b64W6 >>>= B64W6.$6) == 0b0L) return ret.append("</td></tr>");

			else ret.append(Strva.STR_HTML_MIDDLE_TD);

		} while (B.T);
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public static StringBuilder toHtmlStrToHWHeadSByAryOfB64W6(long[] aryOfB64W6, int min, String[] sAryForHead,

			CharSequence sHtmlClass) {

		StringBuilder retStr = new StringBuilder(O.defLenForStr);

		final StringBuilder htmlStart1 = new StringBuilder("<table class=\"").append(sHtmlClass).append("\" ><thead><tr><td>");
		final StringBuilder htmlEnd1 = new StringBuilder("</td></tr></thead>").append(O.C_A_L);

		final StringBuilder htmlHead = new StringBuilder("<tr><td>");

		int idx = 0;
		do {
			htmlHead.append(sAryForHead[idx]);

			if (++idx != sAryForHead.length) htmlHead.append(Strva.STR_HTML_MIDDLE_TD);

			else {
				htmlHead.append("</td></tr>");

				break;
			}

		} while (B.T);

		for (idx = 0; idx != aryOfB64W6.length;) {

			retStr.append(htmlStart1).append(idx + 1).append(htmlEnd1);
			retStr.append(rowHtmlWHead(aryOfB64W6[idx], min, htmlHead));
			retStr.append("</table>");

			if (++idx != aryOfB64W6.length)

				if (idx == Strva.maxRowInHtml) return retStr;

				else retStr.append(Jsp.L);
		}

		return retStr;
	}
}
