package lgpl3.shareWXyz;

import lgpl3.comb.Cnk;

/**
 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
 * Returns the number of ways to share several identical items with every person.
 *
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hnr_A" >src</a>
 *
 * @see Hnr_U
 */
public abstract class Hnr_A { // private static final Class<?> THIS = Hnr_A.class;

	/**
	 * H(n,r) = C(n-1 + r, n-1) = C(n+r-1, r) <br/>
	 * H(n,r) min1 = H(n, r-n) = C(n-1 + r-n, r-n) = C(r-1, r-n) = C(r-1, n-1) // r gte n
	 */
	public static long int64(int n, int r) {

		return Cnk.int64(n + r - 1, r);
	}

	/**
	 * H(n,r) = C(n-1 + r, n-1) = C(n+r-1, r) <br/>
	 * H(n,r) min1 = H(n, r-n) = C(n-1 + r-n, r-n) = C(r-1, r-n) = C(r-1, n-1) // r gte n
	 */
	public static long hWMin1(int n, int r) {

		return Cnk.int64(r - 1, n - 1);
	}
}
