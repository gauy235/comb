package lgpl3.shareWXyz;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MSK;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;

/**
 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
 * Returns the number of ways to share several identical items with every person.
 *
 * @version 2023/11/28_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hnr" >src</a>
 *
 * @see Hxy
 */
public abstract class Hnr extends Hnr_U { // private static final Class<?> THIS = Hnr.class;

	/**
	 * Onto by room major.<br/>
	 */
	public static void ontoRoomMaj(int n, long prefix, final int r, Seq retSeq, int lv) { // 每個房間不空

		if (lv++ == r) {

			retSeq.a(prefix); // todo: 可再去檢查 min max

			return;
		}

		prefix <<= $6;

		for (int v = 1; v <= n; v++)

			if (B64W6.cntOfDistCat(prefix | v) + (r - lv) >= n) ontoRoomMaj(n, (prefix | v), r, retSeq, lv);

	}

	/**
	 * Onto<br/>
	 */
	public static long[] ontoRoomMaj(int n, int r) { // todo: 想 若 n == r 則為 Pnk 排列

		Seq retSeq = new Seq(); // O.l("n=" +n);

		ontoRoomMaj(n, 0b0L, r, retSeq, 0);

		return retSeq.trim().ar;
	}

	/**
	 * OntoWMin0<br/>
	 */
	public static void ontoWMin0RoomMaj(int n, long prefix, final int r, Seq retSeq, int lv) {

		if (lv++ == r) {

			retSeq.a(prefix);

			return;
		}

		prefix <<= $6;

		for (int v = 1; v <= n; v++) ontoWMin0RoomMaj(n, (prefix | v), r, retSeq, lv); // 房間名 vCell min=1 開始
	}

	/**
	 * OntoWMin0<br/>
	 */
	public static long[] ontoWMin0RoomMaj(int n, int r) {

		Seq retSeq = new Seq();

		ontoWMin0RoomMaj(n, 0b0L, r, retSeq, 0);

		return retSeq.trim().ar;
	}

	/**
	 * Cnk<br/>
	 */
	public static void cByB64W6GtTail(int n, int k, long prefix, Seq retSeq, int lv) {

		if (lv++ == k) {

			retSeq.a(prefix); // O.l("len=" + retSeq.i);

			return;
		}

		int newTail = ((int) prefix & MSK) + 1; // O.l("newTail=" + newTail);

		prefix <<= $6; // long tmp = prefix | newTail;

		for (int newN = n + (k - lv); newTail <= newN; newTail++) cByB64W6GtTail(n, k, (prefix | newTail), retSeq, lv);
	}

	/**
	 * Cnk<br/>
	 */
	public static void cByRoomYN(int n, int k, long prefix, int cntY, Seq retSeq, int lv) { // see transpose strMatrixChainMul

		if (lv++ == n) {

			retSeq.a(prefix);

			return;
		}

		prefix <<= $6; // O.lv(lv, "prefix=" + B64W6.str24(prefix));

		if (cntY < k) cByRoomYN(n, k, (prefix | $YES), (cntY + 1), retSeq, lv);

		if (cntY + (n - lv) >= k) cByRoomYN(n, k, (prefix | $NO), cntY, retSeq, lv);

	}

	/**
	 * Transpose.
	 */
	public static long[] transposeArOfB64W6(long[] arOfB64W6) { // 轉置 破壞性改變原陣列

		long oldB64W6, tmpB64W6; // oldB64W6 = B64W6.revAmongVCell(arOfB64W6[idx]) // 轉置的本義 故不用 revAmongVCell

		int idx = 0, myOrder;
		do {
			oldB64W6 = arOfB64W6[idx]; // O.l("oldB64=" + B64W6.str24(oldB64), THIS);

			myOrder = 1;
			tmpB64W6 = 0b0L;
			do {
				if (((int) oldB64W6 & MSK) == $YES) tmpB64W6 = (tmpB64W6 << $6) | myOrder;

				if ((oldB64W6 >>>= $6) == 0b0L) break; // 有 2 層迴圈

				myOrder++;

			} while (B.T);

			arOfB64W6[idx] = tmpB64W6;

		} while (++idx != arOfB64W6.length);

		return arOfB64W6;
	}

	/**
	 * Dyck word.<br/>
	 */
	public static StringBuilder strDyckAftRev(long b64W6) { // 轉置

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		b64W6 = B64W6.revAmongVCell(b64W6); // O.l("bef b64W6=" + B64W6.str24(b64W6));

		int vCell;
		do {
			if ((vCell = (int) b64W6 & MSK) == $YES) ret.append(cYes); // char Y

			else if (vCell == $NO) ret.append(cNo); // char N

			if ((b64W6 >>>= $6) == 0b0L) return ret;

			ret.append(O.C44);

		} while (B.T);
	}
}
