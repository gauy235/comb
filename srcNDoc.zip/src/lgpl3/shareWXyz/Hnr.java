package lgpl3.shareWXyz;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.ary.Seq;

/**
 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
 * Returns the number of ways to share several identical items with every person.
 *
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hnr" >src</a>
 *
 * @see Hxy
 */
public abstract class Hnr extends Hnr_U { // private static final Class<?> THIS = Hnr.class;

	/**
	 * Onto<br/>
	 */
	public static void ontoByH(int maxSymbol, long prefix, int kAsLv, Seq retSeq) {

		prefix <<= $6;

		if (--kAsLv == 0) {

			long tmp;

			for (int v = 1; v <= maxSymbol; v++) {

				tmp = B64W6.easySortAftTotalVCell(tmp = prefix | v);

				if (B64W6.totalVCell(B64W6.countAllOccurNRev(tmp)) == maxSymbol) retSeq.a(tmp);

			}

			return;
		}

		for (int v = 1; v <= maxSymbol; v++) ontoByH(maxSymbol, (prefix | v), kAsLv, retSeq);
	}

	/**
	 * Onto<br/>
	 */
	public static long[] ontoByH(int countOfKind, int totalN) {

		Seq retSeq = new Seq(); // O.l("countOfKind=" + countOfKind);

		ontoByH(countOfKind, 0b0L, totalN, retSeq);

		return retSeq.trim().ar;
	}

	/**
	 * OntoWMin0<br/>
	 */
	public static void ontoWMin0ByH(int maxSymbol, long prefix, int kAsLv, Seq retSeq) {

		prefix <<= $6;

		int v = 1;

		if (--kAsLv == 0) {

			for (; v <= maxSymbol; v++) retSeq.a(prefix | v);

			return;
		}

		for (; v <= maxSymbol; v++) ontoWMin0ByH(maxSymbol, (prefix | v), kAsLv, retSeq);
	}

	/**
	 * OntoWMin0<br/>
	 */
	public static long[] ontoWMin0ByH(int countOfKind, int totalN) {

		Seq retSeq = new Seq(); // O.l("countOfKind=" + countOfKind);

		ontoWMin0ByH(countOfKind, 0b0L, totalN, retSeq);

		return retSeq.trim().ar;
	}
}
