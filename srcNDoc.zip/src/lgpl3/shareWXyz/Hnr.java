package lgpl3.shareWXyz;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MASK32;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.ary.Seq;

/**
 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
 * Returns the number of ways to share several identical items with every person.
 *
 * @version 2023/11/27_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hnr" >src</a>
 *
 * @see Hxy
 */
public abstract class Hnr extends Hnr_U { // private static final Class<?> THIS = Hnr.class;

	/**
	 * Cnk<br/>
	 */
	public static void cByGtTail(int n, int k, long prefix, Seq retSeq, int lv) {

		int newTail = ((int) prefix & MASK32) + 1; // O.l("min=" + min);

		if (lv++ == k) {

			retSeq.a(prefix); // O.l("len=" + retSeq.i);

			return;

		}

		prefix <<= $6;

		for (int newN = n + (k - lv); newTail <= newN; newTail++) cByGtTail(n, k, (prefix | newTail), retSeq, lv);

		// long tmp = prefix | newTail;

	}

	/**
	 * Cnk<br/>
	 */
	public static long[] cByGtTail(int n, int k) {

		Seq retSeq = new Seq();

		cByGtTail(n, k, 0b0L, retSeq, 0);

		return retSeq.trim().ar;
	}

	/**
	 * Onto<br/>
	 */
	public static void ontoRoomMaj(int n, long prefix, final int r, Seq retSeq, int lv) {

		if (lv++ == r) {

			retSeq.a(prefix); // todo: 可再去檢查 min max

			return;
		}

		prefix <<= $6;

		for (int v = 1; v <= n; v++) if (B64W6.distrNCnt(prefix | v) + (r - lv) >= n)

			ontoRoomMaj(n, (prefix | v), r, retSeq, lv);

	}

	/**
	 * Onto<br/>
	 */
	public static long[] ontoRoomMaj(int n, int r) {

		Seq retSeq = new Seq(); // O.l("n=" +n);

		ontoRoomMaj(n, 0b0L, r, retSeq, 0);

		return retSeq.trim().ar;
	}

	/**
	 * OntoWMin0<br/>
	 */
	public static void ontoWMin0RoomMaj(int n, long prefix, final int r, Seq retSeq, int lv) {

		if (lv++ == r) {

			retSeq.a(prefix);

			return;
		}

		prefix <<= $6;

		// 雖然 WMin0 但是為了抓房間名 所以 vCell 內放 min=1 開始

		for (int v = 1; v <= n; v++) ontoWMin0RoomMaj(n, (prefix | v), r, retSeq, lv);
	}

	/**
	 * OntoWMin0<br/>
	 */
	public static long[] ontoWMin0RoomMaj(int n, int r) {

		Seq retSeq = new Seq();

		ontoWMin0RoomMaj(n, 0b0L, r, retSeq, 0);

		return retSeq.trim().ar;
	}
}
