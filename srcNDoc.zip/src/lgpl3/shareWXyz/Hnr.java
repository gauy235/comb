package lgpl3.shareWXyz;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MASK32;

import lgpl3.o.ary.Seq;

/**
 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
 * Returns the number of ways to share several identical items with every person.
 *
 * @version 2023/11/27_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hnr" >src</a>
 *
 * @see Hxy
 */
public abstract class Hnr extends Hnr_U { // private static final Class<?> THIS = Hnr.class;

	/**
	 * Sorts then counts.<br/>
	 * The int[]{1, 3, 3} returns: 2
	 */
	public static int countingSortNCnt(long unsortedB64W6) { // unsortedB64W6 must not be 0b0L

		long b64W6 = 0b0L; // O.l("unsortedB64W6=" + B64W6.str24(unsortedB64W6));

		int cnt = 0;

		do b64W6 |= 0b1L << ($6 * ((int) unsortedB64W6 & MASK32)); while ((unsortedB64W6 >>>= $6) != 0b0L);

		for (; ((int) b64W6 & MASK32) == 0b0; b64W6 >>>= $6); // trim

		// O.l("b64W6=" + B64W6.str24(b64W6));

		do if (((int) b64W6 & MASK32) != 0b0) cnt++; while ((b64W6 >>>= $6) != 0b0L); // O.l( "cnt=" + cnt);

		return cnt;
	}

	/**
	 * Onto<br/>
	 */
	public static void ontoByH(int n, long prefix, final int r, Seq retSeq, int lv) {

		prefix <<= $6;

		if (lv++ == r) {

			retSeq.a(prefix); // todo: 可再去檢查 min max

			return;
		}

		for (int v = 1; v <= n; v++) if (countingSortNCnt(prefix | v) + (r - lv) >= n)

			ontoByH(n, (prefix | v), r, retSeq, lv);

	}

	/**
	 * Onto<br/>
	 */
	public static long[] ontoByH(int n, int r) {

		Seq retSeq = new Seq(); // O.l("n=" +n);

		ontoByH(n, 0b0L, r, retSeq, 0);

		return retSeq.trim().ar;
	}

	/**
	 * OntoWMin0<br/>
	 */
	public static void ontoWMin0ByH(int n, long prefix, final int r, Seq retSeq, int lv) {

		prefix <<= $6;

		if (lv++ == r) {

			retSeq.a(prefix);

			return;
		}

		for (int v = 1; v <= n; v++) ontoWMin0ByH(n, (prefix | v), r, retSeq, lv);
	}

	/**
	 * OntoWMin0<br/>
	 */
	public static long[] ontoWMin0ByH(int n, int r) {

		Seq retSeq = new Seq();

		ontoWMin0ByH(n, 0b0L, r, retSeq, 0);

		return retSeq.trim().ar;
	}
}
