package lgpl3.shareWXyz;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MASK32;

import lgpl3.divIntoHeap.Dih;
import lgpl3.o.ary.Seq;

/**
 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
 * To return the number of ways to share several identical items with every person.
 *
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hnr" >src</a>
 *
 * @see Hxy
 */
public abstract class Hnr extends Hnr_U { // private static final Class<?> THIS = Hnr.class;

	public static void ontoByH(final int maxSymbol, long prefix, int rmdN, Seq retSeq) {

		int tailV = (int) prefix & MASK32;

		prefix <<= $6;

		if (--rmdN == 0) {

			do retSeq.a(prefix | tailV); while (++tailV <= maxSymbol);

			return;
		}

		do easyRecur(maxSymbol, (prefix | tailV), rmdN, retSeq); while (++tailV <= maxSymbol);
	}

	public static long[] ontoByH(int countOfKind, int totalN) { // 每 1 種都有無限多個

		Seq retSeq = new Seq();

		Dih.checkArg(totalN + countOfKind, countOfKind, 1, totalN + countOfKind);

		// 符號 1 開頭, 一直取尾巴走下去 => 1,1,1 or 1,1,2 ...
		// 永遠不會出現符號 2 開頭 => 2,2,2

		for (int initSymbol = 1, rmdN = totalN - 1; initSymbol <= countOfKind; initSymbol++)

			ontoByH(countOfKind, initSymbol, rmdN, retSeq); // O.l("initSymbol=" + initSymbol, THIS);

		return retSeq.trim().ar;
	}
}
