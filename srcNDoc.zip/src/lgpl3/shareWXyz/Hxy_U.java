package lgpl3.shareWXyz;

/**
 * @version 2023/10/23_18:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hxy_U" >src</a>
 *
 * @see Hxy_Z
 */
public abstract class Hxy_U extends Hxy_T { // private static final Class<?> THIS = Hxy_U.class;
}
