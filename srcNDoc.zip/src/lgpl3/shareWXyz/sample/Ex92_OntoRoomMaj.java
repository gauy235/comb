package lgpl3.shareWXyz.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.onto.Onto;
import lgpl3.o.O;
import lgpl3.o.ary.Seq;
import lgpl3.shareWXyz.Hnr;
import lgpl3.shareWXyz.Hxy;

/**
 * OntoRoomMaj<br/>
 *
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex92_OntoRoomMaj" >src</a>
 *
 */
public class Ex92_OntoRoomMaj {

	public static void main(String[] sAry) throws Throwable {

		String[] allRoomName = { "天", "地", "海" }; // 房間

		int n = allRoomName.length;
		int r = 5;
		int min = 1; // strByVCellPlusMinMinus1AftRev

		Seq retSeq = new Seq(); // O.l("n=" +n);

		Hnr.ontoRoomMaj(n, 0b0L, r, retSeq, 0);

		long[] arOfB64W6 = retSeq.trim().ar;

		for (int idx = 0; idx != arOfB64W6.length; idx++) {

			O.l("[" + Hxy.strByVCellPlusMinMinus1AftRev(arOfB64W6[idx], min) + "]="

					+ B64W6.strByVCellMinus1AftRevBySAry(arOfB64W6[idx], allRoomName) + "=" + B64W6.str24(arOfB64W6[idx]));

		}

		O.l("len=" + O.eq(arOfB64W6.length, Onto.int64ByToInEx(r, n)));

	}
}
