package lgpl3.shareWXyz.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.keyNV.KArV32;
import lgpl3.shareWXyz.Hnr;

/**
 * PByRoomMaj<br/>
 *
 * @version 2024/02/13_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex97_PByRoomMaj" >src</a>
 *
 */
public class Ex97_PByRoomMaj {

	public static void main(String[] sAry) throws Throwable {

		String[] allRoomName = { "風", "林", "火", "山" }; // 房間名

		int n = allRoomName.length;
		int k = 3;

		KArV32 kV = new KArV32((int) Pnk.int64(n, k));

		Hnr.pByRoomMaj(n, k, 0b0L, kV);

		for (int idx = 0; idx != kV.k.length; idx++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(kV.k[idx], allRoomName) + "=" + B64W6.str24(kV.k[idx]));

		O.l("len=" + O.eq(kV.k.length, Pnk.int64(n, k)));

	}
}
