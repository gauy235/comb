package lgpl3.shareWXyz.sample;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.comb.onto.Onto;
import lgpl3.o.O;
import lgpl3.shareWXyz.Hnr;
import lgpl3.shareWXyz.Hxy;

/**
 * OntoWMin0RoomMaj<br/>
 *
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex91_OntoWMin0RoomMaj" >src</a>
 *
 */
public class Ex91_OntoWMin0RoomMaj {

	public static void main1(String[] sAry) throws Throwable {

		long b64W6 = B64W6.genB64W6ByAr32(5, 5, 10, 11);

		O.l("b64W6=" + B64W6.str24(b64W6));

		b64W6 = B64W6.cntOfDistCat(b64W6);

		O.l("b64W6=" + B64W6.str24(b64W6));

	}

	public static void main2(String[] sAry) throws Throwable {

		int[] ar32 = new int[] { 10, 10, 50, 20, 10, 22 }; // check genB64W6ByAr32(1, 1, 2, 3, 4)

		long b64W6 = B64W6.genB64W6ByAr32(1, 1, 2, 3, 4);
		// long b64W6 = 0b000011_000011_000011_000011L;

		b64W6 = B64W6.easySortAftTotalVCell(b64W6);

		long listCntOfOccurNRev = B64W6.listCntOfOccurNRev(b64W6);

		O.l("listCntOfOccurNRev=" + O.L + B64W6.str(b64W6));

		O.l("totalVCell=" + B64W6.totalVCell(listCntOfOccurNRev));
	}

	public static void main(String[] sAry) throws Throwable {

		String[] allRoomName = { "天", "地", "海" }; // 房間

		int n = allRoomName.length;
		int r = n + 2;
		int min = 1; // 雖然 WMin0 但是為了抓房間名 所以 vCell 內放 min=1 開始

		long[] arOfB64W6;

		int rnd = O.rnd100() - 100;

		if (rnd < 80) arOfB64W6 = Hnr.ontoRoomMaj(n, r);

		else arOfB64W6 = Hnr.ontoWMin0RoomMaj(n, r);

		for (int idx = 0; idx != arOfB64W6.length; idx++) {

			O.l("[" + Hxy.strByVCellPlusMinMinus1AftRev(arOfB64W6[idx], min) + "]="

					+ B64W6.strByVCellMinus1AftRevBySAry(arOfB64W6[idx], allRoomName) + "=" + B64W6.str24(arOfB64W6[idx]));

		}

		if (rnd < 80) O.l("len=" + O.eq(arOfB64W6.length, Onto.int64ByToInEx(r, n)));

		else O.l("len=" + O.eq(arOfB64W6.length, O.pow(n, r)));
	}
}
