package lgpl3.shareWXyz.sample;

import lgpl3.comb.Cnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.shareWXyz.Hnr;

/**
 * Ex93_CnkByGtTail<br/>
 *
 * @version 2023/11/28_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex93_CnkByGtTail" >src</a>
 *
 */
public class Ex93_CnkByGtTail {

	public static void main(String[] sAry) throws Throwable {

		String[] baseSAry = { "甲", "乙", "丙" };

		int n = baseSAry.length;
		int k = 2;

		long[] arOfB64W6 = Hnr.cByGtTail(n, k);

		O.l("ar[0]=" + B64W6.str24(arOfB64W6[0]));

		for (int idx = 0; idx != arOfB64W6.length; idx++)

			O.l(B64W6.strByVCellMinus1AftRevBySAry(arOfB64W6[idx], baseSAry) + "=" + B64W6.str24(arOfB64W6[idx]));

		O.l("len=" + O.eq(arOfB64W6.length, Cnk.int64(n, k)));
	}
}
