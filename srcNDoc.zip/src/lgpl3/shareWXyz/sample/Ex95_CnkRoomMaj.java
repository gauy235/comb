package lgpl3.shareWXyz.sample;

import lgpl3.comb.Cnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.ary.Seq;
import lgpl3.shareWXyz.Hnr;

/**
 * Ex95_CnkRoomMaj<br/>
 *
 * @version 2023/11/28_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex95_CnkRoomMaj" >src</a>
 *
 */
public class Ex95_CnkRoomMaj {

	public static void main(String[] sAry) throws Throwable {

		int n = 4;
		int k = 3;

		Seq retSeq = new Seq();

		Hnr.cRoomMaj(n, k, 0b0L, 0, retSeq, 0);

		long[] arOfB64W6 = retSeq.trim().ar;

		Aryva.chkDup(arOfB64W6);

		for (int idx = 0; idx != arOfB64W6.length; idx++)

			O.l(Hnr.strDyckAftRev(arOfB64W6[idx]) + "=" + B64W6.str24(arOfB64W6[idx]));

		O.l("len=" + O.eq(arOfB64W6.length, Cnk.int64(n, k)));
	}
}
