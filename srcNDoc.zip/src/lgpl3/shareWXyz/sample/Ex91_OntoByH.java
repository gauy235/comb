package lgpl3.shareWXyz.sample;

import lgpl3.comb.Pnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.shareWXyz.Hnr;
import lgpl3.shareWXyz.Hxy;

/**
 * Onto<br/>
 *
 * @version 2023/11/25_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex91_OntoByH" >src</a>
 *
 */
public class Ex91_OntoByH {

	public static void main(String[] sAry) throws Throwable {

		sAry = new String[] { "金", "木", "水" }; // 房間

		int countOfKind = sAry.length;
		int totalN = 5;
		int min = 1;

		long[] ary = Hnr.ontoByH(countOfKind, totalN);

		O.l("ar[0]=" + B64W6.str24(ary[0]));

		O.l(Pnk.strByAryOfRevB64W6BySAry(ary, sAry));

		O.l(Hxy.strByAryOfB64W6AftRev(ary, min, O.L));

		O.l("len=" + ary.length);

	}
}
