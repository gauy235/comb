package lgpl3.shareWXyz.sample;

import lgpl3.comb.Cnk;
import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;
import lgpl3.o.ary.Aryva;
import lgpl3.o.keyNV.KArV32;
import lgpl3.shareWXyz.Hnr;

/**
 * Ex95_CByRoomYN<br/>
 *
 * @version 2024/02/08_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ex95_CByRoomYN" >src</a>
 *
 */
public class Ex95_CByRoomYN {

	public static void main(String[] sAry) throws Throwable {

		Hnr.cNo = '_';

		int n = 7;
		int k = 4;

		KArV32 retKV = new KArV32((int) Cnk.int64(n, k));

		Hnr.cByRoomYN(n, k, 0b0L, 0, retKV, 0);

		long[] arOfB64W6 = retKV.k;

		Aryva.chkDup(arOfB64W6);

		for (int idx = 0; idx != arOfB64W6.length; idx++)

			O.l(B64W6.str24(arOfB64W6[idx]) + "=" + Hnr.strDyckAftRev(arOfB64W6[idx]));

		O.l("len=" + O.eq(arOfB64W6.length, Cnk.int64(n, k)));
	}
}
