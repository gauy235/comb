package lgpl3.shareWXyz;

import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.$6;
import static lgpl3.comb.b64WVCell.B64W6BitPerCellFromR.MSK;

import lgpl3.divIntoHeap.Dih;
import lgpl3.o.B;
import lgpl3.o.ary.Seq;
import lgpl3.o.keyNV.KArV32;

/**
 * Hxy(myN, myK) eq Hnr(myK, myN)
 *
 * @version 2023/10/23_18:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Hxy_A" >src</a>
 *
 * @see Hxy_T
 */
public abstract class Hxy_A extends ShareWXyz { // private static final Class<?> THIS = Hxy_A.class;

	/**
	 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
	 * To return the number of ways to share several identical items with every person.<br/>
	 *
	 * @see Dih #colRecur(int, int, int, int, long, Seq)
	 */
	public static void colRecur(int n, int k, int min, int max, long prefix, KArV32 kV) {

		B.cnt++;

		prefix <<= $6;

		if (k-- == 1) {

			kV.k[kV.v++] = prefix | n; // O.l(Hxy.strByVCellPlusMinMinus1(prefix, min));

			return;
		}

		// int newN
		// int newK as k - 1
		// int newMin after regularized min always 1
		// int newMax

		int newMin = ((newMin = n - max * k) < min) ? min : newMin; // predict

		int newMax = ((newMax = n - k * min) > max) ? max : newMax; // predict

		// min (總是 from 原始 min) max for 這一層
		// newMin newMax for 下一層

		// 10 share with 3
		// 3,1,6 ok
		// 3,2,5 ok
		// 3,3,4 ok
		// 3,4,3 ok
		// 3,5,2 ok

		int upBound = newMax; // 下界 1, 上界最好為 n

		for (int giveV = newMin, rmdN; giveV <= upBound;) {

			rmdN = n - giveV;

			// O.l("up giveV=" + giveV + " rmdN=" + rmdN + ", k=" + k + ", min=" + newMin + ", max=" + newMax, THIS);

			if ((newMax * k) >= rmdN && (newMin * k) <= rmdN) {

				// O.l("add=", THIS);

				colRecur(rmdN, k, newMin, newMax, (prefix | giveV), kV);

			}

			giveV++;

			// 以下用 [n,k,min,max]=[3,2,1,3] err
			// rmdN = n - giveV;
			// newMax = ((newMax = rmdN - newMin * k) > max) ? max : newMax; // newMax 每次都不一樣 newMin 穩定不變

			// O.l("down giveV=" + giveV + " rmdN=" + rmdN + ", k=" + k + ", min=" + newMin + ", max=" + newMax, THIS);

		}
	}

	/**
	 * 即 n 個相同物品分成給 k 人, 每人最少 1 個.<br/>
	 * To return the number of ways to share several identical items with every person.
	 *
	 * @see Dih#col(int, int, int, int)
	 */
	public static long[] col(int n, int k, int min, int max) {

		// regularize
		// check arg
		// special case

		int reguB32W6 = Dih.reguByMin1(n, k, min, max);

		n = reguB32W6 & MSK;
		max = (reguB32W6 >>> $6) & MSK;

		// Dih.checkArg(n, k, 1, max);

		// O.x("aft n=" + n + ", k=" + k + ", min=" + 1 + ", max=" + max + THIS);

		KArV32 retKV = new KArV32((int) HxyVal.int64(n, k, 1, max));

		colRecur(n, k, 1, max, 0b0L, retKV);

		return retKV.k;
	}
}
