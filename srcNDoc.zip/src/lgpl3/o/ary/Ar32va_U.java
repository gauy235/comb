package lgpl3.o.ary;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * @version 2023/11/04_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ar32va_U" >src</a>
 *
 * @see Ar32va
 */
public abstract class Ar32va_U extends Ar32va_A { // private static final Class<?> THIS = Ar32va_U.class;

	/**
	 * To check if there is duplicated.<br/>
	 */
	public static int[] checkDup(int[] sortedAr) {

		if (sortedAr.length == 0) return sortedAr;

		int idx = (sortedAr.length - 1), tail = sortedAr[idx], head;

		for (; idx > 0; tail = head) if (tail == (head = sortedAr[--idx])) O.x("idx=" + idx);

		return sortedAr;
	}

	/**
	 * To check if there is duplicated.<br/>
	 */
	public static int[] sortNCheckDup(int[] ar) {

		if (ar.length == 0) return ar;

		Arrays.sort(ar); // 破壞性寫入 // java.util.DualPivotQuicksort.sort(ar, 0, ar.length - 1, null, 0, 0);

		int idx = (ar.length - 1), tail = ar[idx], head;

		for (; idx > 0; tail = head) if (tail == (head = ar[--idx])) O.x("idx=" + idx);

		return ar;
	}

	/**
	 * To check if there is duplicated.<br/>
	 */
	public static int[] sortDescNCheckDup(int[] ar) {

		if (ar.length == 0) return ar;

		Arrays.sort(ar); // 破壞性寫入 // java.util.DualPivotQuicksort.sort(ar, 0, ar.length - 1, null, 0, 0);

		rev(ar);

		int idx = (ar.length - 1), tail = ar[idx], head;

		for (; idx > 0; tail = head) if (tail == (head = ar[--idx])) O.x("idx=" + idx);

		return ar;
	}

	/**
	 * Distinct.<br/>
	 *
	 * @see Aryva #dist(long[])
	 */
	public static int[] dist(int[] sortedAr) {

		// max as king
		int max = sortedAr[0], idx = 1, cnt = 1 /* 第一個已自動加入 */, tmpV;

		for (; idx != sortedAr.length; idx++) // O.l("tmpV=" + sortedAr[idx] + ", idx=" + idx + ", max=" + max);

			if ((tmpV = sortedAr[idx]) != max) sortedAr[cnt++] = max = tmpV; // 連用 2 個等號

		if (cnt != sortedAr.length) System.arraycopy(sortedAr, 0, (sortedAr = new int[cnt]), 0, cnt);

		return sortedAr;
	}

	/**
	 * Distinct.<br/>
	 *
	 * @see Aryva #easyDist(long[])
	 */
	public static int[] easyDist(int[] sortedAr) { // 2 份記憶體空間

		int idx, cache, ret[] = new int[sortedAr.length], iRet;

		ret[0] = cache = sortedAr[0]; // 連用 2 個等號

		for (iRet = idx = 1; idx != sortedAr.length; idx++) // 連用 2 個等號

			if (sortedAr[idx] != cache) ret[iRet++] = cache = sortedAr[idx]; // 連用 2 個等號

		// O.l("cache=" + sortedAry[idx] + ", iRet=" + iRet );

		if (iRet != sortedAr.length) System.arraycopy(ret, 0, (ret = new int[iRet]), 0, iRet);

		return ret;
	}

	/**
	 * Merge.
	 *
	 * @see Aryva #merge(long[])
	 */
	public static int[] merge(int[] big, int[] small) {

		int[] ret = new int[big.length + small.length]; // todo: 重複用 big 即可

		System.arraycopy(big, 0, ret, 0, big.length);
		System.arraycopy(small, 0, ret, big.length, small.length);

		return ret;
	}

	/**
	 * Exclude.
	 */
	public static int[] ex(int[] sortedAr, int[] exAr) {

		int idx = 0, len = sortedAr.length, key;

		int searchFrom = 0, searchTo = exAr.length, retIdx, newLen = 0;

		for (; idx != len; idx++) {

			O.l("ex=" + Arrays.toString(Arrays.copyOfRange(exAr, searchFrom, searchTo)));

			retIdx = Arrays.binarySearch(exAr, searchFrom, searchTo, key = sortedAr[idx]);

			O.l("retIdx=" + retIdx);

			O.l("(searchFrom + retIdx)=" + (searchFrom + retIdx));

			// -insertionPoint - 1
			// if (key != oldKey) // changed

			if ((searchFrom + retIdx) < -1) searchFrom++; // O.l("searchFrom++ ");

			if (retIdx < 0)

				if (idx == newLen) ++newLen;

				else sortedAr[newLen++] = key; // 使用原陣列當容器

		}

		if (newLen != len) System.arraycopy(sortedAr, 0, (sortedAr = new int[newLen]), 0, newLen);

		return sortedAr;
	}

	/**
	 * Convert.
	 */
	public static int[] toAr(long[] ary) {

		int len = ary.length, ret[] = new int[len];

		while (len-- != 0) ret[len] = (int) ary[len];

		return ret;
	}
}