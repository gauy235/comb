package lgpl3.o.ary;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * 陣列小幫手娃.<br/>
 * The aid to array.
 *
 * @version 2023/11/04_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Aryva" >src</a>
 *
 * @see Ar32va
 */
public abstract class Aryva extends Aryva_A { // private static final Class<?> THIS = Aryva.class;

	/**
	 * To distinct.<br/>
	 *
	 * @see Ar32va #dist(int[])
	 */
	public static long[] dist(long[] sortedAry) {

		long max = sortedAry[0], tmpV;

		int idx = 1, cnt = 1 /* 第一個已自動加入 */;

		for (; idx != sortedAry.length; idx++) // O.l("tmpV=" + sortedAry[idx] + ", idx=" + idx + ", max=" + max);

			if ((tmpV = sortedAry[idx]) != max) sortedAry[cnt++] = max = tmpV; // 連用 2 個等號

		if (cnt != sortedAry.length) System.arraycopy(sortedAry, 0, (sortedAry = new long[cnt]), 0, cnt);

		return sortedAry;
	}

	/**
	 * To distinct.
	 *
	 * @see Ar32va #easyDist(int[])
	 */
	public static long[] easyDist(long[] sortedAry) { // 2 份記憶體空間

		int idx, iRet;

		long cache, ret[] = new long[sortedAry.length];

		ret[0] = cache = sortedAry[0]; // 連用 2 個等號

		for (iRet = idx = 1; idx != sortedAry.length; idx++) // 連用 2 個等號

			if (sortedAry[idx] != cache) ret[iRet++] = cache = sortedAry[idx]; // 連用 2 個等號

		// O.l("cache=" + sortedAry[idx] + ", iRet=" + iRet );

		if (iRet != sortedAry.length) System.arraycopy(ret, 0, (ret = new long[iRet]), 0, iRet); // 使用原陣列當容器

		return ret;
	}

	/**
	 * Merge.
	 *
	 * @see Ar32va #merge(int[])
	 */
	public static long[] merge(long[] bigAry, long[] smallAry) {

		long[] ret = new long[bigAry.length + smallAry.length]; // todo: 重複用 big 嗎

		System.arraycopy(bigAry, 0, ret, 0, bigAry.length);
		System.arraycopy(smallAry, 0, ret, bigAry.length, smallAry.length);

		return ret;
	}

	/**
	 * Exclude.
	 *
	 * @see Ar32va #ex(int[])
	 */
	public static long[] ex(long[] sortedAr, long[] exAr) {

		int iKey = 0, len = sortedAr.length, srhFrom = 0, iFound, lenRet = 0;

		for (long key; iKey != len; iKey++) {

			O.l("ex=" + Arrays.toString(Arrays.copyOfRange(exAr, srhFrom, exAr.length)));

			iFound = Arrays.binarySearch(exAr, srhFrom, exAr.length, key = sortedAr[iKey]);

			O.l("key=" + key + " srhFrom=" + srhFrom + " iFound=" + iFound);

			if (iFound < 0) sortedAr[lenRet++] = key; // 用原陣列當容器

			if (srhFrom + iFound < -1) srhFrom++; // 新發現 可學習 // -insertionPoint - 1

		}

		if (lenRet != len) System.arraycopy(sortedAr, 0, (sortedAr = new long[lenRet]), 0, lenRet);

		return sortedAr;
	}
}
