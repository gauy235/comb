package lgpl3.o.ary;

import java.util.Arrays;

import lgpl3.o.O;

/**
 * 陣列小幫手娃.<br/>
 * The aid to array.
 *
 * @version 2023/11/04_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Aryva" >src</a>
 *
 * @see Ar32va
 */
public abstract class Aryva extends Aryva_A { // private static final Class<?> THIS = Aryva.class;

	/**
	 * To distinct.<br/>
	 *
	 * @see Ar32va #dist(int[])
	 */
	public static long[] dist(long[] sortedAry) {

		long max = sortedAry[0], tmpV;

		int idx = 1, cnt = 1 /* 第一個已自動加入 */;

		for (; idx != sortedAry.length; idx++) // O.l("tmpV=" + sortedAry[idx] + ", idx=" + idx + ", max=" + max);

			if ((tmpV = sortedAry[idx]) != max) sortedAry[cnt++] = max = tmpV; // 連用 2 個等號

		if (cnt != sortedAry.length) System.arraycopy(sortedAry, 0, (sortedAry = new long[cnt]), 0, cnt);

		return sortedAry;
	}

	/**
	 * To distinct.
	 *
	 * @see Ar32va #easyDist(int[])
	 */
	public static long[] easyDist(long[] sortedAry) { // 2 份記憶體空間

		int idx, iRet;

		long cache, ret[] = new long[sortedAry.length];

		ret[0] = cache = sortedAry[0]; // 連用 2 個等號

		for (iRet = idx = 1; idx != sortedAry.length; idx++) // 連用 2 個等號

			if (sortedAry[idx] != cache) ret[iRet++] = cache = sortedAry[idx]; // 連用 2 個等號

		// O.l("cache=" + sortedAry[idx] + ", iRet=" + iRet );

		if (iRet != sortedAry.length) System.arraycopy(ret, 0, (ret = new long[iRet]), 0, iRet); // 使用原陣列當容器

		return ret;
	}

	/**
	 * To distinct.
	 *
	 * @see Ar32va #merge(int[])
	 */
	public static long[] merge(long[] bigAry, long[] smallAry) {

		long[] ret = new long[bigAry.length + smallAry.length];

		System.arraycopy(bigAry, 0, ret, 0, bigAry.length);
		System.arraycopy(smallAry, 0, ret, bigAry.length, smallAry.length);

		return ret;
	}

	/**
	 * To difference.<br/>
	 * To difference.
	 */
	public static long[] ex(long[] sortedAry, long[] exAry) {

		int idx = 0, len = sortedAry.length;

		long key;

		int searchFrom = 0, searchTo = exAry.length, retIdx, newLen = 0;

		for (; idx != len; idx++) {

			O.l("ex=" + Arrays.toString(Arrays.copyOfRange(exAry, searchFrom, searchTo)));

			retIdx = Arrays.binarySearch(exAry, searchFrom, searchTo, key = sortedAry[idx]);

			O.l("retIdx=" + retIdx);

			O.l("(searchFrom + retIdx)=" + (searchFrom + retIdx));

			// todo: -insertionPoint - 1

			if ((searchFrom + retIdx) < -1) searchFrom++; // O.l("searchFrom++ ");

			if (retIdx < 0)

				if (idx == newLen) ++newLen;

				else sortedAry[newLen++] = key; // 使用原陣列當容器

		}

		if (newLen != len) System.arraycopy(sortedAry, 0, (sortedAry = new long[newLen]), 0, newLen);

		return sortedAry;
	}
}
