package lgpl3.o.ary;

import static lgpl3.o.B.T;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;

/**
 * 本類別是使用 32 位元的整數陣列.<br/>
 * The array of 32 bit integer.
 *
 * @version 2023/11/04_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Ar32va_A" >src</a>
 *
 * @see Ar32va_U
 */
public abstract class Ar32va_A { // private static final Class<?> THIS = Ar32va_A.class;

	/**
	 * To swap.
	 */
	public static int[] swapV(int[] ar, int idxA, int idxB) {

		int tmpV = ar[idxA];
		ar[idxA] = ar[idxB];
		ar[idxB] = tmpV;

		return ar;
	}

	/**
	 * To sum.
	 */
	public static long sum64(int[] ar, int from, int to) {

		long ans = 0L;

		for (; from < to; from++) ans += ar[from];

		return ans;
	}

	/**
	 * 切掉陣列前面的多個 0.<br/>
	 * Removes all 0 in the head of the array.
	 *
	 * @see O #delTailAll0(int[])
	 */
	public static int[] delHeadAll0(int[] ar) {

		int idxNot0 = 0, len = ar.length;

		for (; idxNot0 != len; idxNot0++) if (ar[idxNot0] != 0L) { // 用於縮短陣列情況下 [0,0,9,8] => len = 4-2

			if (idxNot0 != 0) System.arraycopy(ar, idxNot0, ar = new int[idxNot0 = len - idxNot0], 0, idxNot0);

			return ar;
		}

		return ar;
	}

	/**
	 * To gen the ascending int[]<br/>
	 */
	public static int[] genAscArFrom1(int len) {

		int[] ret = new int[len];

		for (int idx = 0; idx != len;) ret[idx] = ++idx;

		return ret;
	}

	/**
	 * 陣列內元素位置顛倒.<br/>
	 * To reverse.
	 */
	public static int[] rev(int[] ar) {

		// equivalent: Arrays.sort(ar, Collections.reverseOrder());

		for (int idx = 0, lenDiv2 = (ar.length >>> 1), lenMinus1 = (ar.length - 1), tmpV; idx != lenDiv2; idx++) {

			tmpV = ar[idx];
			ar[idx] = ar[lenMinus1 - idx]; // todo: (lenMinus1 - idx) 要用新變數嗎
			ar[lenMinus1 - idx] = tmpV;
		}

		return ar;
	}

	/**
	 * The bound and 0 are both inclusive.
	 *
	 * @see B64W6 #findFirstOccurDownTo0(long, int, int)
	 */
	public static int findFirstOccurDownTo0(int[] ar, int bound /* inclusive */, int key) {

		do if (ar[bound] == key) return bound; while (--bound >= 0);

		return Integer.MIN_VALUE; // todo: return -insertionPoint - 1
	}

	/**
	 * if contain.
	 *
	 * @see Aryva #ifContain(long[], int, int, long)
	 */
	public static boolean ifContain(int[] ar, int from, int to, int key) {

		while (from < to) if (ar[from++] == key) return T;

		return !T;
	}

	/**
	 * merge sort.<br/>
	 */
	public static void merge(int[] ar, int l, int mid, int r) {

		int tmpAr[] = new int[r - l + 1], iL = l, iM = (mid + 1), iT = 0;

		while (iL <= mid && iM <= r) tmpAr[iT++] = (ar[iL] < ar[iM]) ? ar[iL++] : ar[iM++]; // todo: 改良寫法

		while (iL <= mid) tmpAr[iT++] = ar[iL++];

		while (iM <= r) tmpAr[iT++] = ar[iM++];

		iT = 0;

		do ar[l++] = tmpAr[iT++]; while (l <= r); // 回寫回去
	}

	/**
	 * merge sort.<br/>
	 */
	public static int[] mgSort(int[] ar, int l, int r) {

		if (l < r) {

			int mid = (l + r) >>> 1;

			mgSort(ar, l, mid);

			mgSort(ar, (mid + 1), r);

			merge(ar, l, mid, r);
		}

		return ar;
	}

	/**
	 * merge sort.<br/>
	 */
	public static void mergeDesc(int[] ar, int l, int mid, int r) {

		int tmpAr[] = new int[r - l + 1], iL = l, iM = (mid + 1), iT = 0;

		while (iL <= mid && iM <= r) tmpAr[iT++] = (ar[iL] > ar[iM]) ? ar[iL++] : ar[iM++]; // todo: 改良寫法

		while (iL <= mid) tmpAr[iT++] = ar[iL++];

		while (iM <= r) tmpAr[iT++] = ar[iM++];

		iT = 0;

		do ar[l++] = tmpAr[iT++]; while (l <= r); // 回寫回去
	}

	/**
	 * sorts in descending order.
	 *
	 * @see Aryva #mgSortDesc(long[], int, int)
	 */
	public static int[] mgSortDesc(int[] ar, int l, int r) {

		if (l < r) {

			int mid = (l + r) >>> 1;

			mgSortDesc(ar, l, mid);

			mgSortDesc(ar, (mid + 1), r);

			mergeDesc(ar, l, mid, r);
		}

		return ar;
	}

	/**
	 * if there is duplicated.<br/>
	 */
	public static int[] chkDup(int[] sortedAr) {

		if (sortedAr.length == 0) return sortedAr;

		for (int ix = (sortedAr.length - 1), tail = sortedAr[ix], v; ix != 0; tail = v)

			if (tail == (v = sortedAr[--ix])) O.x("idx=" + ix);

		return sortedAr;
	}

	/**
	 * if there is duplicated.<br/>
	 */
	public static int[] mgSortNChkDup(int[] ar) {

		if (ar.length == 0) return ar;

		for (int ix = (ar.length - 1), tail = mgSortDesc(ar, 0, ix)[ix], v; ix != 0; tail = v)

			if (tail == (v = ar[--ix])) O.x("idx=" + ix);

		return ar;
	}

	/**
	 * if there is duplicated.<br/>
	 */
	public static int[] mgSortDescNChkDup(int[] ar) {

		if (ar.length == 0) return ar;

		for (int ix = (ar.length - 1), tail = mgSortDesc(ar, 0, ix)[ix], v; ix != 0; tail = v)

			if (tail == (v = ar[--ix])) O.x("idx=" + ix);

		return ar;
	}
}