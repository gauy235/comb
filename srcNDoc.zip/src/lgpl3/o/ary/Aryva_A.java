package lgpl3.o.ary;

import static lgpl3.o.B.T;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;

/**
 * 陣列小幫手娃.<br/>
 * The aid to array.
 *
 * @version 2023/11/04_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Aryva_A" >src</a>
 *
 * @see Aryva
 */
public abstract class Aryva_A { // private static final Class<?> THIS = Aryva_A.class;

	/**
	 * Sum.
	 */
	public static long sum(long[] ar, int from, int to) {

		long ans = 0L;

		for (; from < to; from++) ans += ar[from];

		return ans;
	}

	/**
	 * 切掉陣列前面的多個 0.<br/>
	 * Removes all 0 in the head of the array.
	 *
	 * @see O #delTailAll0(long[])
	 */
	public static long[] delHeadAll0(long[] ar) {

		int idxNot0 = 0, len = ar.length;

		for (; idxNot0 != len; idxNot0++) if (ar[idxNot0] != 0L) { // 用於縮短陣列情況下 [0,0,9,8] => len = 4-2

			if (idxNot0 != 0) System.arraycopy(ar, idxNot0, ar = new long[idxNot0 = len - idxNot0], 0, idxNot0);

			return ar;
		}

		return ar;
	}

	/**
	 * if contain.<br/>
	 *
	 * @see Ar32va #ifContain(int[], int, int, int)
	 */
	public static boolean ifContain(long[] ar, int from, int to, long key) {

		for (; from < to; from++) if (ar[from] == key) return T;

		return !T;
	}

	/**
	 * 陣列內元素位置顛倒.<br/>
	 * To reverse.
	 */
	public static long[] rev(long[] ar) {

		int ix = 0, lenDiv2 = (ar.length >>> 1), lenMinus1 = (ar.length - 1);

		for (long tmpV; ix != lenDiv2; ix++) {

			tmpV = ar[ix];
			ar[ix] = ar[lenMinus1 - ix]; // todo: lenMinus1 - ix 用 2 次
			ar[lenMinus1 - ix] = tmpV;
		}

		return ar;
	}

	/**
	 * merge sort.<br/>
	 *
	 * @see B64W6 #mergeAr(long[], int, int, int)
	 */
	public static void mergeLR(long[] ar, int l, int mid, int r) {

		long tmpAr[] = new long[r - l + 1], vL, vM; // 使用額外空間

		int iL = l, iM = (mid + 1), iT = 0;

		while (iL <= mid && iM <= r)

			if ((vL = ar[iL]) < (vM = ar[iM])) {

				tmpAr[iT++] = vL;
				iL++; // // 此情況下 iL 延長

			} else {

				tmpAr[iT++] = vM;
				iM++; // // 此情況下 iM 延長
			}

		// while (iL <= mid && iM <= right) tmpAr[iT++] = (vL=ar[iL++] < vM=ar[iM++]) ? vL : vM // err: 只可其中 1 邊延長

		while (iL <= mid) tmpAr[iT++] = ar[iL++];

		while (iM <= r) tmpAr[iT++] = ar[iM++];

		iT = 0;

		do ar[l++] = tmpAr[iT++]; while (l <= r); // 回寫回去

	}

	/**
	 * merge sort.<br/>
	 */
	public static long[] mgSort(long[] ar, int l, int r) {

		if (l < r) {

			int mid = (l + r) >>> 1;

			mgSort(ar, l, mid);

			mgSort(ar, (mid + 1), r);

			mergeLR(ar, l, mid, r);
		}

		return ar;
	}

	/**
	 * merge sort desc.<br/>
	 *
	 * @see Ar32va #mgSortDesc(int[], int, int)
	 */
	public static long[] mgSortDesc(long[] ar, int l, int r) {

		return rev(mgSort(ar, l, r));
	}

	/**
	 * Checks if there is duplicated.<br/>
	 */
	public static long[] chkDup(long[] sortedAr) {

		if (sortedAr.length == 0) return sortedAr; // O.l ("len=" + sortedAr.length, THIS);

		int ix = sortedAr.length - 1;

		for (long tail = sortedAr[ix], v; ix != 0; tail = v) if (tail == (v = sortedAr[--ix])) O.x("idx=" + ix);

		return sortedAr;
	}

	/**
	 * Checks if there is duplicated.<br/>
	 */
	public static long[] mgSortNChkDup(long[] ar) {

		if (ar.length == 0) return ar;

		int ix = ar.length - 1;

		for (long tail = mgSort(ar, 0, ix)[ix], v; ix != 0; tail = v) if (tail == (v = ar[--ix])) O.x("idx=" + ix);

		return ar;
	}

	/**
	 * sorts desc.<br/>
	 */
	public static long[] mgSortDescNChkDup(long[] ar) {

		if (ar.length == 0) return ar;

		int ix = ar.length - 1;

		for (long tail = mgSortDesc(ar, 0, ix)[ix], v; ix != 0; tail = v) if (tail == (v = ar[--ix])) O.x("idx=" + ix);

		return ar;
	}
}
