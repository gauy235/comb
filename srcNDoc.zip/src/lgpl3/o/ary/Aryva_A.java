package lgpl3.o.ary;

import static lgpl3.o.B.T;

import lgpl3.comb.b64WVCell.B64W6;
import lgpl3.o.O;

/**
 * 陣列小幫手娃.<br/>
 * The aid to array.
 *
 * @version 2023/11/04_09:50:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=Aryva_A" >src</a>
 *
 * @see Aryva
 */
public abstract class Aryva_A { // private static final Class<?> THIS = Aryva_A.class;

	/**
	 * To sum.
	 */
	public static long sum(long[] ary, int from, int to) {

		long ans = 0L;

		for (; from < to; from++) ans += ary[from];

		return ans;
	}

	/**
	 * 切掉陣列前面的多個 0.<br/>
	 * To remove all 0 of the head digits in the array.
	 *
	 * @see O#delTailAll0(long[])
	 */
	public static long[] delHeadAll0(long[] ary) {

		int idxNot0 = 0, len = ary.length;

		for (; idxNot0 != len; idxNot0++) if (ary[idxNot0] != 0L) break;

		if (idxNot0 != 0) System.arraycopy(ary, idxNot0, (ary = new long[idxNot0 = (len - idxNot0)]), 0, idxNot0);

		// [0,0,9,8] => 4-2
		// 用於縮短陣列情況下

		return ary;
	}

	/**
	 * To check if contain.<br/>
	 *
	 * @see Ar32va #ifContain(int[], int, int, int)
	 */
	public static boolean ifContain(long[] ary, int from, int to, long key) {

		for (; from < to; from++) if (ary[from] == key) return T;

		return !T;
	}

	/**
	 * 陣列內元素位置顛倒.<br/>
	 * To reverse.
	 */
	public static long[] rev(long[] ary) {

		int idx = 0, lenDiv2 = (ary.length >>> 1), lenMinus1 = (ary.length - 1);

		for (long tmpV; idx != lenDiv2; idx++) {

			tmpV = ary[idx];
			ary[idx] = ary[lenMinus1 - idx];
			ary[lenMinus1 - idx] = tmpV;
		}

		return ary;
	}

	/**
	 * merge sort.<br/>
	 *
	 * @see B64W6 #mergeAr(long[], int, int, int)
	 */
	public static void merge(long[] ar, int l, int mid, int r) {

		long tmpAr[] = new long[r - l + 1], vL, vM; // 使用額外空間

		int iL = l, iM = (mid + 1), iT = 0;

		while (iL <= mid && iM <= r)

			if ((vL = ar[iL]) < (vM = ar[iM])) {

				tmpAr[iT++] = vL;
				iL++; // // 此情況下 iL 延長

			} else {

				tmpAr[iT++] = vM;
				iM++; // // 此情況下 iM 延長
			}

		// while (iL <= mid && iM <= right) tmpAr[iT++] = (vL = ar[iL++]) < (vM = ar[iM++]) ? vL : vM; // err: 只可其中 1 邊延長

		while (iL <= mid) tmpAr[iT++] = ar[iL++];

		while (iM <= r) tmpAr[iT++] = ar[iM++];

		iT = 0;

		do ar[l++] = tmpAr[iT++]; while (l <= r); // 回寫回去

	}

	/**
	 * merge sort.<br/>
	 */
	public static long[] mgSort(long[] ar, int l, int r) {

		if (l < r) {

			int mid = (l + r) >>> 1;

			mgSort(ar, l, mid);

			mgSort(ar, (mid + 1), r);

			merge(ar, l, mid, r);
		}

		return ar;
	}

	/**
	 * merge sort.<br/>
	 *
	 * @see B64W6 #mergeAr(long[], int, int, int)
	 */
	public static void mergeDesc(long[] ar, int l, int mid, int r) {

		long tmpAr[] = new long[r - l + 1], vL, vM; // 使用額外空間

		int iL = l, iM = (mid + 1), iT = 0;

		while (iL <= mid && iM <= r)

			if ((vL = ar[iL]) > (vM = ar[iM])) {

				tmpAr[iT++] = vL;
				iL++; // // 此情況下 iL 延長

			} else {

				tmpAr[iT++] = vM;
				iM++; // // 此情況下 iM 延長
			}

		// while (iL <= mid && iM <= right) tmpAr[iT++] = (vL = ar[iL++]) < (vM = ar[iM++]) ? vL : vM; // err: 只可其中 1 邊延長

		while (iL <= mid) tmpAr[iT++] = ar[iL++];

		while (iM <= r) tmpAr[iT++] = ar[iM++];

		iT = 0;

		do ar[l++] = tmpAr[iT++]; while (l <= r); // 回寫回去

	}

	/**
	 * merge sort desc.<br/>
	 *
	 * @see Ar32va #mgSortDesc(int[], int, int)
	 */
	public static long[] mgSortDesc(long[] ar, int l, int r) {

		if (l < r) {

			int mid = (l + r) >>> 1;

			mgSortDesc(ar, l, mid);

			mgSortDesc(ar, (mid + 1), r);

			mergeDesc(ar, l, mid, r);
		}

		return ar;
	}

	/**
	 * To check if there is duplicated.<br/>
	 */
	public static long[] checkDup(long[] sortedAr) {

		if (sortedAr.length == 0) return sortedAr; // O.l ("len=" + sortedAry.length, THIS);

		int ix = sortedAr.length - 1;

		for (long tail = sortedAr[ix], head; ix > 0; tail = head) if (tail == (head = sortedAr[--ix])) O.x("idx=" + ix);

		return sortedAr;
	}

	/**
	 * To check if there is duplicated.<br/>
	 */
	public static long[] mgSortNCheckDup(long[] ar) {

		if (ar.length == 0) return ar;

		int ix = ar.length - 1;

		for (long tail = mgSort(ar, 0, ix)[ix], head; ix > 0; tail = head) if (tail == (head = ar[--ix])) O.x("idx=" + ix);

		return ar;
	}

	/**
	 * sort desc.<br/>
	 */
	public static long[] mgSortDescNCheckDup(long[] ar) { // todo: Ar32va 也要有此方法

		if (ar.length == 0) return ar;

		int ix = ar.length - 1;

		for (long tail = mgSortDesc(ar, 0, ix)[ix], head; ix > 0; tail = head) if (tail == (head = ar[--ix])) O.x("idx=" + ix);

		return ar;
	}
}
