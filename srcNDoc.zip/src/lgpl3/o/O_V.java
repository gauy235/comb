package lgpl3.o;

import java.lang.reflect.Array;

/**
 * @version 2023/11/25_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=O_V" >src</a>
 *
 * @see O_W
 */
public abstract class O_V extends O_M {

	/**
	 * 切掉陣列末的多個 0.<br/>
	 * Removes all 0 in the tail of the array.
	 */
	public static long[] delTailAll0(long[] ar) {

		int idxNot0 = ar.length; // l("idxNot0=" + idxNot0 );

		while (idxNot0-- != 0) if (ar[idxNot0] != 0L) break;

		if (idxNot0 == -1) return ARY0;

		if (++idxNot0 != ar.length) System.arraycopy(ar, 0, ar = new long[idxNot0], 0, idxNot0); // 縮短陣列情況下可用

		return ar;
	}

	/**
	 * 切掉陣列末的多個 0.<br/>
	 * Removes all 0 in the tail of the array.
	 */
	public static int[] delTailAll0(int[] ar) {

		int idxNot0 = ar.length; // l("idxNot0=" + idxNot0 );

		while (idxNot0-- != 0) if (ar[idxNot0] != 0) break;

		if (idxNot0 == -1) return INT32_ARY0;

		if (++idxNot0 != ar.length) System.arraycopy(ar, 0, ar = new int[idxNot0], 0, idxNot0); // 縮短陣列情況下可用

		return ar;
	}

	/**
	 * 切掉陣列末的多個 null.<br/>
	 * Removes all null in the tail of the array.
	 */
	@SuppressWarnings("unchecked")
	public static <T extends Object> T[] delTailAllNull(T[] ar) { // ambiguous for Sting[] and Object[]

		int idxNot0 = ar.length; // l("idxNot0=" + idxNot0 );

		while (idxNot0-- != 0) if (ar[idxNot0] != null) break;

		if (idxNot0 == -1) return (T[]) OBJ_ARY0;

		if (++idxNot0 != ar.length)

			System.arraycopy(ar, 0, ar = (T[]) Array.newInstance(ar[0].getClass(), idxNot0), 0, idxNot0); // 縮短陣列情況下可用

		return ar;
	}

	/**
	 * Gets the String that is nested in between two Strings.<br/>
	 * Only the first match is returned.
	 */
	public static String subSBetween(StringBuilder oriStr, String sStart, String sEnd) { // pretty good // 原創

		int iStart = oriStr.indexOf(sStart);

		if (iStart != -1) {

			final int iEnd = oriStr.indexOf(sEnd, (iStart += sStart.length())); // sStart.len > 0

			if (iEnd > iStart) return oriStr.substring(iStart, iEnd); // else xy(iStart, iEnd);

		}

		return null;
	}

	/**
	 * Gets the String that is nested in between two Strings.<br/>
	 * Only the first match is returned.
	 */
	public static String subSBetween(String oriS, String sStart, String sEnd) { // pretty good // 原創

		int iStart = oriS.indexOf(sStart);

		if (iStart != -1) {

			final int iEnd = oriS.indexOf(sEnd, (iStart += sStart.length()));

			if (iEnd > iStart) return oriS.substring(iStart, iEnd);

		}

		return null;
	}

	/**
	 * Trims all string in array of string.<br/>
	 */
	public static String[] splitNTrimAll(CharSequence charSeq, String regexToSplit) {

		String tmpS = (charSeq instanceof String) ? (String) charSeq : charSeq.toString(); // l("tmpS=" + tmpS);

		String[] sAry = tmpS.split(regexToSplit);

		// l("sAry="); // l(sAry);

		// l("len=" + sAry.length);

		int idx = 0, iRet = 0;

		for (; idx != sAry.length;) {

			// if (Z.equals(tmpS = sAry[idx++].trim()))
			if ((tmpS = sAry[idx++]) == null || Z.equals(tmpS = tmpS.trim())) continue; // tmpS must trim for 6! / 2! 3!

			sAry[iRet++] = tmpS;
		}

		if (iRet != sAry.length) System.arraycopy(sAry, 0, sAry = new String[iRet], 0, iRet);

		return sAry;
	}

	/**
	 * 執行緒活著嗎 ?<br/>
	 */
	public static <T extends Thread> boolean isAlive(T thr) {

		return (thr != null) && thr.isAlive();
	}

	/**
	 * aryOfThr 內有執行緒活著嗎 ?<br/>
	 */
	public static <T extends Thread> boolean isAnyAlive(T[] arOfThr) {

		T thr;

		for (int idx = 0; idx != arOfThr.length; idx++) if (((thr = arOfThr[idx]) != null) && thr.isAlive()) return B.T;

		return !B.T;
	}

	/**
	 * 停止 aryOfThr 內執行緒.<br/>
	 */
	@SuppressWarnings("deprecation")
	public static <T extends Thread> void stopAllAlive(T thr, T otherThr) {

		if ((thr != null) && thr.isAlive()) thr.stop();

		if ((otherThr != null) && otherThr.isAlive()) otherThr.stop();

	}

	/**
	 * 停止 aryOfThr 內執行緒.<br/>
	 */
	@SuppressWarnings("deprecation")
	public static <T extends Thread> void stopAllAlive(T thr, T[] aryOfThr) {

		if ((thr != null) && thr.isAlive()) thr.stop();

		for (int idx = 0; idx != aryOfThr.length; idx++) if (((thr = aryOfThr[idx]) != null) && thr.isAlive()) thr.stop();
	}
}
