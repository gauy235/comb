package lgpl3.o;

import java.util.Enumeration;
import java.util.Properties;

/**
 * The origin.<br/>
 *
 * @version 2023/11/05_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=O" >src</a>
 *
 */
public abstract class O extends O_W {

	/**
	 * 把 TreeMap 轉字串建立者.<br/>
	 */
	public static StringBuilder strOfProp(Properties prop, CharSequence lineWr) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		String key;
		for (Enumeration<?> en = prop.propertyNames(); en.hasMoreElements();)

			ret.append(key = (String) en.nextElement()).append(O.C61).append(prop.getProperty(key)).append(lineWr);

		return ret;
	}

	/**
	 * The user.name<br/>
	 */
	public static final String SYS_USER_DOT_NAME = System.getProperty("user.name");

	/**
	 * Is to develop?<br/>
	 */
	public static boolean isDev = "gau".equalsIgnoreCase(SYS_USER_DOT_NAME) || "demo".equalsIgnoreCase(SYS_USER_DOT_NAME);

	/**
	 * Is Linux?<br/>
	 */
	public static final boolean IS_LINUX = ("linux".compareToIgnoreCase(System.getProperty("os.name")) == 0);

	/**
	 * The String array.<br/>
	 */
	public static final String[] ARY_A_Z = { S65, S66, S67, S68, S69, S70, S71, S72, S73, S74, S75, S76, S77, S78, S79, S80,

			S81, S82, S83, S84, S85, S86, S87, S88, S89, S90 };

	/**
	 * The updated time.<br/>
	 */
	public static final String S_UPDATED_TIME_AS_VERSION = "2024/04/01_22:27:51+08:00"; // will auto update

}