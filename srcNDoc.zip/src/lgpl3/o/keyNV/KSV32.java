package lgpl3.o.keyNV;

import java.io.Serializable;

import lgpl3.o.B;
import lgpl3.o.O;

/**
 * 本類別 String 與 int.<br/>
 * Something like a String which is attached by an int.
 *
 * @version 2023/11/12_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=KSV32" >src</a>
 *
 * @see K32V
 * @see K32V32
 * @see K32V64
 * @see K32VSeq
 * @see K64V
 * @see K64V32
 * @see K64V64V64
 * @see KAr32V32
 * @see KArV32
 * @see KSV32
 * @see MapK32V
 * @see LiK32V32
 * @see LiK32VSeq
 * @see LiK64V32
 * @see LiKSV32
 */
public class KSV32 implements Comparable<KSV32>, Serializable {

	private static final Class<?> THIS = KSV32.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * The key.<br/>
	 */
	public final String k;

	/**
	 * The value.<br/>
	 */
	public int v;

	/**
	 * 建構方法.<br/>
	 */
	public KSV32(String s, int int32) {

		k = s;
		v = int32;
	}

	/**
	 * Compare to other's key.<br/>
	 */
	@Override
	public int compareTo(KSV32 otherKSV32) {

		return k.compareTo(otherKSV32.k);
	}

	/**
	 * Compare to other's key.<br/>
	 */
	@Override
	public boolean equals(Object obj) {

		if (obj == null) return !B.T;

		if (obj instanceof KSV32) return k.equals(((KSV32) obj).k);

		return !B.T;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public StringBuilder toStr() {

		return new StringBuilder(O.defLenForStr).append(O.C40).append(k).append(O.C94).append(v).append(O.C41);
	}
}
