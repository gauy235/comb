package lgpl3.o.keyNV;

import java.io.Serializable;

import lgpl3.o.B;
import lgpl3.o.O;

/**
 * 本類別 int64 與 int32.<br/>
 * It is like an int64 which is attached by the int32.
 *
 * @version 2023/11/12_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=K64V32" >src</a>
 *
 * @see K32V
 * @see K32V64
 * @see K32VSeq
 * @see K64V
 * @see K64V32
 * @see K64V64V64
 * @see KAr32V32
 * @see KArV32
 * @see KSV32
 * @see MapK32V
 * @see MapK32VSeq
 * @see MapK64V32
 * @see MapKSV32
 */
public class K64V32 implements Comparable<K64V32>, Serializable {

	private static final Class<?> THIS = K64V32.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * The key.<br/>
	 */
	public final long k;

	/**
	 * The value.<br/>
	 */
	public long v;

	/**
	 * 建構方法.<br/>
	 */
	public K64V32(long int64, int int32) {

		k = int64;
		v = int32;
	}

	/**
	 * 比較彼此的 64 位元整數的大小.<br/>
	 * To compare to other's key.
	 */
	@Override
	public int compareTo(K64V32 otherK64V32) {

		if (k > otherK64V32.k) return 1;

		if (k < otherK64V32.k) return -1;

		return 0;
	}

	/**
	 * 比較彼此的 64 位元整數的大小.<br/>
	 * To compare to other's key.
	 */
	@Override
	public boolean equals(Object obj) {

		if (obj == null) return !B.T;

		if (obj instanceof K64V32) return k == ((K64V32) obj).k;

		return !B.T;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public StringBuilder toStr() {

		return new StringBuilder(O.defLenForStr).append(O.C40).append(k).append(O.C94).append(v).append(O.C41);
	}
}
