package lgpl3.o.keyNV;

import java.util.Arrays;

import lgpl3.o.B;
import lgpl3.o.ary.Arr;
import lgpl3.o.ary.Seq;

/**
 * A map for K32VSeq.<br/>
 * A map for K32VSeq.
 *
 * @version 2023/11/12_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=MapK32VSeq" >MapK32VSeq.java</a>
 *
 * @see K32V
 * @see K32V64
 * @see K32VSeq
 * @see K64V
 * @see K64V32
 * @see K64V64V64
 * @see KAr32V32
 * @see KArV32
 * @see KSV32
 * @see MapK32V
 * @see MapK32VSeq
 * @see MapK64V32
 * @see MapKSV32
 */
public class MapK32VSeq extends Arr<K32VSeq> {

	private static final Class<?> THIS = MapK32VSeq.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	public MapK32VSeq() {

		super(K32VSeq.class); // fuck
	}

	/**
	 * 加入.<br/>
	 * To append without checking.
	 */
	public void a(int int32, Seq seq) {

		if (i == baseLen) extLen();

		ar[i++] = new K32VSeq(int32, seq);

	}

	/**
	 * 檢查後加入.<br/>
	 * To append after checked.
	 */
	public Seq get(int int32) {

		final int iFound = Arrays.binarySearch(ar, 0, i, new K32VSeq(int32, null));

		return ((iFound < 0) ? null : ar[iFound].v);

	}
}
