package lgpl3.o.keyNV;

import java.io.Serializable;

import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Arr;

/**
 * 問題在資料結構.<br/>
 * 若資料結構不好, 才會想一直抓住它, 丟也丟不掉 若資料結構好, 心中的大石頭就放下了.
 *
 * @version 2023/12/03_22:10:00<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=LiK32V32" >src</a>
 *
 * @see K32V
 * @see K32V32
 * @see K32V64
 * @see K32VSeq
 * @see K64V
 * @see K64V32
 * @see K64V64V64
 * @see KAr32V32
 * @see KArV32
 * @see KSV32
 * @see MapK32V
 * @see LiK32V32
 * @see LiK32VSeq
 * @see LiK64V32
 * @see LiKSV32
 */
public class LiK32V32 extends Arr<K32V32> implements Serializable { // List of K32V32

	private static final Class<?> THIS = LiK32V32.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * 建構方法.<br/>
	 */
	public LiK32V32() {

		super(K32V32.class);
	}

	/**
	 * 加入.<br/>
	 */
	public LiK32V32 a(int k, int v) {

		if (i == baseLen) extLen();

		ar[i++] = new K32V32(k, v);

		return this;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	@Override
	public StringBuilder toStr() {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		K32V32 kV;

		for (int idx = 0; idx != i;) {

			ret.append(O.C40).append((kV = ar[idx]).k).append(O.C94).append(kV.v).append(O.C41);

			if (++idx != i) ret.append(O.C_A_L);

		}

		return ret;
	}
}
