package lgpl3.o.keyNV;

import java.io.Serializable;

import lgpl3.o.B;
import lgpl3.o.O;
import lgpl3.o.ary.Arr;

/**
 * 問題在資料結構.<br/>
 * 因為資料結構不好, 才會想一直抓住它, 丟也丟不掉 若資料結構好, 心中的大石頭就放下了.<br/>
 *
 * @version 2023/11/12_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=LiKSV32" >src</a>
 *
 * @see K32V
 * @see K32V32
 * @see K32V64
 * @see K32VSeq
 * @see K64V
 * @see K64V32
 * @see K64V64V64
 * @see KAr32V32
 * @see KArV32
 * @see KSV32
 * @see LiK32V
 * @see LiK32V32
 * @see LiK32VSeq
 * @see LiK64V32
 * @see LiKSV32
 */
public class LiKSV32 extends Arr<KSV32> implements Serializable {

	private static final Class<?> THIS = LiKSV32.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * To put and count.<br/>
	 */
	public void easyPutNCount(String s) {

		KSV32 kV = new KSV32(s, 1); // cnt starts with 1

		if (i == 0) {

			if (i == baseLen) extLen();

			ar[i++] = kV;

		} else {

			KSV32 tailKSV32 = ar[i - 1];

			if (kV.k.equals(tailKSV32.k)) tailKSV32.v++;

			else {
				if (i == baseLen) extLen();

				ar[i++] = kV;
			}
		}
	}

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	public LiKSV32(String[] sortedSAry) {

		super(KSV32.class); // fuck

		for (int idx = 0; idx != sortedSAry.length; idx++) easyPutNCount(sortedSAry[idx]);
	}

	/**
	 * To array of distinct items.<br/>
	 */
	public String[] allKey() {

		String[] ret = new String[i];

		for (int idx = 0; idx != i; idx++) ret[idx] = ar[idx].k;

		return ret;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	@Override
	public StringBuilder toStr() {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		for (int idx = 0; idx != i;) {

			ret.append(ar[idx].toStr());

			if (++idx != i) ret.append(O.C_A_L);

		}

		return ret;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public StringBuilder toStr(CharSequence prefix, CharSequence lineWr) {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		KSV32 kV;

		for (int idx = 0; idx != i;) {

			ret.append(idx + 1).append(prefix).append((kV = ar[idx]).k).append(O.C61).append(kV.v);

			if (++idx != i) ret.append(lineWr); // todo: if (i++ != Strva.int32MaxRowForHtml)

		}

		return ret;
	}
}
