package lgpl3.o.keyNV;

import java.io.Serializable;

import lgpl3.o.B;
import lgpl3.o.O;

/**
 * 本類別 int64 跟 int64 跟 int64<br/>
 *
 * @version 2023/11/12_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=K64V64V64" >src</a>
 *
 * @see K32V
 * @see K32V32
 * @see K32V64
 * @see K32VSeq
 * @see K64V
 * @see K64V32
 * @see K64V64V64
 * @see KAr32V32
 * @see KArV32
 * @see KSV32
 * @see MapK32V
 * @see LiK32V32
 * @see LiK32VSeq
 * @see LiK64V32
 * @see LiKSV32
 */
public class K64V64V64 implements Comparable<K64V64V64>, Serializable {

	private static final Class<?> THIS = K64V64V64.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * The key.
	 */
	public final long k;

	/**
	 * The first value.
	 */
	public long v1;

	/**
	 * The second value 2.
	 */
	public long v2;

	/**
	 * Constructor.
	 */
	public K64V64V64(long int64, long int64V1, long int64V2) {

		k = int64;
		v1 = int64V1;
		v2 = int64V2;
	}

	/**
	 * Compare to other's key.
	 */
	@Override
	public int compareTo(K64V64V64 otherK64V64V64) {

		if (k > otherK64V64V64.k) return 1;

		if (k < otherK64V64V64.k) return -1;

		return 0;
	}

	/**
	 * Compare to other's key.
	 */
	@Override
	public boolean equals(Object obj) {

		if (obj == null) return !B.T;

		if (obj instanceof K64V64V64) return k == ((K64V64V64) obj).k;

		return !B.T;
	}

	/**
	 * To StringBuilder.
	 */
	public StringBuilder toStr() {

		return new StringBuilder(O.defLenForStr).append(O.C40).append(k).append(O.C94).append(v1).append(O.C94).append(v2).

				append(O.C41);

	}
}
