package lgpl3.o.keyNV;

import java.io.Serializable;

import lgpl3.comb.filter.CompaForAr32;
import lgpl3.o.B;
import lgpl3.o.O;

/**
 * 本類別 32 位元整數陣列及 32 位元整數, 其內第 0 位置是 32 位元整數陣列, 第 1 位置是 32 位元整數.<br/>
 * Something like a int[] which is attached by an int.
 *
 * @version 2023/11/12_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=KAr32V32" >src</a>
 *
 * @see K32V
 * @see K32V32
 * @see K32V64
 * @see K32VSeq
 * @see K64V
 * @see K64V32
 * @see K64V64V64
 * @see KAr32V32
 * @see KArV32
 * @see KSV32
 * @see LiK32VSeq
 * @see LiK64V32
 * @see LiKSV32
 */
public class KAr32V32 implements Comparable<KAr32V32>, Serializable {

	private static final Class<?> THIS = KAr32V32.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * The key.<br/>
	 */
	public final int[] k;

	/**
	 * The value.<br/>
	 */
	public int v;

	/**
	 * 建構方法.<br/>
	 */
	public KAr32V32(int[] ar32, int int32) {

		k = ar32;
		v = int32;
	}

	/**
	 * 建構方法.<br/>
	 */
	public KAr32V32(int len) {

		k = new int[len];
	}

	/**
	 * Compare to other's key.<br/>
	 */
	@Override
	public int compareTo(KAr32V32 otherKAr32V32) {

		return CompaForAr32.compa(k, otherKAr32V32.k);
	}

	/**
	 * Compare to other's key.<br/>
	 */
	@Override
	public boolean equals(Object obj) {

		if (obj == null) return !B.T;

		if (obj instanceof KAr32V32) return CompaForAr32.compa(k, ((KAr32V32) obj).k) == 0;

		return !B.T;
	}

	/**
	 * 加入.<br/>
	 * Append.
	 */
	public KAr32V32 a(int num32) {

		k[v++] = num32;

		return this;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public StringBuilder toStr() {

		StringBuilder ret = new StringBuilder(O.defLenForStr);

		ret.append("([");

		for (int idx = 0, len = k.length; idx != len;) {

			ret.append(k[idx]);

			if (++idx == len) break;

			else ret.append(O.STR_C44C32);
		}

		return ret.append("]^").append(v).append(O.C41);
	}
}
