package lgpl3.o.keyNV;

import java.util.Arrays;

import lgpl3.o.B;
import lgpl3.o.ary.Arr;

/**
 * A map for K32V.<br/>
 * To use K32V.
 *
 * @version 2023/11/12_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=MapK32V" >src</a>
 *
 * @see K32V
 * @see K32V32
 * @see K32V64
 * @see K32VSeq
 * @see K64V
 * @see K64V32
 * @see K64V64V64
 * @see KAr32V32
 * @see KArV32
 * @see KSV32
 * @see MapK32V
 * @see MapK32V32
 * @see MapK32VSeq
 * @see MapK64V32
 * @see MapKSV32
 */
public class MapK32V<V> extends Arr<K32V<V>> {

	private static final Class<?> THIS = MapK32V.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * 建構方法.<br/>
	 * Constructor.
	 */
	@SuppressWarnings("unchecked")
	public MapK32V() {

		super((Class<K32V<V>>) ((Class<V>) K32V.class)); // super((Class<K32V<V>>) K32V.class);
	}

	/**
	 * 加入.<br/>
	 */
	public MapK32V<V> a(int k, V v) {

		if (i == baseLen) extLen();

		ar[i++] = new K32V<V>(k, v);

		return this;
	}

	/**
	 * Gets value.<br/>
	 */
	public V get(int key) {

		int iFound = Arrays.binarySearch(ar, 0, i, new K32V<V>(key, null));

		return (iFound < 0 ? null : ar[iFound].v);
	}
}
