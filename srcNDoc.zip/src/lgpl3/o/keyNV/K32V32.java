package lgpl3.o.keyNV;

import java.io.Serializable;

import lgpl3.o.B;
import lgpl3.o.O;

/**
 * 本類別 int32 與 int32.<br/>
 * It is like an int32 which is attached to the int32.
 *
 * @version 2023/11/30_12:34:56<br/>
 *          <a target="_blank" href="http://c64.tw/w20/o/srchSrc.jsp?nameOfClass=K32V32" >src</a>
 *
 * @see K32V
 * @see K32V32
 * @see K32V64
 * @see K32VSeq
 * @see K64V
 * @see K64V32
 * @see K64V64V64
 * @see KAr32V32
 * @see KArV32
 * @see KSV32
 * @see MapK32V
 * @see LiK32V32
 * @see MapK32VSeq
 * @see MapK64V32
 * @see MapKSV32
 */
public class K32V32 implements Comparable<K32V32>, Serializable {

	private static final Class<?> THIS = K32V32.class;

	private static final long serialVersionUID = B.genId32(THIS);

	/**
	 * The key.<br/>
	 */
	public final int k;

	/**
	 * The value.<br/>
	 */
	public int v;

	/**
	 * 建構方法.<br/>
	 */
	public K32V32(int k, int v) {

		this.k = k;
		this.v = v;
	}

	/**
	 * 比較彼此的 32 位元整數的大小.<br/>
	 * To compare to other's at0().
	 */
	@Override
	public int compareTo(K32V32 otherK32V32) {

		return k - otherK32V32.k;
	}

	/**
	 * 比較彼此的 32 位元整數的大小.<br/>
	 * To compare to other's at0().
	 */
	@Override
	public boolean equals(Object obj) {

		if (obj == null) return !B.T;

		if (obj instanceof K32V32) return k == ((K32V32) obj).k;

		return !B.T;
	}

	/**
	 * To StringBuilder.<br/>
	 */
	public StringBuilder toStr() {

		return new StringBuilder(O.defLenForStr).append(O.C40).append(k).append(O.C94).append(v).append(O.C41);
	}
}
